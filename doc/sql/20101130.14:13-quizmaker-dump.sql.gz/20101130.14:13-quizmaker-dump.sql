--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

--
-- Name: plpgsql; Type: PROCEDURAL LANGUAGE; Schema: -; Owner: postgres
--

CREATE OR REPLACE PROCEDURAL LANGUAGE plpgsql;


ALTER PROCEDURAL LANGUAGE plpgsql OWNER TO postgres;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: assignedtests; Type: TABLE; Schema: public; Owner: jeri; Tablespace: 
--

CREATE TABLE assignedtests (
    assignedtest_id integer NOT NULL,
    test_id integer NOT NULL,
    user_id integer NOT NULL,
    actual_start_time timestamp(0) with time zone,
    actual_end_time timestamp(0) with time zone,
    allowed_start_time timestamp(0) with time zone,
    allowed_max_end_time timestamp(0) with time zone
);


ALTER TABLE public.assignedtests OWNER TO jeri;

--
-- Name: TABLE assignedtests; Type: COMMENT; Schema: public; Owner: jeri
--

COMMENT ON TABLE assignedtests IS 'An instance in which a test is assigned and allowed to be taken.';


--
-- Name: assignedtests_assignedtest_id_seq; Type: SEQUENCE; Schema: public; Owner: jeri
--

CREATE SEQUENCE assignedtests_assignedtest_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.assignedtests_assignedtest_id_seq OWNER TO jeri;

--
-- Name: assignedtests_assignedtest_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jeri
--

ALTER SEQUENCE assignedtests_assignedtest_id_seq OWNED BY assignedtests.assignedtest_id;


--
-- Name: assignedtests_assignedtest_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jeri
--

SELECT pg_catalog.setval('assignedtests_assignedtest_id_seq', 1, false);


--
-- Name: config; Type: TABLE; Schema: public; Owner: jeri; Tablespace: 
--

CREATE TABLE config (
    admin_email text
);


ALTER TABLE public.config OWNER TO jeri;

--
-- Name: TABLE config; Type: COMMENT; Schema: public; Owner: jeri
--

COMMENT ON TABLE config IS 'Global configuration options.';


--
-- Name: problems; Type: TABLE; Schema: public; Owner: jeri; Tablespace: 
--

CREATE TABLE problems (
    problem_id integer NOT NULL,
    file text NOT NULL,
    short_desc text NOT NULL,
    question text NOT NULL,
    answer text NOT NULL,
    nworklines integer DEFAULT 4 NOT NULL,
    par_time interval DEFAULT '00:05:00'::interval NOT NULL,
    uuid text NOT NULL,
    ref text,
    author text,
    insert_time timestamp(0) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.problems OWNER TO jeri;

--
-- Name: COLUMN problems.short_desc; Type: COMMENT; Schema: public; Owner: jeri
--

COMMENT ON COLUMN problems.short_desc IS 'A short description (1 line) of the problem.';


--
-- Name: COLUMN problems.par_time; Type: COMMENT; Schema: public; Owner: jeri
--

COMMENT ON COLUMN problems.par_time IS 'The amount of time it should take to answer the question.  "par" is lingo from golf.';


--
-- Name: COLUMN problems.uuid; Type: COMMENT; Schema: public; Owner: jeri
--

COMMENT ON COLUMN problems.uuid IS 'A unique identifier of this problem.  Used to prevent duplication (loading of the same problem twice).';


--
-- Name: COLUMN problems.ref; Type: COMMENT; Schema: public; Owner: jeri
--

COMMENT ON COLUMN problems.ref IS 'reference: A description of who created this problem and where it came from.';


--
-- Name: problems_problem_id_seq; Type: SEQUENCE; Schema: public; Owner: jeri
--

CREATE SEQUENCE problems_problem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.problems_problem_id_seq OWNER TO jeri;

--
-- Name: problems_problem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jeri
--

ALTER SEQUENCE problems_problem_id_seq OWNED BY problems.problem_id;


--
-- Name: problems_problem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jeri
--

SELECT pg_catalog.setval('problems_problem_id_seq', 24, true);


--
-- Name: problemscores; Type: TABLE; Schema: public; Owner: jeri; Tablespace: 
--

CREATE TABLE problemscores (
    pscore_id integer NOT NULL,
    test_id integer,
    problem_id integer,
    user_id integer,
    assignedtest_id integer,
    start_t timestamp(0) with time zone NOT NULL,
    end_t timestamp(0) with time zone NOT NULL,
    score integer
);


ALTER TABLE public.problemscores OWNER TO jeri;

--
-- Name: problemscores_pscore_id_seq; Type: SEQUENCE; Schema: public; Owner: jeri
--

CREATE SEQUENCE problemscores_pscore_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.problemscores_pscore_id_seq OWNER TO jeri;

--
-- Name: problemscores_pscore_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jeri
--

ALTER SEQUENCE problemscores_pscore_id_seq OWNED BY problemscores.pscore_id;


--
-- Name: problemscores_pscore_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jeri
--

SELECT pg_catalog.setval('problemscores_pscore_id_seq', 1, false);


--
-- Name: problemtags; Type: TABLE; Schema: public; Owner: jeri; Tablespace: 
--

CREATE TABLE problemtags (
    problem_id integer NOT NULL,
    tag_id integer NOT NULL
);


ALTER TABLE public.problemtags OWNER TO jeri;

--
-- Name: TABLE problemtags; Type: COMMENT; Schema: public; Owner: jeri
--

COMMENT ON TABLE problemtags IS 'Tags assigned to problems.';


--
-- Name: tags; Type: TABLE; Schema: public; Owner: jeri; Tablespace: 
--

CREATE TABLE tags (
    tag_id integer NOT NULL,
    tag text,
    dsc text,
    create_date timestamp(0) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.tags OWNER TO jeri;

--
-- Name: COLUMN tags.dsc; Type: COMMENT; Schema: public; Owner: jeri
--

COMMENT ON COLUMN tags.dsc IS 'A description of the meaning of this tag.';


--
-- Name: tags_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: jeri
--

CREATE SEQUENCE tags_tag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tags_tag_id_seq OWNER TO jeri;

--
-- Name: tags_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jeri
--

ALTER SEQUENCE tags_tag_id_seq OWNED BY tags.tag_id;


--
-- Name: tags_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jeri
--

SELECT pg_catalog.setval('tags_tag_id_seq', 39, true);


--
-- Name: testproblems; Type: TABLE; Schema: public; Owner: jeri; Tablespace: 
--

CREATE TABLE testproblems (
    test_id integer NOT NULL,
    problem_id integer NOT NULL,
    seq integer NOT NULL,
    points integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.testproblems OWNER TO jeri;

--
-- Name: tests; Type: TABLE; Schema: public; Owner: jeri; Tablespace: 
--

CREATE TABLE tests (
    test_id integer NOT NULL,
    author integer,
    dsc text,
    create_date timestamp(0) with time zone DEFAULT now() NOT NULL,
    finished boolean DEFAULT false NOT NULL
);


ALTER TABLE public.tests OWNER TO jeri;

--
-- Name: TABLE tests; Type: COMMENT; Schema: public; Owner: jeri
--

COMMENT ON TABLE tests IS 'A test definition.';


--
-- Name: COLUMN tests.dsc; Type: COMMENT; Schema: public; Owner: jeri
--

COMMENT ON COLUMN tests.dsc IS 'A description of this test (e.g. "MATH-40 Fall 2010; Mr Bigler.")';


--
-- Name: COLUMN tests.finished; Type: COMMENT; Schema: public; Owner: jeri
--

COMMENT ON COLUMN tests.finished IS 'A finished test should not be further modified.';


--
-- Name: tests_test_id_seq; Type: SEQUENCE; Schema: public; Owner: jeri
--

CREATE SEQUENCE tests_test_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tests_test_id_seq OWNER TO jeri;

--
-- Name: tests_test_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jeri
--

ALTER SEQUENCE tests_test_id_seq OWNED BY tests.test_id;


--
-- Name: tests_test_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jeri
--

SELECT pg_catalog.setval('tests_test_id_seq', 2, true);


--
-- Name: testscores; Type: VIEW; Schema: public; Owner: jeri
--

CREATE VIEW testscores AS
    SELECT problemscores.test_id, problemscores.user_id, problemscores.assignedtest_id, sum(problemscores.score) AS score FROM problemscores GROUP BY problemscores.test_id, problemscores.user_id, problemscores.assignedtest_id;


ALTER TABLE public.testscores OWNER TO jeri;

--
-- Name: users; Type: TABLE; Schema: public; Owner: jeri; Tablespace: 
--

CREATE TABLE users (
    user_id integer NOT NULL,
    username text NOT NULL,
    password text NOT NULL,
    role text,
    first_name text,
    last_name text,
    address text,
    phone text,
    email text
);


ALTER TABLE public.users OWNER TO jeri;

--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: jeri
--

CREATE SEQUENCE users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO jeri;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jeri
--

ALTER SEQUENCE users_user_id_seq OWNED BY users.user_id;


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jeri
--

SELECT pg_catalog.setval('users_user_id_seq', 1, false);


--
-- Name: assignedtest_id; Type: DEFAULT; Schema: public; Owner: jeri
--

ALTER TABLE assignedtests ALTER COLUMN assignedtest_id SET DEFAULT nextval('assignedtests_assignedtest_id_seq'::regclass);


--
-- Name: problem_id; Type: DEFAULT; Schema: public; Owner: jeri
--

ALTER TABLE problems ALTER COLUMN problem_id SET DEFAULT nextval('problems_problem_id_seq'::regclass);


--
-- Name: pscore_id; Type: DEFAULT; Schema: public; Owner: jeri
--

ALTER TABLE problemscores ALTER COLUMN pscore_id SET DEFAULT nextval('problemscores_pscore_id_seq'::regclass);


--
-- Name: tag_id; Type: DEFAULT; Schema: public; Owner: jeri
--

ALTER TABLE tags ALTER COLUMN tag_id SET DEFAULT nextval('tags_tag_id_seq'::regclass);


--
-- Name: test_id; Type: DEFAULT; Schema: public; Owner: jeri
--

ALTER TABLE tests ALTER COLUMN test_id SET DEFAULT nextval('tests_test_id_seq'::regclass);


--
-- Name: user_id; Type: DEFAULT; Schema: public; Owner: jeri
--

ALTER TABLE users ALTER COLUMN user_id SET DEFAULT nextval('users_user_id_seq'::regclass);


--
-- Data for Name: assignedtests; Type: TABLE DATA; Schema: public; Owner: jeri
--

COPY assignedtests (assignedtest_id, test_id, user_id, actual_start_time, actual_end_time, allowed_start_time, allowed_max_end_time) FROM stdin;
\.


--
-- Data for Name: config; Type: TABLE DATA; Schema: public; Owner: jeri
--

COPY config (admin_email) FROM stdin;
\.


--
-- Data for Name: problems; Type: TABLE DATA; Schema: public; Owner: jeri
--

COPY problems (problem_id, file, short_desc, question, answer, nworklines, par_time, uuid, ref, author, insert_time) FROM stdin;
\.


--
-- Data for Name: problemscores; Type: TABLE DATA; Schema: public; Owner: jeri
--

COPY problemscores (pscore_id, test_id, problem_id, user_id, assignedtest_id, start_t, end_t, score) FROM stdin;
\.


--
-- Data for Name: problemtags; Type: TABLE DATA; Schema: public; Owner: jeri
--

COPY problemtags (problem_id, tag_id) FROM stdin;
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: jeri
--

COPY tags (tag_id, tag, dsc, create_date) FROM stdin;
\.


--
-- Data for Name: testproblems; Type: TABLE DATA; Schema: public; Owner: jeri
--

COPY testproblems (test_id, problem_id, seq, points) FROM stdin;
\.


--
-- Data for Name: tests; Type: TABLE DATA; Schema: public; Owner: jeri
--

COPY tests (test_id, author, dsc, create_date, finished) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: jeri
--

COPY users (user_id, username, password, role, first_name, last_name, address, phone, email) FROM stdin;
\.


--
-- Name: assignedtests_assignedtest_id_key; Type: CONSTRAINT; Schema: public; Owner: jeri; Tablespace: 
--

ALTER TABLE ONLY assignedtests
    ADD CONSTRAINT assignedtests_assignedtest_id_key UNIQUE (assignedtest_id);


--
-- Name: assignedtests_pkey; Type: CONSTRAINT; Schema: public; Owner: jeri; Tablespace: 
--

ALTER TABLE ONLY assignedtests
    ADD CONSTRAINT assignedtests_pkey PRIMARY KEY (assignedtest_id, test_id, user_id);


--
-- Name: problems_pkey; Type: CONSTRAINT; Schema: public; Owner: jeri; Tablespace: 
--

ALTER TABLE ONLY problems
    ADD CONSTRAINT problems_pkey PRIMARY KEY (problem_id);


--
-- Name: problems_uuid_key; Type: CONSTRAINT; Schema: public; Owner: jeri; Tablespace: 
--

ALTER TABLE ONLY problems
    ADD CONSTRAINT problems_uuid_key UNIQUE (uuid);


--
-- Name: problemscores_pkey; Type: CONSTRAINT; Schema: public; Owner: jeri; Tablespace: 
--

ALTER TABLE ONLY problemscores
    ADD CONSTRAINT problemscores_pkey PRIMARY KEY (pscore_id);


--
-- Name: problemtags_pkey; Type: CONSTRAINT; Schema: public; Owner: jeri; Tablespace: 
--

ALTER TABLE ONLY problemtags
    ADD CONSTRAINT problemtags_pkey PRIMARY KEY (problem_id, tag_id);


--
-- Name: tags_pkey; Type: CONSTRAINT; Schema: public; Owner: jeri; Tablespace: 
--

ALTER TABLE ONLY tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (tag_id);


--
-- Name: testproblems_pkey; Type: CONSTRAINT; Schema: public; Owner: jeri; Tablespace: 
--

ALTER TABLE ONLY testproblems
    ADD CONSTRAINT testproblems_pkey PRIMARY KEY (test_id, problem_id, seq);


--
-- Name: tests_pkey; Type: CONSTRAINT; Schema: public; Owner: jeri; Tablespace: 
--

ALTER TABLE ONLY tests
    ADD CONSTRAINT tests_pkey PRIMARY KEY (test_id);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: jeri; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: users_username_key; Type: CONSTRAINT; Schema: public; Owner: jeri; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: assignedtests_test_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jeri
--

ALTER TABLE ONLY assignedtests
    ADD CONSTRAINT assignedtests_test_id_fkey FOREIGN KEY (test_id) REFERENCES tests(test_id);


--
-- Name: assignedtests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jeri
--

ALTER TABLE ONLY assignedtests
    ADD CONSTRAINT assignedtests_user_id_fkey FOREIGN KEY (user_id) REFERENCES users(user_id);


--
-- Name: problemscores_assignedtest_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jeri
--

ALTER TABLE ONLY problemscores
    ADD CONSTRAINT problemscores_assignedtest_id_fkey FOREIGN KEY (assignedtest_id) REFERENCES assignedtests(assignedtest_id);


--
-- Name: problemscores_problem_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jeri
--

ALTER TABLE ONLY problemscores
    ADD CONSTRAINT problemscores_problem_id_fkey FOREIGN KEY (problem_id) REFERENCES problems(problem_id);


--
-- Name: problemscores_test_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jeri
--

ALTER TABLE ONLY problemscores
    ADD CONSTRAINT problemscores_test_id_fkey FOREIGN KEY (test_id) REFERENCES tests(test_id);


--
-- Name: problemscores_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jeri
--

ALTER TABLE ONLY problemscores
    ADD CONSTRAINT problemscores_user_id_fkey FOREIGN KEY (user_id) REFERENCES users(user_id);


--
-- Name: problemtags_problem_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jeri
--

ALTER TABLE ONLY problemtags
    ADD CONSTRAINT problemtags_problem_id_fkey FOREIGN KEY (problem_id) REFERENCES problems(problem_id);


--
-- Name: problemtags_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jeri
--

ALTER TABLE ONLY problemtags
    ADD CONSTRAINT problemtags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES tags(tag_id);


--
-- Name: testproblems_problem_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jeri
--

ALTER TABLE ONLY testproblems
    ADD CONSTRAINT testproblems_problem_id_fkey FOREIGN KEY (problem_id) REFERENCES problems(problem_id);


--
-- Name: testproblems_test_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jeri
--

ALTER TABLE ONLY testproblems
    ADD CONSTRAINT testproblems_test_id_fkey FOREIGN KEY (test_id) REFERENCES tests(test_id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

