--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

--
-- Name: plpgsql; Type: PROCEDURAL LANGUAGE; Schema: -; Owner: postgres
--

CREATE OR REPLACE PROCEDURAL LANGUAGE plpgsql;


ALTER PROCEDURAL LANGUAGE plpgsql OWNER TO postgres;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: assignedtests; Type: TABLE; Schema: public; Owner: jeri; Tablespace: 
--

CREATE TABLE assignedtests (
    ass_test_id integer NOT NULL,
    test_id integer NOT NULL,
    user_id integer NOT NULL,
    actual_start_time timestamp(0) with time zone,
    actual_end_time timestamp(0) with time zone,
    allowed_start_time timestamp(0) with time zone,
    allowed_max_end_time timestamp(0) with time zone
);


ALTER TABLE public.assignedtests OWNER TO jeri;

--
-- Name: TABLE assignedtests; Type: COMMENT; Schema: public; Owner: jeri
--

COMMENT ON TABLE assignedtests IS 'An instance in which a test is assigned and allowed to be taken.';


--
-- Name: assignedtests_ass_test_id_seq; Type: SEQUENCE; Schema: public; Owner: jeri
--

CREATE SEQUENCE assignedtests_ass_test_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.assignedtests_ass_test_id_seq OWNER TO jeri;

--
-- Name: assignedtests_ass_test_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jeri
--

ALTER SEQUENCE assignedtests_ass_test_id_seq OWNED BY assignedtests.ass_test_id;


--
-- Name: assignedtests_ass_test_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jeri
--

SELECT pg_catalog.setval('assignedtests_ass_test_id_seq', 1, false);


--
-- Name: config; Type: TABLE; Schema: public; Owner: jeri; Tablespace: 
--

CREATE TABLE config (
    problems_dir text,
    header_file text,
    admin_email text
);


ALTER TABLE public.config OWNER TO jeri;

--
-- Name: TABLE config; Type: COMMENT; Schema: public; Owner: jeri
--

COMMENT ON TABLE config IS 'Global configuration options.';


--
-- Name: problems; Type: TABLE; Schema: public; Owner: jeri; Tablespace: 
--

CREATE TABLE problems (
    problem_id integer NOT NULL,
    file text NOT NULL,
    dsc text,
    par_time interval DEFAULT '00:05:00'::interval NOT NULL,
    uuid text NOT NULL,
    ref text,
    author text
);


ALTER TABLE public.problems OWNER TO jeri;

--
-- Name: COLUMN problems.file; Type: COMMENT; Schema: public; Owner: jeri
--

COMMENT ON COLUMN problems.file IS 'File where problem definition is stored.';


--
-- Name: COLUMN problems.dsc; Type: COMMENT; Schema: public; Owner: jeri
--

COMMENT ON COLUMN problems.dsc IS 'description';


--
-- Name: COLUMN problems.par_time; Type: COMMENT; Schema: public; Owner: jeri
--

COMMENT ON COLUMN problems.par_time IS 'The amount of time it should take to answer the question.  "par" is lingo from golf.';


--
-- Name: COLUMN problems.uuid; Type: COMMENT; Schema: public; Owner: jeri
--

COMMENT ON COLUMN problems.uuid IS 'A unique identifier of this problem.  Used to prevent duplication (loading of the same problem twice).';


--
-- Name: COLUMN problems.ref; Type: COMMENT; Schema: public; Owner: jeri
--

COMMENT ON COLUMN problems.ref IS 'reference: A description of who created this problem and where it came from.';


--
-- Name: problems_problem_id_seq; Type: SEQUENCE; Schema: public; Owner: jeri
--

CREATE SEQUENCE problems_problem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.problems_problem_id_seq OWNER TO jeri;

--
-- Name: problems_problem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jeri
--

ALTER SEQUENCE problems_problem_id_seq OWNED BY problems.problem_id;


--
-- Name: problems_problem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jeri
--

SELECT pg_catalog.setval('problems_problem_id_seq', 24, true);


--
-- Name: problemscores; Type: TABLE; Schema: public; Owner: jeri; Tablespace: 
--

CREATE TABLE problemscores (
    pscore_id integer NOT NULL,
    test_id integer,
    problem_id integer,
    user_id integer,
    ass_test_id integer,
    start_t timestamp(0) with time zone NOT NULL,
    end_t timestamp(0) with time zone NOT NULL,
    score integer
);


ALTER TABLE public.problemscores OWNER TO jeri;

--
-- Name: problemscores_pscore_id_seq; Type: SEQUENCE; Schema: public; Owner: jeri
--

CREATE SEQUENCE problemscores_pscore_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.problemscores_pscore_id_seq OWNER TO jeri;

--
-- Name: problemscores_pscore_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jeri
--

ALTER SEQUENCE problemscores_pscore_id_seq OWNED BY problemscores.pscore_id;


--
-- Name: problemscores_pscore_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jeri
--

SELECT pg_catalog.setval('problemscores_pscore_id_seq', 1, false);


--
-- Name: problemtags; Type: TABLE; Schema: public; Owner: jeri; Tablespace: 
--

CREATE TABLE problemtags (
    problem_id integer NOT NULL,
    tag_id integer NOT NULL
);


ALTER TABLE public.problemtags OWNER TO jeri;

--
-- Name: TABLE problemtags; Type: COMMENT; Schema: public; Owner: jeri
--

COMMENT ON TABLE problemtags IS 'Tags assigned to problems.';


--
-- Name: tags; Type: TABLE; Schema: public; Owner: jeri; Tablespace: 
--

CREATE TABLE tags (
    tag_id integer NOT NULL,
    tag text,
    dsc text,
    create_date timestamp(0) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.tags OWNER TO jeri;

--
-- Name: COLUMN tags.dsc; Type: COMMENT; Schema: public; Owner: jeri
--

COMMENT ON COLUMN tags.dsc IS 'A description of the meaning of this tag.';


--
-- Name: tags_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: jeri
--

CREATE SEQUENCE tags_tag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tags_tag_id_seq OWNER TO jeri;

--
-- Name: tags_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jeri
--

ALTER SEQUENCE tags_tag_id_seq OWNED BY tags.tag_id;


--
-- Name: tags_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jeri
--

SELECT pg_catalog.setval('tags_tag_id_seq', 39, true);


--
-- Name: testproblems; Type: TABLE; Schema: public; Owner: jeri; Tablespace: 
--

CREATE TABLE testproblems (
    test_id integer NOT NULL,
    problem_id integer NOT NULL,
    seq integer NOT NULL,
    points integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.testproblems OWNER TO jeri;

--
-- Name: tests; Type: TABLE; Schema: public; Owner: jeri; Tablespace: 
--

CREATE TABLE tests (
    test_id integer NOT NULL,
    author integer,
    dsc text,
    create_date timestamp(0) with time zone DEFAULT now() NOT NULL,
    finished boolean DEFAULT false NOT NULL
);


ALTER TABLE public.tests OWNER TO jeri;

--
-- Name: TABLE tests; Type: COMMENT; Schema: public; Owner: jeri
--

COMMENT ON TABLE tests IS 'A test definition.';


--
-- Name: COLUMN tests.dsc; Type: COMMENT; Schema: public; Owner: jeri
--

COMMENT ON COLUMN tests.dsc IS 'A description of this test (e.g. "MATH-40 Fall 2010; Mr Bigler.")';


--
-- Name: COLUMN tests.finished; Type: COMMENT; Schema: public; Owner: jeri
--

COMMENT ON COLUMN tests.finished IS 'A finished test should not be further modified.';


--
-- Name: tests_test_id_seq; Type: SEQUENCE; Schema: public; Owner: jeri
--

CREATE SEQUENCE tests_test_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tests_test_id_seq OWNER TO jeri;

--
-- Name: tests_test_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jeri
--

ALTER SEQUENCE tests_test_id_seq OWNED BY tests.test_id;


--
-- Name: tests_test_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jeri
--

SELECT pg_catalog.setval('tests_test_id_seq', 2, true);


--
-- Name: testscores; Type: VIEW; Schema: public; Owner: jeri
--

CREATE VIEW testscores AS
    SELECT problemscores.test_id, problemscores.user_id, problemscores.ass_test_id, sum(problemscores.score) AS score FROM problemscores GROUP BY problemscores.test_id, problemscores.user_id, problemscores.ass_test_id;


ALTER TABLE public.testscores OWNER TO jeri;

--
-- Name: users; Type: TABLE; Schema: public; Owner: jeri; Tablespace: 
--

CREATE TABLE users (
    user_id integer NOT NULL,
    username text NOT NULL,
    password text NOT NULL,
    role text,
    first_name text,
    last_name text,
    address text,
    phone text,
    email text
);


ALTER TABLE public.users OWNER TO jeri;

--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: jeri
--

CREATE SEQUENCE users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO jeri;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jeri
--

ALTER SEQUENCE users_user_id_seq OWNED BY users.user_id;


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jeri
--

SELECT pg_catalog.setval('users_user_id_seq', 1, false);


--
-- Name: ass_test_id; Type: DEFAULT; Schema: public; Owner: jeri
--

ALTER TABLE assignedtests ALTER COLUMN ass_test_id SET DEFAULT nextval('assignedtests_ass_test_id_seq'::regclass);


--
-- Name: problem_id; Type: DEFAULT; Schema: public; Owner: jeri
--

ALTER TABLE problems ALTER COLUMN problem_id SET DEFAULT nextval('problems_problem_id_seq'::regclass);


--
-- Name: pscore_id; Type: DEFAULT; Schema: public; Owner: jeri
--

ALTER TABLE problemscores ALTER COLUMN pscore_id SET DEFAULT nextval('problemscores_pscore_id_seq'::regclass);


--
-- Name: tag_id; Type: DEFAULT; Schema: public; Owner: jeri
--

ALTER TABLE tags ALTER COLUMN tag_id SET DEFAULT nextval('tags_tag_id_seq'::regclass);


--
-- Name: test_id; Type: DEFAULT; Schema: public; Owner: jeri
--

ALTER TABLE tests ALTER COLUMN test_id SET DEFAULT nextval('tests_test_id_seq'::regclass);


--
-- Name: user_id; Type: DEFAULT; Schema: public; Owner: jeri
--

ALTER TABLE users ALTER COLUMN user_id SET DEFAULT nextval('users_user_id_seq'::regclass);


--
-- Data for Name: assignedtests; Type: TABLE DATA; Schema: public; Owner: jeri
--

COPY assignedtests (ass_test_id, test_id, user_id, actual_start_time, actual_end_time, allowed_start_time, allowed_max_end_time) FROM stdin;
\.


--
-- Data for Name: config; Type: TABLE DATA; Schema: public; Owner: jeri
--

COPY config (problems_dir, header_file, admin_email) FROM stdin;
\.


--
-- Data for Name: problems; Type: TABLE DATA; Schema: public; Owner: jeri
--

COPY problems (problem_id, file, dsc, par_time, uuid, ref, author) FROM stdin;
1	/home/jeri/MATH-40/qzm-problems/arc_length-2010-09-15.pl	Derive formula for the arc length using the Pythagorean Theorem.	00:05:00	[jmm] Wed, 15 Sep 2010 21:17:42 -0700	This example is commonly given in a Calculus 2 (MATH-31) class.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about
2	/home/jeri/MATH-40/qzm-problems/area_circle-2010-09-16.pl	Devise the formula for the area of a circle.	00:05:00	[jmm] Thu, 16 Sep 2010 08:59:22 -0700	This example is commonly given in a Calculus 2 (MATH-31) class.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about
3	/home/jeri/MATH-40/qzm-problems/Bernoulli-2010-09-07-16-01.pl	Solve the ODE: y' + y = x*y^3	00:03:00	Tue, 07 Sep 2010 16:29:03 -0700	An example given in class (MATH-40) taught by Mr Bigler at Butte Community College on 2010-Sep-01.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about
4	/home/jeri/MATH-40/qzm-problems/Bernoulli-2010-09-07-16-02.pl	Solve the ODE: y' - 2y/x = -x^2 * y^2	00:07:00	Tue, 07 Sep 2010 16:44:14 -0700	An example taken from Wikipedia [http://en.wikipedia.org/wiki/Bernoulli_differential_equation] on 2010-Sep-07	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about
5	/home/jeri/MATH-40/qzm-problems/Bernoulli-2010-09-07-20-01.pl	Solve the IVP: y' - y/2x = x * y^-3; y(1) = 2	00:05:00	Tue, 07 Sep 2010 20:38:37 -0700	An example given in class (MATH-40) taught by Mr Bigler at Butte Community College on 2010-Sep-01.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about
6	/home/jeri/MATH-40/qzm-problems/exact-ODE-2010-09-13-01.pl	Solve the ODE: (xy - 1)dx + (x^2 - xy) dy = 0	00:04:00	[jmm] Tue, 21 Sep 2010 22:26:02 -0700	An example given on 9/13/10 in the class MATH-40 taught\nby Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about
7	/home/jeri/MATH-40/qzm-problems/exact-ODE-2010-09-13-02.pl	Solve the ODE: y dx + (x^2 y - x) dy = 0	00:04:00	[jmm] Tue, 21 Sep 2010 22:57:59 -0700	An example given on 9/13/10 in the class MATH-40 taught\nby Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about
8	/home/jeri/MATH-40/qzm-problems/Gauss_Law-2010-09-18-01.pl	Show that Gauss's Law is true by calculating the integral.	00:05:00	[jmm] Thu, 18 Sep 2010 23:35:43 -0700	A common problem in a Physisc Electricity and Magnetism class.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about
9	/home/jeri/MATH-40/qzm-problems/HW-2010-08-25-03-separable.pl	Solve the ODE: sin(x)*sin(y) dx + cos(x)*cos(y) dy = 0	00:03:00	[jmm] Wed, 22 Sep 2010 16:13:49 -0700	Homework problem 3 from the sheet handed out on 8/25/10 in the class (MATH-40) taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about
10	/home/jeri/MATH-40/qzm-problems/HW-2010-08-25-04-separable.pl	Solve the ODE: dP/dt = a*P - b*P^2	00:05:00	[jmm] Wed, 22 Sep 2010 16:41:13 -0700	Homework problem 4 from the sheet handed out on 8/25/10 in the class (MATH-40) taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about
11	/home/jeri/MATH-40/qzm-problems/HW-2010-08-25-05-separable.pl	Solve the ODE: (xy + x)dx - (x^2*y^2 + x^2 + y^2 + 1)dy = 0	00:10:00	[jmm] Wed, 22 Sep 2010 18:01:09 -0700	Homework problem 5 from the sheet handed out on 8/25/10 in the class (MATH-40) taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about
12	/home/jeri/MATH-40/qzm-problems/HW-2010-08-25-10-separable.pl	Solve the IVP: x*sin(x)*e^(-y) dx - y dy = 0	00:10:00	[jmm] Wed, 22 Sep 2010 23:28:25 -0700	Homework problem 10 from the sheet handed out on 8/25/10 in the class (MATH-40) taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about
13	/home/jeri/MATH-40/qzm-problems/HW-2010-08-30-07-linear.pl	Solve the IVP: y' = (cot x)*y + sin(x); y(pi/2) = 0	00:10:00	[jmm] Thu, 23 Sep 2010 09:15:47 -0700	Homework problem 7 from the problems on Pg. 71 of Ordinary Differential Equations by Charles E. Roberts.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about
14	/home/jeri/MATH-40/qzm-problems/HW-2010-09-13-16-ODE.pl	Solve the ODE: (x + y) dy = y dx	00:10:00	[jmm] Thu, 23 Sep 2010 17:23:52 -0700	Homework problem #16 from sheet handed out on 9/13/10 in the\nclass MATH-40 taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about
15	/home/jeri/MATH-40/qzm-problems/HW-2010-09-17-01-orthogonal_trajectory.pl	Find the orthogonal trajectory of: y = c*(x + 1/x)	00:04:00	[jmm] Tue, 21 Sep 2010 20:13:23 -0700	Homework problem #1 from sheet handed out on 9/17/10 in the\nclass MATH-40 taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about
16	/home/jeri/MATH-40/qzm-problems/HW-2010-09-17-02-falling_bodies.pl	4 lbs thrown down 2000 ft ...	00:04:00	[jmm] Tue, 21 Sep 2010 20:20:12 -0700	Homework problem #3 from sheet handed out on 9/17/10 in the\nclass MATH-40 taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about
17	/home/jeri/MATH-40/qzm-problems/HW-2010-09-17-03-exponential_growth.pl	A mold grows at a rate ...	00:05:00	[jmm] Tue, 21 Sep 2010 20:42:10 -0700	Homework problem #6 from sheet handed out on 9/17/10 in the\nclass MATH-40 taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about
18	/home/jeri/MATH-40/qzm-problems/HW-2010-09-17-05-newtons_cooling.pl	A pan of hot water is removed ...	00:05:00	[jmm] Tue, 21 Sep 2010 20:53:36 -0700	Homework problem #8 from sheet handed out on 9/17/10 in the\nclass MATH-40 taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about
19	/home/jeri/MATH-40/qzm-problems/HW-2010-09-17-06-mixture.pl	A tank initially contains 300 gal of brine ...	00:15:00	[jmm] Tue, 21 Sep 2010 21:18:41 -0700	Homework problem #10 from sheet handed out on 9/17/10 in the\nclass MATH-40 taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about
20	/home/jeri/MATH-40/qzm-problems/partial_fractions-2010-09-19-01.pl	Integrate: (x^2 - 1)/(x*(x^2 + 1))	00:03:00	[jmm] 2010-09-19 01	An example made up by the author on 19 Sep 2010.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about
21	/home/jeri/MATH-40/qzm-problems/Physics-2010-09-09-21:57:30.pl	Derive the kinematic equation for position.	00:05:00	[jmm] Thu, 09 Sep 2010 22:03:06 -0700	A common example that is relevant to both a Physics class and\na class in Differential Equations.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about
22	/home/jeri/MATH-40/qzm-problems/separable-2010-08-24-01.pl	Solve the ODE: y' = 2*x	00:02:00	[jmm] Tue, 08 Aug 2010 00:00:00 -0700	An example given in class (MATH-40) taught by Mr Bigler at Butte Community College on 2010-Aug-24.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about
23	/home/jeri/MATH-40/qzm-problems/separable-2010-08-24-02.pl	Solve the ODE: y' = 1 + y^2	00:02:00	[jmm] Tue, 08 Aug 2010 00:00:01 -0700	An example given in class (MATH-40) taught by Mr Bigler at Butte Community College on 2010-Aug-24.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about
24	/home/jeri/MATH-40/qzm-problems/separable-2010-08-24-03.pl	Solve the IVP: y' = -x/y; y(0) = 1	00:02:00	[jmm] Tue, 08 Aug 2010 00:00:02 -0700	An example given in class (MATH-40) taught by Mr Bigler at Butte Community College on 2010-Aug-24.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about
\.


--
-- Data for Name: problemscores; Type: TABLE DATA; Schema: public; Owner: jeri
--

COPY problemscores (pscore_id, test_id, problem_id, user_id, ass_test_id, start_t, end_t, score) FROM stdin;
\.


--
-- Data for Name: problemtags; Type: TABLE DATA; Schema: public; Owner: jeri
--

COPY problemtags (problem_id, tag_id) FROM stdin;
1	1
1	2
1	3
1	4
1	5
1	6
1	7
2	8
2	3
2	9
2	5
2	10
3	1
3	11
3	12
3	13
3	14
3	15
4	1
4	11
4	12
4	14
5	1
5	11
5	16
5	12
5	14
6	8
6	14
6	1
6	17
7	8
7	14
7	1
7	17
8	18
8	8
8	19
8	20
9	1
9	2
9	14
9	21
9	22
10	1
10	2
10	14
10	21
10	22
10	23
11	1
11	2
11	14
11	24
11	25
11	23
12	16
12	1
12	26
12	14
12	24
12	22
12	27
13	16
13	1
13	28
13	14
13	24
13	22
14	8
14	14
14	1
14	24
14	29
14	30
15	8
15	14
15	31
15	25
16	8
16	14
16	32
17	8
17	14
17	33
18	8
18	14
18	34
19	8
19	14
19	35
19	36
20	8
20	23
20	37
20	3
21	18
21	8
21	1
21	38
21	39
21	14
22	1
22	2
22	14
22	9
23	1
23	2
23	14
23	9
24	1
24	26
24	14
24	9
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: jeri
--

COPY tags (tag_id, tag, dsc, create_date) FROM stdin;
1	ODE	\N	2010-09-25 20:39:31-07
2	separable ODE	\N	2010-09-25 20:39:31-07
3	class:MATH-31	\N	2010-09-25 20:39:31-07
4	difficulty:moderate	\N	2010-09-25 20:39:31-07
5	proof	\N	2010-09-25 20:39:31-07
6	pythagorean theorem	\N	2010-09-25 20:39:31-07
7	arc length	\N	2010-09-25 20:39:31-07
8	math	\N	2010-09-25 20:39:31-07
9	difficulty:easy	\N	2010-09-25 20:39:31-07
10	polar	\N	2010-09-25 20:39:31-07
11	nonlinear ODE	\N	2010-09-25 20:39:31-07
12	Bernoulli ODE	\N	2010-09-25 20:39:31-07
13	teacher:Mr. Bigler	\N	2010-09-25 20:39:31-07
14	class:MATH-40	\N	2010-09-25 20:39:31-07
15	in class example	\N	2010-09-25 20:39:31-07
16	IVP	\N	2010-09-25 20:39:31-07
17	exact ODE	\N	2010-09-25 20:39:31-07
18	physics	\N	2010-09-25 20:39:31-07
19	E&M	\N	2010-09-25 20:39:31-07
20	class:PHYS-42	\N	2010-09-25 20:39:31-07
21	difficulty:medium	\N	2010-09-25 20:39:31-07
22	trig	\N	2010-09-25 20:39:31-07
23	partial fractions	\N	2010-09-25 20:39:31-07
24	difficulty:hard	\N	2010-09-25 20:39:31-07
25	polynomial long division	\N	2010-09-25 20:39:31-07
26	separable IVP	\N	2010-09-25 20:39:31-07
27	table method of integration	\N	2010-09-25 20:39:31-07
28	linear	\N	2010-09-25 20:39:31-07
29	clever substitution	\N	2010-09-25 20:39:31-07
30	ultimate method	\N	2010-09-25 20:39:31-07
31	orthogonal trajectories	\N	2010-09-25 20:39:31-07
32	falling bodies	\N	2010-09-25 20:39:31-07
33	exponential growth	\N	2010-09-25 20:39:31-07
34	exponential decay	\N	2010-09-25 20:39:31-07
35	mixture	\N	2010-09-25 20:39:31-07
36	linear ODE	\N	2010-09-25 20:39:31-07
37	integration	\N	2010-09-25 20:39:31-07
38	Newton	\N	2010-09-25 20:39:31-07
39	class:PHYS-41	\N	2010-09-25 20:39:31-07
\.


--
-- Data for Name: testproblems; Type: TABLE DATA; Schema: public; Owner: jeri
--

COPY testproblems (test_id, problem_id, seq, points) FROM stdin;
\.


--
-- Data for Name: tests; Type: TABLE DATA; Schema: public; Owner: jeri
--

COPY tests (test_id, author, dsc, create_date, finished) FROM stdin;
2	\N	my first test	2010-09-25 20:45:05-07	f
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: jeri
--

COPY users (user_id, username, password, role, first_name, last_name, address, phone, email) FROM stdin;
\.


--
-- Name: assignedtests_ass_test_id_key; Type: CONSTRAINT; Schema: public; Owner: jeri; Tablespace: 
--

ALTER TABLE ONLY assignedtests
    ADD CONSTRAINT assignedtests_ass_test_id_key UNIQUE (ass_test_id);


--
-- Name: assignedtests_pkey; Type: CONSTRAINT; Schema: public; Owner: jeri; Tablespace: 
--

ALTER TABLE ONLY assignedtests
    ADD CONSTRAINT assignedtests_pkey PRIMARY KEY (ass_test_id, test_id, user_id);


--
-- Name: problems_pkey; Type: CONSTRAINT; Schema: public; Owner: jeri; Tablespace: 
--

ALTER TABLE ONLY problems
    ADD CONSTRAINT problems_pkey PRIMARY KEY (problem_id);


--
-- Name: problems_uuid_key; Type: CONSTRAINT; Schema: public; Owner: jeri; Tablespace: 
--

ALTER TABLE ONLY problems
    ADD CONSTRAINT problems_uuid_key UNIQUE (uuid);


--
-- Name: problemscores_pkey; Type: CONSTRAINT; Schema: public; Owner: jeri; Tablespace: 
--

ALTER TABLE ONLY problemscores
    ADD CONSTRAINT problemscores_pkey PRIMARY KEY (pscore_id);


--
-- Name: problemtags_pkey; Type: CONSTRAINT; Schema: public; Owner: jeri; Tablespace: 
--

ALTER TABLE ONLY problemtags
    ADD CONSTRAINT problemtags_pkey PRIMARY KEY (problem_id, tag_id);


--
-- Name: tags_pkey; Type: CONSTRAINT; Schema: public; Owner: jeri; Tablespace: 
--

ALTER TABLE ONLY tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (tag_id);


--
-- Name: testproblems_pkey; Type: CONSTRAINT; Schema: public; Owner: jeri; Tablespace: 
--

ALTER TABLE ONLY testproblems
    ADD CONSTRAINT testproblems_pkey PRIMARY KEY (test_id, problem_id, seq);


--
-- Name: tests_pkey; Type: CONSTRAINT; Schema: public; Owner: jeri; Tablespace: 
--

ALTER TABLE ONLY tests
    ADD CONSTRAINT tests_pkey PRIMARY KEY (test_id);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: jeri; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: users_username_key; Type: CONSTRAINT; Schema: public; Owner: jeri; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: assignedtests_test_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jeri
--

ALTER TABLE ONLY assignedtests
    ADD CONSTRAINT assignedtests_test_id_fkey FOREIGN KEY (test_id) REFERENCES tests(test_id);


--
-- Name: assignedtests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jeri
--

ALTER TABLE ONLY assignedtests
    ADD CONSTRAINT assignedtests_user_id_fkey FOREIGN KEY (user_id) REFERENCES users(user_id);


--
-- Name: problemscores_ass_test_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jeri
--

ALTER TABLE ONLY problemscores
    ADD CONSTRAINT problemscores_ass_test_id_fkey FOREIGN KEY (ass_test_id) REFERENCES assignedtests(ass_test_id);


--
-- Name: problemscores_problem_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jeri
--

ALTER TABLE ONLY problemscores
    ADD CONSTRAINT problemscores_problem_id_fkey FOREIGN KEY (problem_id) REFERENCES problems(problem_id);


--
-- Name: problemscores_test_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jeri
--

ALTER TABLE ONLY problemscores
    ADD CONSTRAINT problemscores_test_id_fkey FOREIGN KEY (test_id) REFERENCES tests(test_id);


--
-- Name: problemscores_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jeri
--

ALTER TABLE ONLY problemscores
    ADD CONSTRAINT problemscores_user_id_fkey FOREIGN KEY (user_id) REFERENCES users(user_id);


--
-- Name: problemtags_problem_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jeri
--

ALTER TABLE ONLY problemtags
    ADD CONSTRAINT problemtags_problem_id_fkey FOREIGN KEY (problem_id) REFERENCES problems(problem_id);


--
-- Name: problemtags_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jeri
--

ALTER TABLE ONLY problemtags
    ADD CONSTRAINT problemtags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES tags(tag_id);


--
-- Name: testproblems_problem_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jeri
--

ALTER TABLE ONLY testproblems
    ADD CONSTRAINT testproblems_problem_id_fkey FOREIGN KEY (problem_id) REFERENCES problems(problem_id);


--
-- Name: testproblems_test_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: jeri
--

ALTER TABLE ONLY testproblems
    ADD CONSTRAINT testproblems_test_id_fkey FOREIGN KEY (test_id) REFERENCES tests(test_id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

