--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

--
-- Name: plpgsql; Type: PROCEDURAL LANGUAGE; Schema: -; Owner: -
--

CREATE OR REPLACE PROCEDURAL LANGUAGE plpgsql;


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: assignedtests; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE assignedtests (
    assignedtest_id integer NOT NULL,
    test_id integer NOT NULL,
    user_id integer NOT NULL,
    actual_start_time timestamp(0) with time zone,
    actual_end_time timestamp(0) with time zone,
    allowed_start_time timestamp(0) with time zone,
    allowed_max_end_time timestamp(0) with time zone
);


--
-- Name: TABLE assignedtests; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE assignedtests IS 'An instance in which a test is assigned and allowed to be taken.';


--
-- Name: assignedtests_assignedtest_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE assignedtests_assignedtest_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: assignedtests_assignedtest_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE assignedtests_assignedtest_id_seq OWNED BY assignedtests.assignedtest_id;


--
-- Name: config; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE config (
    admin_email text
);


--
-- Name: TABLE config; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE config IS 'Global configuration options.';


--
-- Name: problems; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE problems (
    problem_id integer NOT NULL,
    short_desc text NOT NULL,
    question text NOT NULL,
    answer text NOT NULL,
    nworklines integer DEFAULT 4 NOT NULL,
    par_time interval DEFAULT '00:05:00'::interval NOT NULL,
    uuid text NOT NULL,
    ref text,
    author text,
    create_date timestamp(0) with time zone DEFAULT now() NOT NULL
);


--
-- Name: COLUMN problems.short_desc; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN problems.short_desc IS 'A short description (1 line) of the problem.';


--
-- Name: COLUMN problems.par_time; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN problems.par_time IS 'The amount of time it should take to answer the question.  "par" is lingo from golf.';


--
-- Name: COLUMN problems.uuid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN problems.uuid IS 'A unique identifier of this problem.  Used to prevent duplication (loading of the same problem twice).';


--
-- Name: COLUMN problems.ref; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN problems.ref IS 'reference: A description of who created this problem and where it came from.';


--
-- Name: problems_problem_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE problems_problem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: problems_problem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE problems_problem_id_seq OWNED BY problems.problem_id;


--
-- Name: problemscores; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE problemscores (
    pscore_id integer NOT NULL,
    test_id integer,
    problem_id integer,
    user_id integer,
    assignedtest_id integer,
    start_t timestamp(0) with time zone NOT NULL,
    end_t timestamp(0) with time zone NOT NULL,
    score integer
);


--
-- Name: problemscores_pscore_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE problemscores_pscore_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: problemscores_pscore_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE problemscores_pscore_id_seq OWNED BY problemscores.pscore_id;


--
-- Name: problemtags; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE problemtags (
    pt_id integer NOT NULL,
    problem_id integer NOT NULL,
    tag text NOT NULL
);


--
-- Name: problemtags_pt_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE problemtags_pt_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: problemtags_pt_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE problemtags_pt_id_seq OWNED BY problemtags.pt_id;


--
-- Name: testproblems; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE testproblems (
    tp_id integer NOT NULL,
    test_id integer NOT NULL,
    problem_id integer NOT NULL,
    "order" integer DEFAULT 1 NOT NULL,
    points integer DEFAULT 1 NOT NULL
);


--
-- Name: testproblems_tp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE testproblems_tp_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: testproblems_tp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE testproblems_tp_id_seq OWNED BY testproblems.tp_id;


--
-- Name: tests; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE tests (
    test_id integer NOT NULL,
    author integer,
    dsc text,
    create_date timestamp(0) with time zone DEFAULT now() NOT NULL,
    finished boolean DEFAULT false NOT NULL,
    date date DEFAULT ('now'::text)::date NOT NULL
);


--
-- Name: TABLE tests; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE tests IS 'A test definition.';


--
-- Name: COLUMN tests.dsc; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN tests.dsc IS 'A description of this test (e.g. "MATH-40 Fall 2010; Mr Bigler.")';


--
-- Name: COLUMN tests.finished; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN tests.finished IS 'A finished test should not be further modified.';


--
-- Name: COLUMN tests.date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN tests.date IS 'date to display on a test';


--
-- Name: tests_test_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE tests_test_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tests_test_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE tests_test_id_seq OWNED BY tests.test_id;


--
-- Name: testscores; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW testscores AS
    SELECT problemscores.test_id, problemscores.user_id, problemscores.assignedtest_id, sum(problemscores.score) AS score FROM problemscores GROUP BY problemscores.test_id, problemscores.user_id, problemscores.assignedtest_id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE users (
    user_id integer NOT NULL,
    username text NOT NULL,
    password text NOT NULL,
    role text,
    first_name text,
    last_name text,
    address text,
    phone text,
    email text
);


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE users_user_id_seq OWNED BY users.user_id;


--
-- Name: assignedtest_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE assignedtests ALTER COLUMN assignedtest_id SET DEFAULT nextval('assignedtests_assignedtest_id_seq'::regclass);


--
-- Name: problem_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE problems ALTER COLUMN problem_id SET DEFAULT nextval('problems_problem_id_seq'::regclass);


--
-- Name: pscore_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE problemscores ALTER COLUMN pscore_id SET DEFAULT nextval('problemscores_pscore_id_seq'::regclass);


--
-- Name: pt_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE problemtags ALTER COLUMN pt_id SET DEFAULT nextval('problemtags_pt_id_seq'::regclass);


--
-- Name: tp_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE testproblems ALTER COLUMN tp_id SET DEFAULT nextval('testproblems_tp_id_seq'::regclass);


--
-- Name: test_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE tests ALTER COLUMN test_id SET DEFAULT nextval('tests_test_id_seq'::regclass);


--
-- Name: user_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE users ALTER COLUMN user_id SET DEFAULT nextval('users_user_id_seq'::regclass);


--
-- Name: assignedtests_assignedtest_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY assignedtests
    ADD CONSTRAINT assignedtests_assignedtest_id_key UNIQUE (assignedtest_id);


--
-- Name: assignedtests_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY assignedtests
    ADD CONSTRAINT assignedtests_pkey PRIMARY KEY (assignedtest_id, test_id, user_id);


--
-- Name: problems_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY problems
    ADD CONSTRAINT problems_pkey PRIMARY KEY (problem_id);


--
-- Name: problems_uuid_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY problems
    ADD CONSTRAINT problems_uuid_key UNIQUE (uuid);


--
-- Name: problemscores_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY problemscores
    ADD CONSTRAINT problemscores_pkey PRIMARY KEY (pscore_id);


--
-- Name: problemtags_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY problemtags
    ADD CONSTRAINT problemtags_pkey PRIMARY KEY (pt_id);


--
-- Name: testproblems_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY testproblems
    ADD CONSTRAINT testproblems_pkey PRIMARY KEY (tp_id);


--
-- Name: tests_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY tests
    ADD CONSTRAINT tests_pkey PRIMARY KEY (test_id);


--
-- Name: unique_problem_tag; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY problemtags
    ADD CONSTRAINT unique_problem_tag UNIQUE (problem_id, tag);


--
-- Name: unique_test_problem; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY testproblems
    ADD CONSTRAINT unique_test_problem UNIQUE (test_id, problem_id);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: users_username_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: assignedtests_test_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY assignedtests
    ADD CONSTRAINT assignedtests_test_id_fkey FOREIGN KEY (test_id) REFERENCES tests(test_id);


--
-- Name: assignedtests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY assignedtests
    ADD CONSTRAINT assignedtests_user_id_fkey FOREIGN KEY (user_id) REFERENCES users(user_id);


--
-- Name: problemscores_assignedtest_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY problemscores
    ADD CONSTRAINT problemscores_assignedtest_id_fkey FOREIGN KEY (assignedtest_id) REFERENCES assignedtests(assignedtest_id);


--
-- Name: problemscores_problem_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY problemscores
    ADD CONSTRAINT problemscores_problem_id_fkey FOREIGN KEY (problem_id) REFERENCES problems(problem_id);


--
-- Name: problemscores_test_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY problemscores
    ADD CONSTRAINT problemscores_test_id_fkey FOREIGN KEY (test_id) REFERENCES tests(test_id);


--
-- Name: problemscores_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY problemscores
    ADD CONSTRAINT problemscores_user_id_fkey FOREIGN KEY (user_id) REFERENCES users(user_id);


--
-- Name: problemtags_problem_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY problemtags
    ADD CONSTRAINT problemtags_problem_id_fkey FOREIGN KEY (problem_id) REFERENCES problems(problem_id);


--
-- Name: testproblems_problem_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY testproblems
    ADD CONSTRAINT testproblems_problem_id_fkey FOREIGN KEY (problem_id) REFERENCES problems(problem_id);


--
-- Name: testproblems_test_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY testproblems
    ADD CONSTRAINT testproblems_test_id_fkey FOREIGN KEY (test_id) REFERENCES tests(test_id);


--
-- Name: public; Type: ACL; Schema: -; Owner: -
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: problems; Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON TABLE problems FROM PUBLIC;
REVOKE ALL ON TABLE problems FROM jeri;
GRANT ALL ON TABLE problems TO jeri;
GRANT ALL ON TABLE problems TO "www-data";


--
-- Name: problems_problem_id_seq; Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON SEQUENCE problems_problem_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE problems_problem_id_seq FROM jeri;
GRANT ALL ON SEQUENCE problems_problem_id_seq TO jeri;
GRANT ALL ON SEQUENCE problems_problem_id_seq TO "www-data";


--
-- Name: problemtags; Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON TABLE problemtags FROM PUBLIC;
REVOKE ALL ON TABLE problemtags FROM jeri;
GRANT ALL ON TABLE problemtags TO jeri;
GRANT ALL ON TABLE problemtags TO "www-data";


--
-- Name: problemtags_pt_id_seq; Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON SEQUENCE problemtags_pt_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE problemtags_pt_id_seq FROM jeri;
GRANT ALL ON SEQUENCE problemtags_pt_id_seq TO jeri;
GRANT ALL ON SEQUENCE problemtags_pt_id_seq TO "www-data";


--
-- Name: testproblems; Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON TABLE testproblems FROM PUBLIC;
REVOKE ALL ON TABLE testproblems FROM jeri;
GRANT ALL ON TABLE testproblems TO jeri;
GRANT ALL ON TABLE testproblems TO "www-data";


--
-- Name: testproblems_tp_id_seq; Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON SEQUENCE testproblems_tp_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE testproblems_tp_id_seq FROM jeri;
GRANT ALL ON SEQUENCE testproblems_tp_id_seq TO jeri;
GRANT ALL ON SEQUENCE testproblems_tp_id_seq TO "www-data";


--
-- Name: tests; Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON TABLE tests FROM PUBLIC;
REVOKE ALL ON TABLE tests FROM jeri;
GRANT ALL ON TABLE tests TO jeri;
GRANT ALL ON TABLE tests TO "www-data";


--
-- Name: tests_test_id_seq; Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON SEQUENCE tests_test_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE tests_test_id_seq FROM jeri;
GRANT ALL ON SEQUENCE tests_test_id_seq TO jeri;
GRANT ALL ON SEQUENCE tests_test_id_seq TO "www-data";


--
-- PostgreSQL database dump complete
--

