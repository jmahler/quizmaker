--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

--
-- Name: plpgsql; Type: PROCEDURAL LANGUAGE; Schema: -; Owner: -
--

CREATE OR REPLACE PROCEDURAL LANGUAGE plpgsql;


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: assignedtests; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE assignedtests (
    assignedtest_id integer NOT NULL,
    test_id integer NOT NULL,
    user_id integer NOT NULL,
    actual_start_time timestamp(0) with time zone,
    actual_end_time timestamp(0) with time zone,
    allowed_start_time timestamp(0) with time zone,
    allowed_max_end_time timestamp(0) with time zone
);


--
-- Name: TABLE assignedtests; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE assignedtests IS 'An instance in which a test is assigned and allowed to be taken.';


--
-- Name: assignedtests_assignedtest_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE assignedtests_assignedtest_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: assignedtests_assignedtest_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE assignedtests_assignedtest_id_seq OWNED BY assignedtests.assignedtest_id;


--
-- Name: assignedtests_assignedtest_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('assignedtests_assignedtest_id_seq', 1, false);


--
-- Name: config; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE config (
    admin_email text
);


--
-- Name: TABLE config; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE config IS 'Global configuration options.';


--
-- Name: problems; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE problems (
    problem_id integer NOT NULL,
    short_desc text NOT NULL,
    question text NOT NULL,
    answer text NOT NULL,
    nworklines integer DEFAULT 4 NOT NULL,
    par_time interval DEFAULT '00:05:00'::interval NOT NULL,
    uuid text NOT NULL,
    ref text,
    author text,
    create_date timestamp(0) with time zone DEFAULT now() NOT NULL
);


--
-- Name: COLUMN problems.short_desc; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN problems.short_desc IS 'A short description (1 line) of the problem.';


--
-- Name: COLUMN problems.par_time; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN problems.par_time IS 'The amount of time it should take to answer the question.  "par" is lingo from golf.';


--
-- Name: COLUMN problems.uuid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN problems.uuid IS 'A unique identifier of this problem.  Used to prevent duplication (loading of the same problem twice).';


--
-- Name: COLUMN problems.ref; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN problems.ref IS 'reference: A description of who created this problem and where it came from.';


--
-- Name: problems_problem_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE problems_problem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: problems_problem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE problems_problem_id_seq OWNED BY problems.problem_id;


--
-- Name: problems_problem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('problems_problem_id_seq', 25, true);


--
-- Name: problemscores; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE problemscores (
    pscore_id integer NOT NULL,
    test_id integer,
    problem_id integer,
    user_id integer,
    assignedtest_id integer,
    start_t timestamp(0) with time zone NOT NULL,
    end_t timestamp(0) with time zone NOT NULL,
    score integer
);


--
-- Name: problemscores_pscore_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE problemscores_pscore_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: problemscores_pscore_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE problemscores_pscore_id_seq OWNED BY problemscores.pscore_id;


--
-- Name: problemscores_pscore_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('problemscores_pscore_id_seq', 1, false);


--
-- Name: problemtags; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE problemtags (
    pt_id integer NOT NULL,
    problem_id integer NOT NULL,
    tag text NOT NULL
);


--
-- Name: problemtags_pt_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE problemtags_pt_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: problemtags_pt_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE problemtags_pt_id_seq OWNED BY problemtags.pt_id;


--
-- Name: problemtags_pt_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('problemtags_pt_id_seq', 123, true);


--
-- Name: testproblems; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE testproblems (
    tp_id integer NOT NULL,
    test_id integer NOT NULL,
    problem_id integer NOT NULL,
    "order" integer DEFAULT 1 NOT NULL,
    points integer DEFAULT 1 NOT NULL
);


--
-- Name: testproblems_tp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE testproblems_tp_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: testproblems_tp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE testproblems_tp_id_seq OWNED BY testproblems.tp_id;


--
-- Name: testproblems_tp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('testproblems_tp_id_seq', 1, false);


--
-- Name: tests; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE tests (
    test_id integer NOT NULL,
    author integer,
    dsc text,
    create_date timestamp(0) with time zone DEFAULT now() NOT NULL,
    finished boolean DEFAULT false NOT NULL,
    date date DEFAULT ('now'::text)::date NOT NULL
);


--
-- Name: TABLE tests; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE tests IS 'A test definition.';


--
-- Name: COLUMN tests.dsc; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN tests.dsc IS 'A description of this test (e.g. "MATH-40 Fall 2010; Mr Bigler.")';


--
-- Name: COLUMN tests.finished; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN tests.finished IS 'A finished test should not be further modified.';


--
-- Name: COLUMN tests.date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN tests.date IS 'date to display on a test';


--
-- Name: tests_test_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE tests_test_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tests_test_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE tests_test_id_seq OWNED BY tests.test_id;


--
-- Name: tests_test_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('tests_test_id_seq', 1, false);


--
-- Name: testscores; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW testscores AS
    SELECT problemscores.test_id, problemscores.user_id, problemscores.assignedtest_id, sum(problemscores.score) AS score FROM problemscores GROUP BY problemscores.test_id, problemscores.user_id, problemscores.assignedtest_id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE users (
    user_id integer NOT NULL,
    username text NOT NULL,
    password text NOT NULL,
    role text,
    first_name text,
    last_name text,
    address text,
    phone text,
    email text
);


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE users_user_id_seq OWNED BY users.user_id;


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('users_user_id_seq', 1, false);


--
-- Name: assignedtest_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE assignedtests ALTER COLUMN assignedtest_id SET DEFAULT nextval('assignedtests_assignedtest_id_seq'::regclass);


--
-- Name: problem_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE problems ALTER COLUMN problem_id SET DEFAULT nextval('problems_problem_id_seq'::regclass);


--
-- Name: pscore_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE problemscores ALTER COLUMN pscore_id SET DEFAULT nextval('problemscores_pscore_id_seq'::regclass);


--
-- Name: pt_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE problemtags ALTER COLUMN pt_id SET DEFAULT nextval('problemtags_pt_id_seq'::regclass);


--
-- Name: tp_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE testproblems ALTER COLUMN tp_id SET DEFAULT nextval('testproblems_tp_id_seq'::regclass);


--
-- Name: test_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE tests ALTER COLUMN test_id SET DEFAULT nextval('tests_test_id_seq'::regclass);


--
-- Name: user_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE users ALTER COLUMN user_id SET DEFAULT nextval('users_user_id_seq'::regclass);


--
-- Data for Name: assignedtests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY assignedtests (assignedtest_id, test_id, user_id, actual_start_time, actual_end_time, allowed_start_time, allowed_max_end_time) FROM stdin;
\.


--
-- Data for Name: config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY config (admin_email) FROM stdin;
\.


--
-- Data for Name: problems; Type: TABLE DATA; Schema: public; Owner: -
--

COPY problems (problem_id, short_desc, question, answer, nworklines, par_time, uuid, ref, author, create_date) FROM stdin;
1	Derive formula for the arc length using the Pythagorean Theorem.	Use the pythagorean theorem ($a^2 + b^2 = c^2$) to derive the\nformula for calculating the arc length.\n	The goal is sum up all the lengths of the hypotenuses as either\nx (or y) gets infinitely small. In this answer it will be over $x$.\n\\begin{align*}\n    a^2 + b^2 &= c^2 \\\\\n    dS^2 &= dx^2 + dy^2 \\\\\n    \\sqrt{\\frac{dL^2}{dx^2}} &= \\sqrt{1 + \\frac{dy^2}{dx^2}} \\\\\n    \\frac{dL}{dx} &= \\sqrt{1 + \\frac{dy^2}{dx^2}} \\\\\n    dL &= \\sqrt{1 + \\frac{dy^2}{dx^2}} \\;\\; dx \\\\\n    \\int dL &= \\int_{a}^{b} \\sqrt{1 + \\Big( \\frac{dy}{dx} \\Big)^2} \\;\\; dx \\\\\n    L &= \\int_{a}^{b} \\sqrt{1 + \\Big( \\frac{dy}{dx}\\Big)^2} \\;\\; dx\n\\end{align*}\n	4	00:05:00	[jmm] Wed, 15 Sep 2010 21:17:42 -0700	This example is commonly given in a Calculus 2 (MATH-31) class.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
2	Devise the formula for the area of a circle.	Devise the formula for the area of a circle.\n(HINT: use polar coordinates)\n	Using a double integral and polar coordinates sum the area from the\nradius from $0$ to $r$ and then sum this over all the angles $0$ to $\\theta$.\n\\begin{align*}\n    A &= \\int_0^{2 \\pi} \\int_0^r r \\; dr \\; d\\theta \\\\\n      &= \\int_0^{2 \\pi} \\frac{r^2}{2} \\; d\\theta \\\\\n      &= \\int_0^{2 \\pi} \\frac{2 \\pi r^2}{2} \\\\\n    A &= \\pi \\cdot r^2\n\\end{align*}\n\nAn alternative is to integrate over half the angle and then double it.\n\\begin{align*}\n    A &= 2 \\cdot \\int_0^{\\pi} \\int_0^r r \\; dr \\; d\\theta \\\\\n      &= 2 \\cdot \\int_0^{\\pi} \\Big[ \\frac{r^2}{2} \\Big]_0^r \\; d\\theta \\\\\n      &= 2 \\cdot \\int_0^{\\pi} \\frac{r^2}{2} \\; d\\theta \\\\\n      &= 2 \\cdot \\int_0^{\\pi} \\frac{r^2}{2} \\cdot \\pi \\\\\n    A &= \\pi \\cdot r^2\n\\end{align*}\n	4	00:05:00	[jmm] Thu, 16 Sep 2010 08:59:22 -0700	This example is commonly given in a Calculus 2 (MATH-31) class.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
3	Solve the ODE: y' + y = x*y^3	Solve the ODE:\n\\begin{align*}\n    y' + y &= x \\cdot y^3\n\\end{align*}\n	Notice that the equation is nonlinear because of $y^3$ therefore\nit might be solved as a Bernoulli Differential Equation.\n\nFollow the steps for solving a Bernoulli Differential Equation.\n\nMultiply by $y^{-3}$ to eliminate $y^3$.\n\n\\begin{align*}\n    y' \\cdot y^{-3} + y^{-2} &= x\n\\end{align*}\n\nLet $z = y^{1 - n} = y^{1 - 3} = y^{-2}$.\n\\begin{align*}\n    z &= y^{-2} \\\\\n    z' &= -2 \\cdot y^{-3} \\cdot y'\n\\end{align*}\n\nSubstitute $z$ in to the original equation:\n\\begin{align*}\n    -\\frac{1}{2} \\cdot z' + z &= x\n\\end{align*}\n\nNow it can be solved as a linear ODE.\n\n\\begin{align*}\n    y' + P(x) \\cdot y &= Q(x) \\\\\n    z' - 2 \\cdot z &= -2 \\cdot x\n\\end{align*}\n\n\\begin{align*}\n    \\mu &= e^{\\int P(x) dx} \\\\\n    &= e^{\\int -2 dx} \\\\\n    &= e^{-2 x}\n\\end{align*}\n\nMultiply $\\mu$ by the linear equation, find the derivative (and check).\n\\begin{align*}\n    e^{-2 x} \\cdot z' - e^{-2 x} \\cdot 2 z &= -e^{-2 x} \\cdot 2 x \\\\\n    \\frac{d}{dx} \\Big[ e^{-2 x} z \\Big] &= -e^{-2 x} 2 x  & \\mbox{(checked OK)}\n\\end{align*}\n\nIntegrate (hint: use the table method).\n\\begin{align*}\n    \\int \\frac{d}{dx} \\Big[ e^{-2 x} z \\Big] &= \\int -e^{-2 x} 2 x \\\\\n    e^{-2 x} z  &= x e^{-2 x} + \\frac{1}{2} e^{-2 x} + C \\\\\n    z &= x + \\frac{1}{2} + C e^{2 x}\n\\end{align*}\n\nSubstitute for $z$ the original equation ($z = y^{-2}$).\n\\begin{align*}\n    y^{-2} &= x + \\frac{1}{2} + C e^{2 x} \\\\\n    \\frac{1}{y^{2}} &= \\frac{2 x + 1 + C e^{2 x} 2}{2} \\\\\n    y^2 &= \\frac{2}{2 x + 1 + 2 C e^{2 x}} \\\\\n    y^2 &= \\frac{4}{4 x + 2 + 4 C e^{2 x}} \\\\\n    y &= \\frac{2}{\\sqrt{4 x + 2 + 4 C e^{2 x}}}\n\\end{align*}\n\nThe final answer is:\n\\begin{align*}\n    y &= \\frac{2}{\\sqrt{4 x + 2 + 4 C e^{2 x}}}\n\\end{align*}\n\nAn alternative solution could have combined all the components related\nto $C$.\n\\begin{align*}\n    y &= \\frac{2}{\\sqrt{4 x + 2 + C}}\n\\end{align*}\n	4	00:03:00	Tue, 07 Sep 2010 16:29:03 -0700	An example given in class (MATH-40) taught by Mr Bigler at Butte Community College on 2010-Sep-01.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
4	Solve the ODE: y' - 2y/x = -x^2 * y^2	Solve the ODE:\n\\begin{align*}\n    y' - \\frac{2 y}{x} = -x^2 \\cdot y^2\n\\end{align*}\n	Notice that the equation is nonlinear because of $y^2$, therefore\nit might be solved as a Bernoulli Differential Equation.\n\nFollow the steps for solving a Bernoulli Differential Equation.\n\nMultiply by $y^{-2}$ to eliminate $y^2$.\n\n\\begin{align*}\n    y' \\cdot y^{-2} - \\frac{2}{x} \\cdot y^{-1} &= -x^2\n\\end{align*}\n\nLet $z = y^{1 - n} = y^{1 - 2} = y^{-1}$.\n\\begin{align*}\n    z &= y^{-1} \\\\\n    z' &= -y^{-2} \\cdot y'\n\\end{align*}\n\nSubstitute $z$ in to the original equation:\n\\begin{align*}\n    -z' - \\frac{2}{x} \\cdot z = -x^2 \\\\\n    z' + \\frac{2}{x} \\cdot z = x^2\n\\end{align*}\n\nNow it can be solved as a linear ODE.\n\n\\begin{align*}\n    y' + P(x) \\cdot y &= Q(x) \\\\\n    z' + \\frac{2}{x} \\cdot z &= x^2\n\\end{align*}\n\n\\begin{align*}\n    \\mu &= e^{\\int P(x) dx} \\\\\n    &= e^{\\int \\frac{2}{x} dx} \\\\\n    &= e^{2 \\ln |x|} \\\\\n    &= x^2\n\\end{align*}\n\nMultiply $\\mu$ by the linear equation, find the derivative (and check).\n\\begin{align*}\n    x^2 \\cdot z' - 2 \\cdot x \\cdot z &= x^4 \\\\\n    \\frac{d}{dx} \\Big[ x^2 \\cdot z \\Big] &= x^4  & \\mbox{(checked OK)}\n\\end{align*}\n\nIntegrate.\n\\begin{align*}\n    \\int \\frac{d}{dx} \\Big[ x^2 \\cdot z \\Big] &= x^4 \\\\\n    x^2 \\cdot z &= \\frac{x^5}{5} + C\n\\end{align*}\n\nSubstitute for $z$ the original equation ($z = y^{-1}$).\n\\begin{align*}\n    \\frac{x^2}{y} &= \\frac{x^5}{5} + C \\\\\n    \\frac{1}{y} &= \\frac{x^3}{5} + \\frac{C}{x^2} \\\\\n    \\frac{1}{y} &= \\frac{x^5 + 5 \\cdot C}{5 x^2} \\\\\n    y &= \\frac{5 x^2}{x^5 + 5 C} \\\\\n    y &= \\frac{x^2}{\\frac{x^5}{5} + C}\n\\end{align*}\n\nThe final answer is:\n\\begin{align*}\n    y &= \\frac{x^2}{\\frac{x^5}{5} + C}\n\\end{align*}\n	4	00:07:00	Tue, 07 Sep 2010 16:44:14 -0700	An example taken from Wikipedia [http://en.wikipedia.org/wiki/Bernoulli_differential_equation] on 2010-Sep-07	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
5	Solve the IVP: y' - y/2x = x * y^-3; y(1) = 2	Solve the IVP:\n\\begin{align*}\n    y' - \\frac{y}{2 x} = x \\cdot y^{-3} \\; ; \\;\\;\\; y(1) = 2\n\\end{align*}\n	Notice that the equation is nonlinear because of $y^{-3}$, therefore\nit might be solved as a Bernoulli Differential Equation.\n\nFollow the steps for solving a Bernoulli Differential Equation.\n\nMultiply by $y^{3}$ to eliminate $y^{-3}$.\n\n\\begin{align*}\n    y' \\cdot y^{3} - \\frac{1}{2 x} \\cdot y^{4} &= x\n\\end{align*}\n\nLet $z = y^{1 - n} = y^{1 - (-3)} = y^{4}$.\n\\begin{align*}\n    z &= y^{4} \\\\\n    z' &= 4 \\cdot y^{3} \\cdot y'\n\\end{align*}\n\nSubstitute $z$ in to the original equation:\n\\begin{align*}\n    \\frac{1}{4} \\cdot z' - \\frac{1}{2x} \\cdot z = x\n\\end{align*}\n\nNow it can be solved as a linear ODE.\n\n\\begin{align*}\n    y' + P(x) \\cdot y &= Q(x) \\\\\n    z' - \\frac{2}{x} \\cdot z &= 4 \\cdot x\n\\end{align*}\n\nFind the integrating factor ($\\mu$).\n\\begin{align*}\n    \\mu &= e^{\\int P(x) dx} \\\\\n    &= e^{\\int -\\frac{2}{x} dx} \\\\\n    &= e^{-2 \\ln |x|} \\\\\n    &= x^{-2}\n\\end{align*}\n\nMultiply $\\mu$ by the linear equation and find the derivative.\n\\begin{align*}\n    z' \\cdot x^{-2} + 2 \\cdot x^{-3} \\cdot z &= 4 x^{-1} \\\\\n    \\frac{d}{dx} \\Big[ x^{-2} \\cdot z \\Big] &= 4 \\cdot x^{-1}\n\\end{align*}\n\nIntegrate.\n\\begin{align*}\n    \\frac{d}{dx} \\Big[ x^{-2} \\cdot z \\Big] &= 4 \\cdot x^{-1} \\\\\n    z \\cdot x^{-2} &= 4 \\ln|x| + C\n\\end{align*}\n\nSubstitute for $z$ the original equation ($z = y^{4}$).\n\\begin{align*}\n    y^4 \\cdot x^{-2} &= 4 \\ln|x| + C\n\\end{align*}\n\nAt this point the ODE is solved implicitly.\nBut $C$ needs to be found using the initial condition $y(1) = 2$.\nSubstitute the values and solve for $C$.\n\\begin{align*}\n    2^4 &= 1^2 \\cdot 4 \\ln|1| + C \\\\\n    C &= 16 \\\\\n    y^4 \\cdot x^{-2} &= 4 \\ln|x| + 16\n\\end{align*}\n\nThe final answer in implicit form is:\n\\begin{align*}\n    y^4 &= x^2 \\cdot 4 \\ln|x| + 16 x^2\n\\end{align*}\n	4	00:05:00	Tue, 07 Sep 2010 20:38:37 -0700	An example given in class (MATH-40) taught by Mr Bigler at Butte Community College on 2010-Sep-01.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
12	Solve the IVP: x*sin(x)*e^(-y) dx - y dy = 0	Solve the IVP:\n\\begin{align*}\n    x \\cdot \\sin(x) \\cdot e^{-y} \\; dx - y \\; dy &= 0 \\;\\; ; \\; y(0) = 1\n\\end{align*}\n	Separate.\n\\begin{align*}\n    \\int x \\cdot \\sin(x) \\cdot e^{-y} \\; dx &= \\int y \\; dy\n\\end{align*}\n\nUse the table method of integration to integrate each side.\n\\begin{align*}\n    -x \\cdot \\cos(x) + \\sin(x) &= y e^y - e^y + C\n\\end{align*}\n\nSubstitute the initial conditon to find $C$.\n\\begin{align*}\n    0 + 0 &= 1 \\cdot e^1 - e^1 + C \\\\\n    C &= 0\n\\end{align*}\n\n\\begin{align*}\n    -x \\cdot \\cos(x) + \\sin(x) &= y e^y - e^y\n\\end{align*}\n	4	00:10:00	[jmm] Wed, 22 Sep 2010 23:28:25 -0700	Homework problem 10 from the sheet handed out on 8/25/10 in the class (MATH-40) taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
6	Solve the ODE: (xy - 1)dx + (x^2 - xy) dy = 0	Solve the ODE:\n\\begin{align*}\n    (x \\cdot y - 1) \\; dx + (x^2 - x \\cdot y) \\; dy = 0\n\\end{align*}\n	It is not separable and it is not exact (see below) but it is close.\n\\begin{align*}\n    \\frac{\\partial{M}}{\\partial{y}} &= x \\ne \\frac{\\partial{N}}{\\partial{x}}\n        = 2x - y\n\\end{align*}\n\nTry to find a function in terms of $x$ only.\n\\begin{align*}\n    \\frac{ \\frac{\\partial{M}}{\\partial{y}} - \\frac{\\partial{N}}{\\partial{x}} }\n        {N}\n        &= \\frac{x - 2x + y}{x^2 - xy} \\\\\n        &= -\\frac{1}{x}\n\\end{align*}\nA function in terms of $x$ only was found so this can be used to build an\nintegrating factor.\n\n\\begin{align*}\n    \\mu &= e^{\\int -1/x \\; dx} \\\\\n        &= x^{-1}\n\\end{align*}\n\nMultiply the integrating factor by the original equation and then\ncheck to make sure it is now exact.\n\\begin{align*}\n    \\frac{(xy - 1)}{x} \\; dx + \\frac{ (x^2 - xy)}{x} \\; dy &= 0 \\\\\n    y - \\frac{1}{x} \\; dx + (x - y) \\; dy &= 0 \\\\\n    \\frac{\\partial{M}}{\\partial{y}} = 1 &= \\frac{\\partial{N}}{\\partial{x}}\n\\end{align*}\nThe modified equation is exact so now it can be solved normally.\n\nIntegrate each term seperately and then combine unique terms.\n\\begin{align*}\n    \\int \\Big( y - \\frac{1}{x} \\Big) \\; dx &= x y - \\ln|x| \\\\\n    \\int \\Big( x - y \\Big) \\; dy &= x y - \\frac{y^2}{2} \\\\\n    -\\frac{y^2}{2} + x y - \\ln|x| &= C\n\\end{align*}\n	4	00:04:00	[jmm] Tue, 21 Sep 2010 22:26:02 -0700	An example given on 9/13/10 in the class MATH-40 taught\nby Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
7	Solve the ODE: y dx + (x^2 y - x) dy = 0	Solve the ODE:\n\\begin{align*}\n    y \\; dx + (x^2 y - x ) \\; dy = 0\n\\end{align*}\n	It is not separable and it is not exact (see below) but it is close.\n\\begin{align*}\n    \\frac{\\partial{M}}{\\partial{y}} &= 1 \\ne \\frac{\\partial{N}}{\\partial{x}}\n        = 2 x y - 1\n\\end{align*}\n\nTry to find a function in terms of $x$ only.\n\\begin{align*}\n    \\frac{ \\frac{\\partial{M}}{\\partial{y}} - \\frac{\\partial{N}}{\\partial{x}} }\n        {N}\n        &= \\frac{2 - 2 x y}{x^2 y - x} \\\\\n        &= -\\frac{2}{x}\n\\end{align*}\nA function in terms of $x$ only was found so this can be used to build an\nintegrating factor.\n\n\\begin{align*}\n    \\mu &= e^{\\int -2/x \\; dx} \\\\\n        &= x^{-2}\n\\end{align*}\n\nMultiply the integrating factor by the original equation and then\ncheck to make sure it is now exact.\n\\begin{align*}\n    \\frac{y}{x^2} \\; dx + \\frac{ (x^2 y - x)}{x^2} \\; dy &= 0 \\\\\n    \\frac{\\partial{M}}{\\partial{y}} = \\frac{1}{x^2} &= \\frac{\\partial{N}}{\\partial{x}}\n\\end{align*}\nThe modified equation is exact so now it can be solved normally.\n\nIntegrate each term seperately and then combine unique terms.\n\\begin{align*}\n    \\int \\frac{y}{x^2} \\; dx &= -\\frac{y}{x} \\\\\n    \\int \\Big( y - \\frac{1}{x} \\Big) \\; dy &= \\frac{y^2}{2} - \\frac{y}{x} \\\\\n    \\frac{y^2}{2} - \\frac{y}{x} &= C\n\\end{align*}\n	4	00:04:00	[jmm] Tue, 21 Sep 2010 22:57:59 -0700	An example given on 9/13/10 in the class MATH-40 taught\nby Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
8	Show that Gauss's Law is true by calculating the integral.	To find the flux using Gauss's Law it is often not necessary\nto calculate the E field and the area because $q/\\epsilon_0$ can be used.\n\\begin{align*}\n    \\Phi &= \\oint \\vec{E} \\cdot \\vec{dA} = \\frac{q}{\\epsilon_0}\n\\end{align*}\n\nUsing any surface you choose, complete the integral and show that it\ndoes in fact equal $q/\\epsilon_0$.\n	The simplest surface to use is a sphere so that is what will be used here.\n\nThe equation for calculating the electric field using Coulomb's Law.\n\\begin{align*}\n    E = \\frac{k \\cdot Q}{r^2}\n\\end{align*}\n\nThe surface area of a sphere.\n\\begin{align*}\n    A = 4 \\cdot \\pi \\cdot r^2\n\\end{align*}\n\n\\begin{align*}\n    \\Phi &= \\oint E \\cdot dA \\\\\n    &= E \\cdot A \\\\\n    &= \\frac{k \\cdot Q \\cdot 4 \\pi r^2}{r^2} \\\\\n    &= k \\cdot Q \\cdot 4 \\pi\n\\end{align*}\n\nSubstitute for $k$.\n\\begin{align*}\n    k &= \\frac{1}{4 \\pi \\epsilon_0}\n\\end{align*}\n\n\\begin{align*}\n    \\Phi &= k \\cdot Q \\cdot 4 \\pi \\\\\n    &= \\frac{Q \\cdot 4 \\pi}{4 \\pi \\epsilon_0} \\\\\n    &= \\frac{Q}{\\epsilon_0} \\\\\n    &= \\frac{q}{\\epsilon_0}\n\\end{align*}\n\nThis results proves that integrating produces the same result as expected.\n	4	00:05:00	[jmm] Thu, 18 Sep 2010 23:35:43 -0700	A common problem in a Physisc Electricity and Magnetism class.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
9	Solve the ODE: sin(x)*sin(y) dx + cos(x)*cos(y) dy = 0	Solve the ODE:\n\\begin{align*}\n    \\sin(x) \\sin(y) \\; dx + \\cos(x) \\cdot \\cos(y) \\; dy &= 0\n\\end{align*}\n	Separate and integrate.\n\\begin{align*}\n    \\int \\frac{-\\sin(x)}{\\cos(x)} \\; dx &= \\int \\frac{ \\cos(y) }{ \\sin(y) } \\; dy \\\\\n    \\ln|\\cos(x)| &= \\ln|\\sin(y)| + C \\\\\n    \\cos(x) &= \\sin(y) \\cdot C \\\\\n    \\sin(y) &= C \\cdot \\cos(x)\n\\end{align*}\n\nOther slight variations involving $C$ in the answer are also acceptable.\n	4	00:03:00	[jmm] Wed, 22 Sep 2010 16:13:49 -0700	Homework problem 3 from the sheet handed out on 8/25/10 in the class (MATH-40) taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
10	Solve the ODE: dP/dt = a*P - b*P^2	Solve the ODE:\n\\begin{align*}\n    \\frac{dP}{dt} &= a \\cdot P - b \\cdot P^2\n\\end{align*}\n	Separate and integrate.\n\\begin{align*}\n    \\frac{dP}{a \\cdot P - b \\cdot P^2} &= dt\n\\end{align*}\n\nUse partial fractions (not shown) to reduce the equation to\nan integratable form.\n\\begin{align*}\n    \\int dt &= \\int \\Big( \\frac{1/a}{P} + \\frac{b/a}{a - b \\cdot P} \\Big) \\; dP\n\\end{align*}\n\n\\begin{align*}\n    t &= \\frac{1}{a} \\ln|P| - \\frac{1}{a} \\ln|a - b \\cdot P| + C \\\\\n    t \\cdot a + C &= \\ln|P| - \\ln|a - b \\cdot P| \\\\\n    t \\cdot a + C &= \\ln \\Big( \\frac{|P|}{|a - b \\cdot p|} \\Big) \\\\\n    K \\cdot e^{t \\cdot a} &= \\frac{|P|}{|a - b \\cdot P|}\n\\end{align*}\n	4	00:05:00	[jmm] Wed, 22 Sep 2010 16:41:13 -0700	Homework problem 4 from the sheet handed out on 8/25/10 in the class (MATH-40) taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
11	Solve the ODE: (xy + x)dx - (x^2*y^2 + x^2 + y^2 + 1)dy = 0	Solve the ODE:\n\\begin{align*}\n    (xy + x) \\; dx - (x^2 y^2 + x^2 + y^2 + 1) \\; dy &= 0\n\\end{align*}\n	Separate.\n\\begin{align*}\n    (xy + x) \\; dx - (x^2 y^2 + x^2 + y^2 + 1) \\; dy &= 0 \\\\\n    x (y + 1) \\; dx &= x^2 (y^2 + 1) + (y^2 + 1) \\; dy \\\\\n    \\frac{(y+1)}{x} \\; dx &= (y^2 + 1) (x^2 + 1) \\; dy \\\\\n    \\frac{dx}{x(x^2 + 1)} &= \\frac{y^2 + 1}{y + 1} \\; dy\n\\end{align*}\n\nIn it's current form it is difficult to integrate.\nThe left hand side ($dx$) can be reduced using partial fractions.\nAnd the right hand side can be reduced using polynomial long division.\nThe steps are not shown, just the result below.\n\\begin{align*}\n    \\Big( \\frac{1}{x} - \\frac{x}{x^2 + 1} \\Big) \\; dx &= \\Big( y - 1 + \\frac{2}{y+1} \\Big) \\; dy \\\\\n    \\ln|x| - \\frac{1}{2} \\cdot \\ln|x^2 + 1| &= \\frac{y^2}{2} - y + 2 \\cdot \\ln|y + 1| + C \\\\\n    2 \\ln|x| - \\ln|x^2 + 1| &= y^2 - 2 y + 4 \\cdot \\ln|y + 1| + C\n\\end{align*}\n	4	00:10:00	[jmm] Wed, 22 Sep 2010 18:01:09 -0700	Homework problem 5 from the sheet handed out on 8/25/10 in the class (MATH-40) taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
13	Solve the IVP: y' = (cot x)*y + sin(x); y(pi/2) = 0	Solve the IVP:\n\\begin{align*}\n    y' &= (\\cot x) y + \\sin x \\;\\; ; \\; y(\\pi/2) = 0\n\\end{align*}\n	It is not seperable but it does fit in to the linear form ($y' + P(x) y = Q(x)$).\n\\begin{align*}\n    y' - (\\cot x) y &= \\sin x\n\\end{align*}\n\nBuild the integrating factor.\n\\begin{align*}\n    \\mu &= e^{\\int -\\cot x \\; dx} \\\\\n        &= e^{- \\ln|\\sin x|} \\\\\n        &= \\frac{1}{\\sin x}\n\\end{align*}\n\nMultiply $\\mu$ by the equation.\n\\begin{align*}\n    y' \\cdot \\frac{1}{\\sin x} - \\frac{\\cot x}{\\sin x} y &= 1\n\\end{align*}\n\nCheck the derivative and integrate.\n\\begin{align*}\n    \\int \\frac{d}{dx} \\Big[ \\frac{1}{\\sin x} y \\Big] &= \\int 1 \\; dx \\\\\n    \\frac{1}{\\sin x} y &= x + C\n\\end{align*}\n\nSubstitute the initial conditon to find $C$.\n\\begin{align*}\n    \\frac{1}{\\sin(\\pi/2)} \\cdot 0 &= \\frac{\\pi}{2} + C \\\\\n    C &= -\\frac{\\pi}{2}\n\\end{align*}\n\n\\begin{align*}\n    y &= \\sin(x) \\Big( x - \\frac{\\pi}{2} \\Big)\n\\end{align*}\n	4	00:10:00	[jmm] Thu, 23 Sep 2010 09:15:47 -0700	Homework problem 7 from the problems on Pg. 71 of Ordinary Differential Equations by Charles E. Roberts.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
14	Solve the ODE: (x + y) dy = y dx	Solve the ODE\n\\begin{align*}\n    (x + y) \\; dy &= y \\; dx\n\\end{align*}\n	This problem can be solved using the ultimate method or the clever\nsubstitution ($v = y/x$).\n\\begin{align*}\n\\frac{ \\frac{\\partial M}{\\partial y} - \\frac{\\partial N}{\\partial x} }\n    { - M } &= -\\frac{2}{y}\n\\end{align*}\n\n(intermediate steps not shown)\n\n\\begin{align*}\n    \\frac{x}{y} - \\ln|y| = C\n\\end{align*}\n	4	00:10:00	[jmm] Thu, 23 Sep 2010 17:23:52 -0700	Homework problem #16 from sheet handed out on 9/13/10 in the\nclass MATH-40 taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
15	Find the orthogonal trajectory of: y = c*(x + 1/x)	Find the orthogonal trajectories of the family of curves\n\\begin{align*}\n    y &= c \\Big( x + \\frac{1}{x} \\Big)\n\\end{align*}\n	\\begin{align*}\n    y^2 &= -x^2 -2 \\cdot \\ln|x^2 - 1| + C\n\\end{align*}\n	4	00:04:00	[jmm] Tue, 21 Sep 2010 20:13:23 -0700	Homework problem #1 from sheet handed out on 9/17/10 in the\nclass MATH-40 taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
16	4 lbs thrown down 2000 ft ...	An object weighting 4 lb is thrown vertically downward toward the earth\nfrom a height of 2000 ft with an initial velocity of 2 ft/sec.  As it falls\nit is acted upon by air resistance that is numerically equal to $v/2$ (in pounds),\nwhere $v$ is the velocity (in feet per second).\\\\\n\\\\\n(a)  What is the velocity and distance fallen at the end of 1 second? \\\\\n(b)  With what velocity does the object strike the earth?\n	\nUse the equation for the falling bodies and find $k$.\nThen substitute to find the answer.\n\\begin{align*}\n    \\frac{dv}{dt} &= g - \\frac{g}{m} \\cdot k \\cdot v \\\\\n    \\frac{dv}{dt} &= 32 - \\frac{32}{4} \\cdot \\frac{1}{2} \\cdot v \\\\\n    \\frac{dv}{dt} &= 32 - 4 \\cdot v \\\\\n    \\frac{dv}{32 - 4 \\cdot v} &= dt \\\\\n    \\frac{dv}{8 - v} &= 4 \\cdot dt \\\\\n    \\frac{dv}{v - 8} &= -4 \\cdot dt \\\\\n    \\int \\frac{dv}{v - 8} &= \\int -4 \\cdot dt \\\\\n    \\ln |v - 8| &= -4 \\cdot t + C \\\\\n    v - 8 &= e^{-4 \\cdot t} e^{C} \\\\\n    v &= e^{-4 \\cdot t} e^{C} + 8 \\\\\n    2 &= e^{C} + 8 & (v(0) = 2) \\\\\n    K &= -6 \\\\\n    v &= 8 - g \\cdot e^{-4 \\cdot t}\n\\end{align*}\n\nVelocity at 1 second: 7.89 ft/s\n\nBecause the terminal velocity is 8.00 ft/s and it reaches this\nspeed well before 2000 ft the velocity at impact will\nalso be the terminal velocity (8.00 ft/s).\n	4	00:04:00	[jmm] Tue, 21 Sep 2010 20:20:12 -0700	Homework problem #3 from sheet handed out on 9/17/10 in the\nclass MATH-40 taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
17	A mold grows at a rate ...	A mold grows at a rate that is proportional to the amount present.\nIn 24 hours the amount of it has grown from 2 grams to 3 grams.\nHow many grams of it are present at the end of 24 more hours?\n	The rate of change is proportional to the amount present.\n\\begin{align*}\n    & \\frac{dA}{dt} \\propto k \\cdot A\n\\end{align*}\n\nUse the initial conditions to find $k$.\n\\begin{align*}\n    A &= A_0 \\cdot e^{k \\cdot t} \\\\\n    3 &= 2 \\cdot e^{k \\cdot 24} \\\\\n    \\ln(\\frac{3}{2}) &= k \\cdot 24 \\\\\n    k &= \\frac{ \\ln(\\frac{3}{2}) }{24}\n\\end{align*}\n\nSubstitute for time ($t$) and solve for the amount ($A$).\n\\begin{align*}\n    A &= A_0 e^{ \\frac{ \\ln(\\frac{3}{2}) }{24} \\cdot t } \\\\\n      &= A_0 e^{ \\frac{ \\ln(\\frac{3}{2}) }{24} \\cdot 48 } \\\\\n      &= 2 \\cdot e^{2 \\ln(\\frac{3}{2}) } \\\\\n      &= 4.5 \\;\\; \\mbox{grams}\n\\end{align*}\n	4	00:05:00	[jmm] Tue, 21 Sep 2010 20:42:10 -0700	Homework problem #6 from sheet handed out on 9/17/10 in the\nclass MATH-40 taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
19	A tank initially contains 300 gal of brine ...	A tank initially contains 300 gal of brine in which 20 lb of salt is dissolved.\nStarting at t = 0, brine containing 3 lb of salt per gallon flows in to the tank\nat the rate of 3 gal/min.  The mixture is kept uniform by stirring, and the\nwell-stirred mixture leaves the tank at the rate of 5 gal/min.  How much salt\nis in the tank at the end of 15 minutes?\n	Substitute and solve the differential equation. \n\\begin{align*}\n    \\frac{dQ}{dt} &= r_{in} \\cdot c_{in} - r_{out} \\cdot \\frac{Q}{v_o - (r_{out} - r_{in}) t} \\\\\n    Q(t) &= Q_0\n\\end{align*}\n\n(steps not shown)\n\n\\begin{align*}\n    Q = 134 \\;\\; \\mbox{lbs}\n\\end{align*}\n\n	4	00:15:00	[jmm] Tue, 21 Sep 2010 21:18:41 -0700	Homework problem #10 from sheet handed out on 9/17/10 in the\nclass MATH-40 taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
20	Integrate: (x^2 - 1)/(x*(x^2 + 1))	Integrate:\n\\begin{align*}\n    \\int \\frac{x^2 - 1}{x (x^2 + 1)}\n\\end{align*}\n	In its current form it cannot be integrated easily.\nNoticing that the degree of the denominator is greater than the\nnumerator it can likely be reduced using partial fractions.\n\n\\begin{align*}\n    \\frac{x^2 - 1}{x (x^2 + 1)} &= \\frac{A}{x} + \\frac{B x + C}{x^2 + 1} \\\\\n    x^2 - 1 &= A \\cdot (x^2 + 1) + x \\cdot (B x + C) \\\\\n    \\ldots \\\\\n    \\frac{x^2 - 1}{x (x^2 + 1)} &= \\frac{-1}{x} + \\frac{2 x + 0}{x^2 + 1}\n\\end{align*}\n\nNow it is in a form that can be integrated easily.\n\\begin{align*}\n    \\int \\Big( \\frac{-1}{x} + \\frac{2 x + 0}{x^2 + 1} \\Big) \\; dx\n      &= \\frac{1}{x^2} + \\ln|x^2 + 1| + C\n\\end{align*}\n	4	00:03:00	[jmm] 2010-09-19 01	An example made up by the author on 19 Sep 2010.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
21	Derive the kinematic equation for position.	Knowing that acceleration, position, and velocity are related as\n\\begin{align*}\n    a &= \\frac{dv}{dt} \\;\\;\\; [m/s^2] \\\\\n    v &= \\frac{dx}{dt} \\;\\;\\; [m/s]\n\\end{align*}\nderive the kinematic equation that describes the position ($x(x_0, v_0, t, a) \\;\\; [m]$).\n	\\begin{align*}\n    a &= \\frac{dv}{dt} \\;\\;\\; [m/s^2]\n\\end{align*}\n\nSeparate the variables and integrate.\n\n\\begin{align*}\n    \\int a \\; dt &= \\int dv \\\\\n    a \\cdot t &= v + C\n\\end{align*}\n\nTo determine what $C$ should be check the units.\nIn this case the units are $[m/s]$ which means $C$ represents velocity,\nspecifically the initial velocity.\n\n\\begin{align*}\n    a \\cdot t &= v + v_0 \\;\\;\\; [m/s]\n\\end{align*}\n\nSubstitute for velocity ($v$) with $\\frac{dx}{dt}$ then separate\nand integrate.\n\n\\begin{align*}\n    \\frac{dx}{dt} &= a \\cdot t + v_0 \\\\\n    \\int dx &= \\int (a \\cdot t + v_0) dt \\\\\n    x &= \\frac{1}{2} \\cdot a \\cdot t^2 + v_0 \\cdot t + C\n\\end{align*}\n\nDetermine what $C$ should be just like before by checking the units.\n\n\\begin{align*}\n    x_f &= \\frac{1}{2} \\cdot a \\cdot t^2 + v_0 \\cdot t + x_0 \\;\\;\\; [m]\n\\end{align*}\n\nThis final equation determines the position based on acceleration, velocity,\netc.\n	4	00:05:00	[jmm] Thu, 09 Sep 2010 22:03:06 -0700	A common example that is relevant to both a Physics class and\na class in Differential Equations.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
22	Solve: (x^2 + 1)y'' - 2xy' + 2y = 0.	Solve the ODE\n\\begin{align*}\n(x^2 + 1) y'' - 2 x y' + 2 y &= 0\n\\end{align*}\nknowing that one solution is $y = x$.\n	Because we are given one of the solution it is most likely\na Reduction of Order problem.\nBut it needs to be in the form\n\\begin{align*}\n    y'' + P(x) y' + Q(x) y &= 0\n\\end{align*}\nbefore it can be solved.\n\n\\begin{align*}\n    y'' - \\frac{2 x}{x^2 + 1} y' + \\frac{2}{x^2 + 1} y &= 0\n\\end{align*}\n\nTo find a second answer, $y_2$, we must solve $y_2 = v \\cdot y_1$ where\n\\begin{align*}\n    v &= \\int \\frac{e^{-\\int P(x) \\; dx}}{(y_1)^2}\n\\end{align*}\n\nPlugging in the values and solving results in the value:\n\\begin{align*}\n    v &= x - \\frac{1}{x}\n\\end{align*}\n\n\\begin{align*}\n    y_2 &= v \\cdot y_1 \\\\\n        &= (x - \\frac{1}{x}) x \\\\\n        &= x^2 - 1\n\\end{align*}\n\nChecking the second answer by deriving and plugging back in to the original\nequation will confirm that it is indeed a valid solution.\n\nCombine both the solutions in to a single general solution for the\nfinal answer.\n\n\\begin{align*}\n    y_g &= C_1 x + C_2 x^2 - 1\n\\end{align*}\n\n	4	00:05:00	[jmm] Tue, 26 Oct 2010 18:41:12 -0700	This was a test question given on 10/20/10 in MATH-40 taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
23	Solve the ODE: y' = 2*x	Solve the ODE:\n\\begin{align*}\n    y' = 2 x\n\\end{align*}\n	Separate and integrate.\n\n\\begin{align*}\n    \\frac{dy}{dx} &= 2 x \\\\\n    dy &= 2 x \\; dx \\\\\n    \\int dy &= \\int 2 x \\; dx \\\\\n    y &= x^2\n\\end{align*}\n\nThe answer can be verified by deriving it and verifying that\nit is the same as the original equation.\n\n\\begin{align*}\n    y &= x^2 \\\\\n    y' &= 2 x\n\\end{align*}\n	4	00:02:00	[jmm] Tue, 08 Aug 2010 00:00:00 -0700	An example given in class (MATH-40) taught by Mr Bigler at Butte Community College on 2010-Aug-24.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
24	Solve the ODE: y' = 1 + y^2	Solve the ODE:\n\\begin{align*}\n    y' = 1 + y^2\n\\end{align*}\n	Seperate and integrate.\n\n\\begin{align*}\n    \\frac{dy}{dx} &= 1 + y^2 \\\\\n    dy &= (1 + y^2) \\; dx \\\\\n    \\frac{dy}{1 + y^2} &= dx \\\\\n    \\int \\frac{dy}{1 + y^2} &= \\int dx \\\\\n    \\arctan(y) &= x + C \\\\\n    y &= \\tan(x + C) & \\mbox{(explicit, one parameter, family of solutions)} \\\\\n    x &= 0, C = 0 \\rightarrow y = 0 \\\\\n    y &= \\tan(x) & \\mbox{(particular solution)}\n\\end{align*}\n	4	00:02:00	[jmm] Tue, 08 Aug 2010 00:00:01 -0700	An example given in class (MATH-40) taught by Mr Bigler at Butte Community College on 2010-Aug-24.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
25	Solve the IVP: y' = -x/y; y(0) = 1	Solve the ODE:\n\\begin{align*}\n    \\frac{dy}{dx} &= \\frac{-x}{y} ; \\;\\;\\; y(0) = 1\n\\end{align*}\n	\nFirst solve the ODE (separate and integrate).\n\n\\begin{align*}\n    \\int y \\; dy &= - \\int x \\; dx \\\\\n    \\frac{y^2}{2} &= -\\frac{x^2}{2} + C \\\\\n    y^2 &= -x^2 + C \\\\\n    y &= \\pm \\sqrt{C - x^2}\n\\end{align*}\n\nSubstitute the values of the initial condition ($y(0) = 1$) to find\nthe value of $C$.\n\n\\begin{align*}\n    y(0) &= 1 \\\\\n    1 &= \\pm \\sqrt{C - 0^2} \\\\\n    1 &= \\pm \\sqrt{C} & \\mbox{(cannot be negative)} \\\\\n    y &= \\sqrt{1 - x^2}\n\\end{align*}\n	4	00:02:00	[jmm] Tue, 08 Aug 2010 00:00:02 -0700	An example given in class (MATH-40) taught by Mr Bigler at Butte Community College on 2010-Aug-24.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
18	A pan of hot water is removed ...	Assume that the rate at which radioactive nuclei decay is proporitonal to the\r\nnumber of such nuclei that are present in a given sample.  In a certain sample\r\none-fourth of the original number of radioactive nuclei have undergone\r\ndisintegration in a period of 500 years.\r\n\r\n(a)  What fraction of the original radioactive nuclei will remain after 1000\r\nyears?\r\n(b)  In how many years will one-half of the original number remain?	\\begin{align*}\r\n    \\frac{dA}{dt} &= k \\cdot A \\\\\r\n    A &= A_0 \\cdot e^{k \\cdot t} \\\\\r\n    \\frac{3}{4} A_0 &= A_0 \\cdot e^{k \\cdot 500} \\\\\r\n    k &= \\frac{\\ln(3/4)}{500} \\\\\r\n    A &= A_0 \\cdot e^{ \\frac{\\ln(3/4)}{500} \\cdot t}\r\n\\end{align*}\r\n\r\na)\r\n\\begin{align*}\r\n    t &= 1000 \\;\\; \\mbox{years} \\\\\r\n    z \\cdot A_0 &= A_0 \\cdot e^{ \\frac{\\ln(3/4)}{500} \\cdot 1000} \\\\\r\n    z &= 9/16\r\n\\end{align*}\r\n\r\nb)\r\n\\begin{align*}\r\n    z &= 1/2 \\\\\r\n    t &= ? \\\\\r\n    \\frac{1}{2} &= e^{ \\frac{\\ln(3/4)}{500} \\cdot t} \\\\\r\n    t &= \\frac{ \\ln(1/2) \\cdot 500 }{ \\ln(3/4) } \\\\\r\n      &= 1205 \\;\\; \\mbox{years}\r\n\\end{align*}	4	00:05:00	[jmm] Tue, 21 Sep 2010 20:53:36 -0700	Homework problem #8 from sheet handed out on 9/17/10 in the\nclass MATH-40 taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
\.


--
-- Data for Name: problemscores; Type: TABLE DATA; Schema: public; Owner: -
--

COPY problemscores (pscore_id, test_id, problem_id, user_id, assignedtest_id, start_t, end_t, score) FROM stdin;
\.


--
-- Data for Name: problemtags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY problemtags (pt_id, problem_id, tag) FROM stdin;
1	1	ODE
2	1	separable ODE
3	1	class:MATH-31
4	1	difficulty:moderate
5	1	proof
6	1	pythagorean theorem
7	1	arc length
8	2	math
9	2	class:MATH-31
10	2	difficulty:easy
11	2	proof
12	2	polar
13	3	ODE
14	3	nonlinear ODE
15	3	Bernoulli ODE
16	3	teacher:Mr. Bigler
17	3	class:MATH-40
18	3	in class example
19	4	ODE
20	4	nonlinear ODE
21	4	Bernoulli ODE
22	4	class:MATH-40
23	5	ODE
24	5	nonlinear ODE
25	5	IVP
26	5	Bernoulli ODE
27	5	class:MATH-40
28	6	math
29	6	class:MATH-40
30	6	ODE
31	6	exact ODE
32	7	math
33	7	class:MATH-40
34	7	ODE
35	7	exact ODE
36	8	physics
37	8	math
38	8	E&M
39	8	class:PHYS-42
40	9	ODE
41	9	separable ODE
42	9	class:MATH-40
43	9	difficulty:medium
44	9	trig
45	10	ODE
46	10	separable ODE
47	10	class:MATH-40
48	10	difficulty:medium
49	10	trig
50	10	partial fractions
51	11	ODE
52	11	separable ODE
53	11	class:MATH-40
54	11	difficulty:hard
55	11	polynomial long division
56	11	partial fractions
57	12	IVP
58	12	ODE
59	12	separable IVP
60	12	class:MATH-40
61	12	difficulty:hard
62	12	trig
63	12	table method of integration
64	13	IVP
65	13	ODE
66	13	linear
67	13	class:MATH-40
68	13	difficulty:hard
69	13	trig
70	14	math
71	14	class:MATH-40
72	14	ODE
73	14	difficulty:hard
74	14	clever substitution
75	14	ultimate method
76	15	math
77	15	class:MATH-40
78	15	orthogonal trajectories
79	15	polynomial long division
80	16	math
81	16	class:MATH-40
82	16	falling bodies
83	17	math
84	17	class:MATH-40
85	17	exponential growth
89	19	math
90	19	class:MATH-40
91	19	mixture
92	19	linear ODE
93	20	math
94	20	partial fractions
95	20	integration
96	20	class:MATH-31
97	21	physics
98	21	math
99	21	ODE
100	21	Newton
101	21	class:PHYS-41
102	21	class:MATH-40
103	22	ODE
104	22	difficulty:moderate
105	22	class:MATH-40
106	22	reduction of order
107	22	reduction of order - one solution to find another
108	22	test
109	23	ODE
110	23	separable ODE
111	23	class:MATH-40
112	23	difficulty:easy
113	24	ODE
114	24	separable ODE
115	24	class:MATH-40
116	24	difficulty:easy
117	25	ODE
118	25	separable IVP
119	25	class:MATH-40
120	25	difficulty:easy
121	18	math
122	18	class:MATH-40
123	18	exponential decay
\.


--
-- Data for Name: testproblems; Type: TABLE DATA; Schema: public; Owner: -
--

COPY testproblems (tp_id, test_id, problem_id, "order", points) FROM stdin;
\.


--
-- Data for Name: tests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY tests (test_id, author, dsc, create_date, finished, date) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY users (user_id, username, password, role, first_name, last_name, address, phone, email) FROM stdin;
\.


--
-- Name: assignedtests_assignedtest_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY assignedtests
    ADD CONSTRAINT assignedtests_assignedtest_id_key UNIQUE (assignedtest_id);


--
-- Name: assignedtests_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY assignedtests
    ADD CONSTRAINT assignedtests_pkey PRIMARY KEY (assignedtest_id, test_id, user_id);


--
-- Name: problems_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY problems
    ADD CONSTRAINT problems_pkey PRIMARY KEY (problem_id);


--
-- Name: problems_uuid_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY problems
    ADD CONSTRAINT problems_uuid_key UNIQUE (uuid);


--
-- Name: problemscores_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY problemscores
    ADD CONSTRAINT problemscores_pkey PRIMARY KEY (pscore_id);


--
-- Name: problemtags_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY problemtags
    ADD CONSTRAINT problemtags_pkey PRIMARY KEY (pt_id);


--
-- Name: testproblems_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY testproblems
    ADD CONSTRAINT testproblems_pkey PRIMARY KEY (tp_id);


--
-- Name: tests_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY tests
    ADD CONSTRAINT tests_pkey PRIMARY KEY (test_id);


--
-- Name: unique_problem_tag; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY problemtags
    ADD CONSTRAINT unique_problem_tag UNIQUE (problem_id, tag);


--
-- Name: unique_test_problem; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY testproblems
    ADD CONSTRAINT unique_test_problem UNIQUE (test_id, problem_id);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: users_username_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: assignedtests_test_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY assignedtests
    ADD CONSTRAINT assignedtests_test_id_fkey FOREIGN KEY (test_id) REFERENCES tests(test_id);


--
-- Name: assignedtests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY assignedtests
    ADD CONSTRAINT assignedtests_user_id_fkey FOREIGN KEY (user_id) REFERENCES users(user_id);


--
-- Name: problemscores_assignedtest_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY problemscores
    ADD CONSTRAINT problemscores_assignedtest_id_fkey FOREIGN KEY (assignedtest_id) REFERENCES assignedtests(assignedtest_id);


--
-- Name: problemscores_problem_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY problemscores
    ADD CONSTRAINT problemscores_problem_id_fkey FOREIGN KEY (problem_id) REFERENCES problems(problem_id);


--
-- Name: problemscores_test_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY problemscores
    ADD CONSTRAINT problemscores_test_id_fkey FOREIGN KEY (test_id) REFERENCES tests(test_id);


--
-- Name: problemscores_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY problemscores
    ADD CONSTRAINT problemscores_user_id_fkey FOREIGN KEY (user_id) REFERENCES users(user_id);


--
-- Name: problemtags_problem_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY problemtags
    ADD CONSTRAINT problemtags_problem_id_fkey FOREIGN KEY (problem_id) REFERENCES problems(problem_id);


--
-- Name: testproblems_problem_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY testproblems
    ADD CONSTRAINT testproblems_problem_id_fkey FOREIGN KEY (problem_id) REFERENCES problems(problem_id);


--
-- Name: testproblems_test_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY testproblems
    ADD CONSTRAINT testproblems_test_id_fkey FOREIGN KEY (test_id) REFERENCES tests(test_id);


--
-- Name: public; Type: ACL; Schema: -; Owner: -
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: problems; Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON TABLE problems FROM PUBLIC;
REVOKE ALL ON TABLE problems FROM jeri;
GRANT ALL ON TABLE problems TO jeri;
GRANT ALL ON TABLE problems TO "www-data";


--
-- Name: problems_problem_id_seq; Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON SEQUENCE problems_problem_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE problems_problem_id_seq FROM jeri;
GRANT ALL ON SEQUENCE problems_problem_id_seq TO jeri;
GRANT ALL ON SEQUENCE problems_problem_id_seq TO "www-data";


--
-- Name: problemtags; Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON TABLE problemtags FROM PUBLIC;
REVOKE ALL ON TABLE problemtags FROM jeri;
GRANT ALL ON TABLE problemtags TO jeri;
GRANT ALL ON TABLE problemtags TO "www-data";


--
-- Name: problemtags_pt_id_seq; Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON SEQUENCE problemtags_pt_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE problemtags_pt_id_seq FROM jeri;
GRANT ALL ON SEQUENCE problemtags_pt_id_seq TO jeri;
GRANT ALL ON SEQUENCE problemtags_pt_id_seq TO "www-data";


--
-- Name: testproblems; Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON TABLE testproblems FROM PUBLIC;
REVOKE ALL ON TABLE testproblems FROM jeri;
GRANT ALL ON TABLE testproblems TO jeri;
GRANT ALL ON TABLE testproblems TO "www-data";


--
-- Name: testproblems_tp_id_seq; Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON SEQUENCE testproblems_tp_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE testproblems_tp_id_seq FROM jeri;
GRANT ALL ON SEQUENCE testproblems_tp_id_seq TO jeri;
GRANT ALL ON SEQUENCE testproblems_tp_id_seq TO "www-data";


--
-- Name: tests; Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON TABLE tests FROM PUBLIC;
REVOKE ALL ON TABLE tests FROM jeri;
GRANT ALL ON TABLE tests TO jeri;
GRANT ALL ON TABLE tests TO "www-data";


--
-- Name: tests_test_id_seq; Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON SEQUENCE tests_test_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE tests_test_id_seq FROM jeri;
GRANT ALL ON SEQUENCE tests_test_id_seq TO jeri;
GRANT ALL ON SEQUENCE tests_test_id_seq TO "www-data";


--
-- PostgreSQL database dump complete
--

