--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

--
-- Name: plpgsql; Type: PROCEDURAL LANGUAGE; Schema: -; Owner: -
--

CREATE OR REPLACE PROCEDURAL LANGUAGE plpgsql;


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: assignedtests; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE assignedtests (
    assignedtest_id integer NOT NULL,
    test_id integer NOT NULL,
    user_id integer NOT NULL,
    actual_start_time timestamp(0) with time zone,
    actual_end_time timestamp(0) with time zone,
    allowed_start_time timestamp(0) with time zone,
    allowed_max_end_time timestamp(0) with time zone
);


--
-- Name: TABLE assignedtests; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE assignedtests IS 'An instance in which a test is assigned and allowed to be taken.';


--
-- Name: assignedtests_assignedtest_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE assignedtests_assignedtest_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: assignedtests_assignedtest_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE assignedtests_assignedtest_id_seq OWNED BY assignedtests.assignedtest_id;


--
-- Name: assignedtests_assignedtest_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('assignedtests_assignedtest_id_seq', 1, false);


--
-- Name: config; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE config (
    admin_email text
);


--
-- Name: TABLE config; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE config IS 'Global configuration options.';


--
-- Name: problems; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE problems (
    problem_id integer NOT NULL,
    short_desc text NOT NULL,
    question text NOT NULL,
    answer text NOT NULL,
    nworklines integer DEFAULT 4 NOT NULL,
    par_time interval DEFAULT '00:05:00'::interval NOT NULL,
    uuid text NOT NULL,
    ref text,
    author text,
    create_date timestamp(0) with time zone DEFAULT now() NOT NULL
);


--
-- Name: COLUMN problems.short_desc; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN problems.short_desc IS 'A short description (1 line) of the problem.';


--
-- Name: COLUMN problems.par_time; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN problems.par_time IS 'The amount of time it should take to answer the question.  "par" is lingo from golf.';


--
-- Name: COLUMN problems.uuid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN problems.uuid IS 'A unique identifier of this problem.  Used to prevent duplication (loading of the same problem twice).';


--
-- Name: COLUMN problems.ref; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN problems.ref IS 'reference: A description of who created this problem and where it came from.';


--
-- Name: problems_problem_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE problems_problem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: problems_problem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE problems_problem_id_seq OWNED BY problems.problem_id;


--
-- Name: problems_problem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('problems_problem_id_seq', 468, true);


--
-- Name: problemscores; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE problemscores (
    pscore_id integer NOT NULL,
    test_id integer,
    problem_id integer,
    user_id integer,
    assignedtest_id integer,
    start_t timestamp(0) with time zone NOT NULL,
    end_t timestamp(0) with time zone NOT NULL,
    score integer
);


--
-- Name: problemscores_pscore_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE problemscores_pscore_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: problemscores_pscore_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE problemscores_pscore_id_seq OWNED BY problemscores.pscore_id;


--
-- Name: problemscores_pscore_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('problemscores_pscore_id_seq', 1, false);


--
-- Name: problemtags; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE problemtags (
    pt_id integer NOT NULL,
    problem_id integer NOT NULL,
    tag text NOT NULL
);


--
-- Name: problemtags_pt_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE problemtags_pt_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: problemtags_pt_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE problemtags_pt_id_seq OWNED BY problemtags.pt_id;


--
-- Name: problemtags_pt_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('problemtags_pt_id_seq', 2219, true);


--
-- Name: testproblems; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE testproblems (
    tp_id integer NOT NULL,
    test_id integer NOT NULL,
    problem_id integer NOT NULL,
    "order" integer DEFAULT 1 NOT NULL,
    points integer DEFAULT 1 NOT NULL
);


--
-- Name: testproblems_tp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE testproblems_tp_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: testproblems_tp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE testproblems_tp_id_seq OWNED BY testproblems.tp_id;


--
-- Name: testproblems_tp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('testproblems_tp_id_seq', 11, true);


--
-- Name: tests; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE tests (
    test_id integer NOT NULL,
    author integer,
    dsc text,
    create_date timestamp(0) with time zone DEFAULT now() NOT NULL,
    finished boolean DEFAULT false NOT NULL,
    date date DEFAULT ('now'::text)::date NOT NULL
);


--
-- Name: TABLE tests; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE tests IS 'A test definition.';


--
-- Name: COLUMN tests.dsc; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN tests.dsc IS 'A description of this test (e.g. "MATH-40 Fall 2010; Mr Bigler.")';


--
-- Name: COLUMN tests.finished; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN tests.finished IS 'A finished test should not be further modified.';


--
-- Name: COLUMN tests.date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN tests.date IS 'date to display on a test';


--
-- Name: tests_test_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE tests_test_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tests_test_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE tests_test_id_seq OWNED BY tests.test_id;


--
-- Name: tests_test_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('tests_test_id_seq', 2, true);


--
-- Name: testscores; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW testscores AS
    SELECT problemscores.test_id, problemscores.user_id, problemscores.assignedtest_id, sum(problemscores.score) AS score FROM problemscores GROUP BY problemscores.test_id, problemscores.user_id, problemscores.assignedtest_id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE users (
    user_id integer NOT NULL,
    username text NOT NULL,
    password text NOT NULL,
    role text,
    first_name text,
    last_name text,
    address text,
    phone text,
    email text
);


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE users_user_id_seq OWNED BY users.user_id;


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('users_user_id_seq', 1, false);


--
-- Name: assignedtest_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE assignedtests ALTER COLUMN assignedtest_id SET DEFAULT nextval('assignedtests_assignedtest_id_seq'::regclass);


--
-- Name: problem_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE problems ALTER COLUMN problem_id SET DEFAULT nextval('problems_problem_id_seq'::regclass);


--
-- Name: pscore_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE problemscores ALTER COLUMN pscore_id SET DEFAULT nextval('problemscores_pscore_id_seq'::regclass);


--
-- Name: pt_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE problemtags ALTER COLUMN pt_id SET DEFAULT nextval('problemtags_pt_id_seq'::regclass);


--
-- Name: tp_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE testproblems ALTER COLUMN tp_id SET DEFAULT nextval('testproblems_tp_id_seq'::regclass);


--
-- Name: test_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE tests ALTER COLUMN test_id SET DEFAULT nextval('tests_test_id_seq'::regclass);


--
-- Name: user_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE users ALTER COLUMN user_id SET DEFAULT nextval('users_user_id_seq'::regclass);


--
-- Data for Name: assignedtests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY assignedtests (assignedtest_id, test_id, user_id, actual_start_time, actual_end_time, allowed_start_time, allowed_max_end_time) FROM stdin;
\.


--
-- Data for Name: config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY config (admin_email) FROM stdin;
\.


--
-- Data for Name: problems; Type: TABLE DATA; Schema: public; Owner: -
--

COPY problems (problem_id, short_desc, question, answer, nworklines, par_time, uuid, ref, author, create_date) FROM stdin;
1	Derive formula for the arc length using the Pythagorean Theorem.	Use the pythagorean theorem ($a^2 + b^2 = c^2$) to derive the\nformula for calculating the arc length.\n	The goal is sum up all the lengths of the hypotenuses as either\nx (or y) gets infinitely small. In this answer it will be over $x$.\n\\begin{align*}\n    a^2 + b^2 &= c^2 \\\\\n    dS^2 &= dx^2 + dy^2 \\\\\n    \\sqrt{\\frac{dL^2}{dx^2}} &= \\sqrt{1 + \\frac{dy^2}{dx^2}} \\\\\n    \\frac{dL}{dx} &= \\sqrt{1 + \\frac{dy^2}{dx^2}} \\\\\n    dL &= \\sqrt{1 + \\frac{dy^2}{dx^2}} \\;\\; dx \\\\\n    \\int dL &= \\int_{a}^{b} \\sqrt{1 + \\Big( \\frac{dy}{dx} \\Big)^2} \\;\\; dx \\\\\n    L &= \\int_{a}^{b} \\sqrt{1 + \\Big( \\frac{dy}{dx}\\Big)^2} \\;\\; dx\n\\end{align*}\n	4	00:05:00	[jmm] Wed, 15 Sep 2010 21:17:42 -0700	This example is commonly given in a Calculus 2 (MATH-31) class.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
3	Solve the ODE: y' + y = x*y^3	Solve the ODE:\n\\begin{align*}\n    y' + y &= x \\cdot y^3\n\\end{align*}\n	Notice that the equation is nonlinear because of $y^3$ therefore\nit might be solved as a Bernoulli Differential Equation.\n\nFollow the steps for solving a Bernoulli Differential Equation.\n\nMultiply by $y^{-3}$ to eliminate $y^3$.\n\n\\begin{align*}\n    y' \\cdot y^{-3} + y^{-2} &= x\n\\end{align*}\n\nLet $z = y^{1 - n} = y^{1 - 3} = y^{-2}$.\n\\begin{align*}\n    z &= y^{-2} \\\\\n    z' &= -2 \\cdot y^{-3} \\cdot y'\n\\end{align*}\n\nSubstitute $z$ in to the original equation:\n\\begin{align*}\n    -\\frac{1}{2} \\cdot z' + z &= x\n\\end{align*}\n\nNow it can be solved as a linear ODE.\n\n\\begin{align*}\n    y' + P(x) \\cdot y &= Q(x) \\\\\n    z' - 2 \\cdot z &= -2 \\cdot x\n\\end{align*}\n\n\\begin{align*}\n    \\mu &= e^{\\int P(x) dx} \\\\\n    &= e^{\\int -2 dx} \\\\\n    &= e^{-2 x}\n\\end{align*}\n\nMultiply $\\mu$ by the linear equation, find the derivative (and check).\n\\begin{align*}\n    e^{-2 x} \\cdot z' - e^{-2 x} \\cdot 2 z &= -e^{-2 x} \\cdot 2 x \\\\\n    \\frac{d}{dx} \\Big[ e^{-2 x} z \\Big] &= -e^{-2 x} 2 x  & \\mbox{(checked OK)}\n\\end{align*}\n\nIntegrate (hint: use the table method).\n\\begin{align*}\n    \\int \\frac{d}{dx} \\Big[ e^{-2 x} z \\Big] &= \\int -e^{-2 x} 2 x \\\\\n    e^{-2 x} z  &= x e^{-2 x} + \\frac{1}{2} e^{-2 x} + C \\\\\n    z &= x + \\frac{1}{2} + C e^{2 x}\n\\end{align*}\n\nSubstitute for $z$ the original equation ($z = y^{-2}$).\n\\begin{align*}\n    y^{-2} &= x + \\frac{1}{2} + C e^{2 x} \\\\\n    \\frac{1}{y^{2}} &= \\frac{2 x + 1 + C e^{2 x} 2}{2} \\\\\n    y^2 &= \\frac{2}{2 x + 1 + 2 C e^{2 x}} \\\\\n    y^2 &= \\frac{4}{4 x + 2 + 4 C e^{2 x}} \\\\\n    y &= \\frac{2}{\\sqrt{4 x + 2 + 4 C e^{2 x}}}\n\\end{align*}\n\nThe final answer is:\n\\begin{align*}\n    y &= \\frac{2}{\\sqrt{4 x + 2 + 4 C e^{2 x}}}\n\\end{align*}\n\nAn alternative solution could have combined all the components related\nto $C$.\n\\begin{align*}\n    y &= \\frac{2}{\\sqrt{4 x + 2 + C}}\n\\end{align*}\n	4	00:03:00	Tue, 07 Sep 2010 16:29:03 -0700	An example given in class (MATH-40) taught by Mr Bigler at Butte Community College on 2010-Sep-01.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
4	Solve the ODE: y' - 2y/x = -x^2 * y^2	Solve the ODE:\n\\begin{align*}\n    y' - \\frac{2 y}{x} = -x^2 \\cdot y^2\n\\end{align*}\n	Notice that the equation is nonlinear because of $y^2$, therefore\nit might be solved as a Bernoulli Differential Equation.\n\nFollow the steps for solving a Bernoulli Differential Equation.\n\nMultiply by $y^{-2}$ to eliminate $y^2$.\n\n\\begin{align*}\n    y' \\cdot y^{-2} - \\frac{2}{x} \\cdot y^{-1} &= -x^2\n\\end{align*}\n\nLet $z = y^{1 - n} = y^{1 - 2} = y^{-1}$.\n\\begin{align*}\n    z &= y^{-1} \\\\\n    z' &= -y^{-2} \\cdot y'\n\\end{align*}\n\nSubstitute $z$ in to the original equation:\n\\begin{align*}\n    -z' - \\frac{2}{x} \\cdot z = -x^2 \\\\\n    z' + \\frac{2}{x} \\cdot z = x^2\n\\end{align*}\n\nNow it can be solved as a linear ODE.\n\n\\begin{align*}\n    y' + P(x) \\cdot y &= Q(x) \\\\\n    z' + \\frac{2}{x} \\cdot z &= x^2\n\\end{align*}\n\n\\begin{align*}\n    \\mu &= e^{\\int P(x) dx} \\\\\n    &= e^{\\int \\frac{2}{x} dx} \\\\\n    &= e^{2 \\ln |x|} \\\\\n    &= x^2\n\\end{align*}\n\nMultiply $\\mu$ by the linear equation, find the derivative (and check).\n\\begin{align*}\n    x^2 \\cdot z' - 2 \\cdot x \\cdot z &= x^4 \\\\\n    \\frac{d}{dx} \\Big[ x^2 \\cdot z \\Big] &= x^4  & \\mbox{(checked OK)}\n\\end{align*}\n\nIntegrate.\n\\begin{align*}\n    \\int \\frac{d}{dx} \\Big[ x^2 \\cdot z \\Big] &= x^4 \\\\\n    x^2 \\cdot z &= \\frac{x^5}{5} + C\n\\end{align*}\n\nSubstitute for $z$ the original equation ($z = y^{-1}$).\n\\begin{align*}\n    \\frac{x^2}{y} &= \\frac{x^5}{5} + C \\\\\n    \\frac{1}{y} &= \\frac{x^3}{5} + \\frac{C}{x^2} \\\\\n    \\frac{1}{y} &= \\frac{x^5 + 5 \\cdot C}{5 x^2} \\\\\n    y &= \\frac{5 x^2}{x^5 + 5 C} \\\\\n    y &= \\frac{x^2}{\\frac{x^5}{5} + C}\n\\end{align*}\n\nThe final answer is:\n\\begin{align*}\n    y &= \\frac{x^2}{\\frac{x^5}{5} + C}\n\\end{align*}\n	4	00:07:00	Tue, 07 Sep 2010 16:44:14 -0700	An example taken from Wikipedia [http://en.wikipedia.org/wiki/Bernoulli_differential_equation] on 2010-Sep-07	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
5	Solve the IVP: y' - y/2x = x * y^-3; y(1) = 2	Solve the IVP:\n\\begin{align*}\n    y' - \\frac{y}{2 x} = x \\cdot y^{-3} \\; ; \\;\\;\\; y(1) = 2\n\\end{align*}\n	Notice that the equation is nonlinear because of $y^{-3}$, therefore\nit might be solved as a Bernoulli Differential Equation.\n\nFollow the steps for solving a Bernoulli Differential Equation.\n\nMultiply by $y^{3}$ to eliminate $y^{-3}$.\n\n\\begin{align*}\n    y' \\cdot y^{3} - \\frac{1}{2 x} \\cdot y^{4} &= x\n\\end{align*}\n\nLet $z = y^{1 - n} = y^{1 - (-3)} = y^{4}$.\n\\begin{align*}\n    z &= y^{4} \\\\\n    z' &= 4 \\cdot y^{3} \\cdot y'\n\\end{align*}\n\nSubstitute $z$ in to the original equation:\n\\begin{align*}\n    \\frac{1}{4} \\cdot z' - \\frac{1}{2x} \\cdot z = x\n\\end{align*}\n\nNow it can be solved as a linear ODE.\n\n\\begin{align*}\n    y' + P(x) \\cdot y &= Q(x) \\\\\n    z' - \\frac{2}{x} \\cdot z &= 4 \\cdot x\n\\end{align*}\n\nFind the integrating factor ($\\mu$).\n\\begin{align*}\n    \\mu &= e^{\\int P(x) dx} \\\\\n    &= e^{\\int -\\frac{2}{x} dx} \\\\\n    &= e^{-2 \\ln |x|} \\\\\n    &= x^{-2}\n\\end{align*}\n\nMultiply $\\mu$ by the linear equation and find the derivative.\n\\begin{align*}\n    z' \\cdot x^{-2} + 2 \\cdot x^{-3} \\cdot z &= 4 x^{-1} \\\\\n    \\frac{d}{dx} \\Big[ x^{-2} \\cdot z \\Big] &= 4 \\cdot x^{-1}\n\\end{align*}\n\nIntegrate.\n\\begin{align*}\n    \\frac{d}{dx} \\Big[ x^{-2} \\cdot z \\Big] &= 4 \\cdot x^{-1} \\\\\n    z \\cdot x^{-2} &= 4 \\ln|x| + C\n\\end{align*}\n\nSubstitute for $z$ the original equation ($z = y^{4}$).\n\\begin{align*}\n    y^4 \\cdot x^{-2} &= 4 \\ln|x| + C\n\\end{align*}\n\nAt this point the ODE is solved implicitly.\nBut $C$ needs to be found using the initial condition $y(1) = 2$.\nSubstitute the values and solve for $C$.\n\\begin{align*}\n    2^4 &= 1^2 \\cdot 4 \\ln|1| + C \\\\\n    C &= 16 \\\\\n    y^4 \\cdot x^{-2} &= 4 \\ln|x| + 16\n\\end{align*}\n\nThe final answer in implicit form is:\n\\begin{align*}\n    y^4 &= x^2 \\cdot 4 \\ln|x| + 16 x^2\n\\end{align*}\n	4	00:05:00	Tue, 07 Sep 2010 20:38:37 -0700	An example given in class (MATH-40) taught by Mr Bigler at Butte Community College on 2010-Sep-01.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
12	Solve the IVP: x*sin(x)*e^(-y) dx - y dy = 0	Solve the IVP:\n\\begin{align*}\n    x \\cdot \\sin(x) \\cdot e^{-y} \\; dx - y \\; dy &= 0 \\;\\; ; \\; y(0) = 1\n\\end{align*}\n	Separate.\n\\begin{align*}\n    \\int x \\cdot \\sin(x) \\cdot e^{-y} \\; dx &= \\int y \\; dy\n\\end{align*}\n\nUse the table method of integration to integrate each side.\n\\begin{align*}\n    -x \\cdot \\cos(x) + \\sin(x) &= y e^y - e^y + C\n\\end{align*}\n\nSubstitute the initial conditon to find $C$.\n\\begin{align*}\n    0 + 0 &= 1 \\cdot e^1 - e^1 + C \\\\\n    C &= 0\n\\end{align*}\n\n\\begin{align*}\n    -x \\cdot \\cos(x) + \\sin(x) &= y e^y - e^y\n\\end{align*}\n	4	00:10:00	[jmm] Wed, 22 Sep 2010 23:28:25 -0700	Homework problem 10 from the sheet handed out on 8/25/10 in the class (MATH-40) taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
51	convert parametric to symmetric	Convert the parametric equation to symmetric form:\n\\begin{align*}\nx &= -2 + 3t\\\\\ny &= 1 + 4t\\\\\nz &= -7t\n\\end{align*}\n	\\begin{align*}\nt = \\frac{x+2}{3} = \\frac{y-1}{4} = \\frac{z-0}{-7}\n\\end{align*}\n\nIt is good form to leave the negative sign in the denominator to\nsimplify conversion back to parametric form.	4	00:01:00	[jmm] Tue Feb 23 19:48:19 2010	Problems from Calculus 2 (MATH-32) taught by Mr Bigler at Butte College in 2010.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:37:42-08
52	equation of line parallel and through (1, 2, -3)	Find the equation for the line containing the point (1, 2, -3) that\nis parallel to $<4, 5, -7>$.\n	Substitute using:\n\\begin{align*}\nx &= x_1 + a \\; t\\\\\ny &= y_1 + b \\; t\\\\\nz &= z_1 + c \\; t\n\\end{align*}\nWhere $<a, b, c> = <4, 5, -7>$.\n\n\\begin{align*}\nx &= 1 + 4t\\\\\ny &= 2 + 5t\\\\\nz &= -3 - 7t\n\\end{align*}	4	00:01:00	[jmm] Tue Feb 16 09:10:40 2010	Problems from Calculus 2 (MATH-32) taught by Mr Bigler at Butte College in 2010.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:37:42-08
6	Solve the ODE: (xy - 1)dx + (x^2 - xy) dy = 0	Solve the ODE:\n\\begin{align*}\n    (x \\cdot y - 1) \\; dx + (x^2 - x \\cdot y) \\; dy = 0\n\\end{align*}\n	It is not separable and it is not exact (see below) but it is close.\n\\begin{align*}\n    \\frac{\\partial{M}}{\\partial{y}} &= x \\ne \\frac{\\partial{N}}{\\partial{x}}\n        = 2x - y\n\\end{align*}\n\nTry to find a function in terms of $x$ only.\n\\begin{align*}\n    \\frac{ \\frac{\\partial{M}}{\\partial{y}} - \\frac{\\partial{N}}{\\partial{x}} }\n        {N}\n        &= \\frac{x - 2x + y}{x^2 - xy} \\\\\n        &= -\\frac{1}{x}\n\\end{align*}\nA function in terms of $x$ only was found so this can be used to build an\nintegrating factor.\n\n\\begin{align*}\n    \\mu &= e^{\\int -1/x \\; dx} \\\\\n        &= x^{-1}\n\\end{align*}\n\nMultiply the integrating factor by the original equation and then\ncheck to make sure it is now exact.\n\\begin{align*}\n    \\frac{(xy - 1)}{x} \\; dx + \\frac{ (x^2 - xy)}{x} \\; dy &= 0 \\\\\n    y - \\frac{1}{x} \\; dx + (x - y) \\; dy &= 0 \\\\\n    \\frac{\\partial{M}}{\\partial{y}} = 1 &= \\frac{\\partial{N}}{\\partial{x}}\n\\end{align*}\nThe modified equation is exact so now it can be solved normally.\n\nIntegrate each term seperately and then combine unique terms.\n\\begin{align*}\n    \\int \\Big( y - \\frac{1}{x} \\Big) \\; dx &= x y - \\ln|x| \\\\\n    \\int \\Big( x - y \\Big) \\; dy &= x y - \\frac{y^2}{2} \\\\\n    -\\frac{y^2}{2} + x y - \\ln|x| &= C\n\\end{align*}\n	4	00:04:00	[jmm] Tue, 21 Sep 2010 22:26:02 -0700	An example given on 9/13/10 in the class MATH-40 taught\nby Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
7	Solve the ODE: y dx + (x^2 y - x) dy = 0	Solve the ODE:\n\\begin{align*}\n    y \\; dx + (x^2 y - x ) \\; dy = 0\n\\end{align*}\n	It is not separable and it is not exact (see below) but it is close.\n\\begin{align*}\n    \\frac{\\partial{M}}{\\partial{y}} &= 1 \\ne \\frac{\\partial{N}}{\\partial{x}}\n        = 2 x y - 1\n\\end{align*}\n\nTry to find a function in terms of $x$ only.\n\\begin{align*}\n    \\frac{ \\frac{\\partial{M}}{\\partial{y}} - \\frac{\\partial{N}}{\\partial{x}} }\n        {N}\n        &= \\frac{2 - 2 x y}{x^2 y - x} \\\\\n        &= -\\frac{2}{x}\n\\end{align*}\nA function in terms of $x$ only was found so this can be used to build an\nintegrating factor.\n\n\\begin{align*}\n    \\mu &= e^{\\int -2/x \\; dx} \\\\\n        &= x^{-2}\n\\end{align*}\n\nMultiply the integrating factor by the original equation and then\ncheck to make sure it is now exact.\n\\begin{align*}\n    \\frac{y}{x^2} \\; dx + \\frac{ (x^2 y - x)}{x^2} \\; dy &= 0 \\\\\n    \\frac{\\partial{M}}{\\partial{y}} = \\frac{1}{x^2} &= \\frac{\\partial{N}}{\\partial{x}}\n\\end{align*}\nThe modified equation is exact so now it can be solved normally.\n\nIntegrate each term seperately and then combine unique terms.\n\\begin{align*}\n    \\int \\frac{y}{x^2} \\; dx &= -\\frac{y}{x} \\\\\n    \\int \\Big( y - \\frac{1}{x} \\Big) \\; dy &= \\frac{y^2}{2} - \\frac{y}{x} \\\\\n    \\frac{y^2}{2} - \\frac{y}{x} &= C\n\\end{align*}\n	4	00:04:00	[jmm] Tue, 21 Sep 2010 22:57:59 -0700	An example given on 9/13/10 in the class MATH-40 taught\nby Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
8	Show that Gauss's Law is true by calculating the integral.	To find the flux using Gauss's Law it is often not necessary\nto calculate the E field and the area because $q/\\epsilon_0$ can be used.\n\\begin{align*}\n    \\Phi &= \\oint \\vec{E} \\cdot \\vec{dA} = \\frac{q}{\\epsilon_0}\n\\end{align*}\n\nUsing any surface you choose, complete the integral and show that it\ndoes in fact equal $q/\\epsilon_0$.\n	The simplest surface to use is a sphere so that is what will be used here.\n\nThe equation for calculating the electric field using Coulomb's Law.\n\\begin{align*}\n    E = \\frac{k \\cdot Q}{r^2}\n\\end{align*}\n\nThe surface area of a sphere.\n\\begin{align*}\n    A = 4 \\cdot \\pi \\cdot r^2\n\\end{align*}\n\n\\begin{align*}\n    \\Phi &= \\oint E \\cdot dA \\\\\n    &= E \\cdot A \\\\\n    &= \\frac{k \\cdot Q \\cdot 4 \\pi r^2}{r^2} \\\\\n    &= k \\cdot Q \\cdot 4 \\pi\n\\end{align*}\n\nSubstitute for $k$.\n\\begin{align*}\n    k &= \\frac{1}{4 \\pi \\epsilon_0}\n\\end{align*}\n\n\\begin{align*}\n    \\Phi &= k \\cdot Q \\cdot 4 \\pi \\\\\n    &= \\frac{Q \\cdot 4 \\pi}{4 \\pi \\epsilon_0} \\\\\n    &= \\frac{Q}{\\epsilon_0} \\\\\n    &= \\frac{q}{\\epsilon_0}\n\\end{align*}\n\nThis results proves that integrating produces the same result as expected.\n	4	00:05:00	[jmm] Thu, 18 Sep 2010 23:35:43 -0700	A common problem in a Physisc Electricity and Magnetism class.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
9	Solve the ODE: sin(x)*sin(y) dx + cos(x)*cos(y) dy = 0	Solve the ODE:\n\\begin{align*}\n    \\sin(x) \\sin(y) \\; dx + \\cos(x) \\cdot \\cos(y) \\; dy &= 0\n\\end{align*}\n	Separate and integrate.\n\\begin{align*}\n    \\int \\frac{-\\sin(x)}{\\cos(x)} \\; dx &= \\int \\frac{ \\cos(y) }{ \\sin(y) } \\; dy \\\\\n    \\ln|\\cos(x)| &= \\ln|\\sin(y)| + C \\\\\n    \\cos(x) &= \\sin(y) \\cdot C \\\\\n    \\sin(y) &= C \\cdot \\cos(x)\n\\end{align*}\n\nOther slight variations involving $C$ in the answer are also acceptable.\n	4	00:03:00	[jmm] Wed, 22 Sep 2010 16:13:49 -0700	Homework problem 3 from the sheet handed out on 8/25/10 in the class (MATH-40) taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
10	Solve the ODE: dP/dt = a*P - b*P^2	Solve the ODE:\n\\begin{align*}\n    \\frac{dP}{dt} &= a \\cdot P - b \\cdot P^2\n\\end{align*}\n	Separate and integrate.\n\\begin{align*}\n    \\frac{dP}{a \\cdot P - b \\cdot P^2} &= dt\n\\end{align*}\n\nUse partial fractions (not shown) to reduce the equation to\nan integratable form.\n\\begin{align*}\n    \\int dt &= \\int \\Big( \\frac{1/a}{P} + \\frac{b/a}{a - b \\cdot P} \\Big) \\; dP\n\\end{align*}\n\n\\begin{align*}\n    t &= \\frac{1}{a} \\ln|P| - \\frac{1}{a} \\ln|a - b \\cdot P| + C \\\\\n    t \\cdot a + C &= \\ln|P| - \\ln|a - b \\cdot P| \\\\\n    t \\cdot a + C &= \\ln \\Big( \\frac{|P|}{|a - b \\cdot p|} \\Big) \\\\\n    K \\cdot e^{t \\cdot a} &= \\frac{|P|}{|a - b \\cdot P|}\n\\end{align*}\n	4	00:05:00	[jmm] Wed, 22 Sep 2010 16:41:13 -0700	Homework problem 4 from the sheet handed out on 8/25/10 in the class (MATH-40) taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
11	Solve the ODE: (xy + x)dx - (x^2*y^2 + x^2 + y^2 + 1)dy = 0	Solve the ODE:\n\\begin{align*}\n    (xy + x) \\; dx - (x^2 y^2 + x^2 + y^2 + 1) \\; dy &= 0\n\\end{align*}\n	Separate.\n\\begin{align*}\n    (xy + x) \\; dx - (x^2 y^2 + x^2 + y^2 + 1) \\; dy &= 0 \\\\\n    x (y + 1) \\; dx &= x^2 (y^2 + 1) + (y^2 + 1) \\; dy \\\\\n    \\frac{(y+1)}{x} \\; dx &= (y^2 + 1) (x^2 + 1) \\; dy \\\\\n    \\frac{dx}{x(x^2 + 1)} &= \\frac{y^2 + 1}{y + 1} \\; dy\n\\end{align*}\n\nIn it's current form it is difficult to integrate.\nThe left hand side ($dx$) can be reduced using partial fractions.\nAnd the right hand side can be reduced using polynomial long division.\nThe steps are not shown, just the result below.\n\\begin{align*}\n    \\Big( \\frac{1}{x} - \\frac{x}{x^2 + 1} \\Big) \\; dx &= \\Big( y - 1 + \\frac{2}{y+1} \\Big) \\; dy \\\\\n    \\ln|x| - \\frac{1}{2} \\cdot \\ln|x^2 + 1| &= \\frac{y^2}{2} - y + 2 \\cdot \\ln|y + 1| + C \\\\\n    2 \\ln|x| - \\ln|x^2 + 1| &= y^2 - 2 y + 4 \\cdot \\ln|y + 1| + C\n\\end{align*}\n	4	00:10:00	[jmm] Wed, 22 Sep 2010 18:01:09 -0700	Homework problem 5 from the sheet handed out on 8/25/10 in the class (MATH-40) taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
13	Solve the IVP: y' = (cot x)*y + sin(x); y(pi/2) = 0	Solve the IVP:\n\\begin{align*}\n    y' &= (\\cot x) y + \\sin x \\;\\; ; \\; y(\\pi/2) = 0\n\\end{align*}\n	It is not seperable but it does fit in to the linear form ($y' + P(x) y = Q(x)$).\n\\begin{align*}\n    y' - (\\cot x) y &= \\sin x\n\\end{align*}\n\nBuild the integrating factor.\n\\begin{align*}\n    \\mu &= e^{\\int -\\cot x \\; dx} \\\\\n        &= e^{- \\ln|\\sin x|} \\\\\n        &= \\frac{1}{\\sin x}\n\\end{align*}\n\nMultiply $\\mu$ by the equation.\n\\begin{align*}\n    y' \\cdot \\frac{1}{\\sin x} - \\frac{\\cot x}{\\sin x} y &= 1\n\\end{align*}\n\nCheck the derivative and integrate.\n\\begin{align*}\n    \\int \\frac{d}{dx} \\Big[ \\frac{1}{\\sin x} y \\Big] &= \\int 1 \\; dx \\\\\n    \\frac{1}{\\sin x} y &= x + C\n\\end{align*}\n\nSubstitute the initial conditon to find $C$.\n\\begin{align*}\n    \\frac{1}{\\sin(\\pi/2)} \\cdot 0 &= \\frac{\\pi}{2} + C \\\\\n    C &= -\\frac{\\pi}{2}\n\\end{align*}\n\n\\begin{align*}\n    y &= \\sin(x) \\Big( x - \\frac{\\pi}{2} \\Big)\n\\end{align*}\n	4	00:10:00	[jmm] Thu, 23 Sep 2010 09:15:47 -0700	Homework problem 7 from the problems on Pg. 71 of Ordinary Differential Equations by Charles E. Roberts.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
14	Solve the ODE: (x + y) dy = y dx	Solve the ODE\n\\begin{align*}\n    (x + y) \\; dy &= y \\; dx\n\\end{align*}\n	This problem can be solved using the ultimate method or the clever\nsubstitution ($v = y/x$).\n\\begin{align*}\n\\frac{ \\frac{\\partial M}{\\partial y} - \\frac{\\partial N}{\\partial x} }\n    { - M } &= -\\frac{2}{y}\n\\end{align*}\n\n(intermediate steps not shown)\n\n\\begin{align*}\n    \\frac{x}{y} - \\ln|y| = C\n\\end{align*}\n	4	00:10:00	[jmm] Thu, 23 Sep 2010 17:23:52 -0700	Homework problem #16 from sheet handed out on 9/13/10 in the\nclass MATH-40 taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
15	Find the orthogonal trajectory of: y = c*(x + 1/x)	Find the orthogonal trajectories of the family of curves\n\\begin{align*}\n    y &= c \\Big( x + \\frac{1}{x} \\Big)\n\\end{align*}\n	\\begin{align*}\n    y^2 &= -x^2 -2 \\cdot \\ln|x^2 - 1| + C\n\\end{align*}\n	4	00:04:00	[jmm] Tue, 21 Sep 2010 20:13:23 -0700	Homework problem #1 from sheet handed out on 9/17/10 in the\nclass MATH-40 taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
16	4 lbs thrown down 2000 ft ...	An object weighting 4 lb is thrown vertically downward toward the earth\nfrom a height of 2000 ft with an initial velocity of 2 ft/sec.  As it falls\nit is acted upon by air resistance that is numerically equal to $v/2$ (in pounds),\nwhere $v$ is the velocity (in feet per second).\\\\\n\\\\\n(a)  What is the velocity and distance fallen at the end of 1 second? \\\\\n(b)  With what velocity does the object strike the earth?\n	\nUse the equation for the falling bodies and find $k$.\nThen substitute to find the answer.\n\\begin{align*}\n    \\frac{dv}{dt} &= g - \\frac{g}{m} \\cdot k \\cdot v \\\\\n    \\frac{dv}{dt} &= 32 - \\frac{32}{4} \\cdot \\frac{1}{2} \\cdot v \\\\\n    \\frac{dv}{dt} &= 32 - 4 \\cdot v \\\\\n    \\frac{dv}{32 - 4 \\cdot v} &= dt \\\\\n    \\frac{dv}{8 - v} &= 4 \\cdot dt \\\\\n    \\frac{dv}{v - 8} &= -4 \\cdot dt \\\\\n    \\int \\frac{dv}{v - 8} &= \\int -4 \\cdot dt \\\\\n    \\ln |v - 8| &= -4 \\cdot t + C \\\\\n    v - 8 &= e^{-4 \\cdot t} e^{C} \\\\\n    v &= e^{-4 \\cdot t} e^{C} + 8 \\\\\n    2 &= e^{C} + 8 & (v(0) = 2) \\\\\n    K &= -6 \\\\\n    v &= 8 - g \\cdot e^{-4 \\cdot t}\n\\end{align*}\n\nVelocity at 1 second: 7.89 ft/s\n\nBecause the terminal velocity is 8.00 ft/s and it reaches this\nspeed well before 2000 ft the velocity at impact will\nalso be the terminal velocity (8.00 ft/s).\n	4	00:04:00	[jmm] Tue, 21 Sep 2010 20:20:12 -0700	Homework problem #3 from sheet handed out on 9/17/10 in the\nclass MATH-40 taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
385	find area, arc, tangent of r = 2 sin(2 \\theta)	Given the polar equation:\r\n\\begin{align*}\r\n\tr &= 2 \\sin(2 \\theta)\r\n\\end{align*}\r\nA) find the area of 1 leaf.\\\\\r\nB) find the arc length of 1 leaf.\\\\\r\nC) find a vertical tangent between $0 \\le \\theta \\le \\frac{\\Pi}{2}$.	A) The graph loops once from $0$ to $2 \\Pi$ and there are 4 leaves\r\nso the period is $\\frac{2\\Pi}{4} = \\frac{\\Pi}{2}$.\r\nTherfore the area of one leaf is:\r\n\\begin{align*}\r\n\t&\\frac{1}{2} \\int_{0}^{\\frac{\\Pi}{2}}(2 \\sin{2\\theta)}^2 d\\theta\\\\\r\n\t&=1.570796327\r\n\\end{align*}\r\n\r\nB) Using the starting and ending points found in the previous step, the\r\narc length is:\r\n\\begin{align*}\r\n\t&\\int_{0}^{\\frac{\\Pi}{2}}\\sqrt{(2 \\sin{2\\theta)}^2 + (4 \\cos{2\\theta})^2} d\\theta\\\\\r\n\t&=4.844224110\r\n\\end{align*}\r\n\r\nC) A vertical tanget will be when $\\frac{dx}{d\\theta} = 0$.\r\n\\begin{align*}\r\n\tr &= 2 \\sin(2 \\theta)\\\\\r\n\tx &= (2 \\sin(2 \\theta)) \\cos(\\theta)\\\\\r\n\t\\frac{dx}{d\\theta} &= (2 \\sin(2 \\theta)) (-\\sin(\\theta)) + \\cos(\\theta) (4 \\cos(2 \\theta))\\\\\r\n\\end{align*}\r\n\r\nIf you plot $\\frac{dx}{d\\theta}$ between $0 \\le \\theta \\le \\frac{\\Pi}{2}$ in rectangular mode you can trace along to find where it is zero for an approxiamate solution of $0.61548$.\r\n\r\n\r\nUsing a TI-89 you can solve to find the answer.\r\n\\begin{verbatim}\r\nsolve(<dxdt>, {t=0});\r\n\\end{verbatim}\r\n\\verb+t+ is some guess, and \\verb+<dxdt>+ is the derivative.	12	00:10:00	[jmm] Sun Dec  6 13:22:36 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
19	A tank initially contains 300 gal of brine ...	A tank initially contains 300 gal of brine in which 20 lb of salt is dissolved.\nStarting at t = 0, brine containing 3 lb of salt per gallon flows in to the tank\nat the rate of 3 gal/min.  The mixture is kept uniform by stirring, and the\nwell-stirred mixture leaves the tank at the rate of 5 gal/min.  How much salt\nis in the tank at the end of 15 minutes?\n	Substitute and solve the differential equation. \n\\begin{align*}\n    \\frac{dQ}{dt} &= r_{in} \\cdot c_{in} - r_{out} \\cdot \\frac{Q}{v_o - (r_{out} - r_{in}) t} \\\\\n    Q(t) &= Q_0\n\\end{align*}\n\n(steps not shown)\n\n\\begin{align*}\n    Q = 134 \\;\\; \\mbox{lbs}\n\\end{align*}\n\n	4	00:15:00	[jmm] Tue, 21 Sep 2010 21:18:41 -0700	Homework problem #10 from sheet handed out on 9/17/10 in the\nclass MATH-40 taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
17	A mold grows at a rate ...	A mold grows at a rate that is proportional to the amount present.\r\nIn 24 hours the amount of it has grown from 2 grams to 3 grams.\r\nHow many grams of it are present at the end of 24 more hours?	The rate of change is proportional to the amount present.\r\n\\begin{align*}\r\n    & \\frac{dA}{dt} \\propto k \\cdot A\r\n\\end{align*}\r\n\r\nUse the initial conditions to find $k$.\r\n\\begin{align*}\r\n    A &= A_0 \\cdot e^{k \\cdot t} \\\\\r\n    3 &= 2 \\cdot e^{k \\cdot 24} \\\\\r\n    \\ln \\left( \\frac{3}{2} \\right) &= k \\cdot 24 \\\\\r\n    k &= \\frac{ \\ln(\\frac{3}{2}) }{24}\r\n\\end{align*}\r\n\r\nSubstitute for time ($t$) and solve for the amount ($A$).\r\n\\begin{align*}\r\n    A &= A_0 e^{ \\frac{ \\ln(\\frac{3}{2}) }{24} \\cdot t } \\\\\r\n      &= A_0 e^{ \\frac{ \\ln(\\frac{3}{2}) }{24} \\cdot 48 } \\\\\r\n      &= 2 \\cdot e^{2 \\ln(\\frac{3}{2}) } \\\\\r\n      &= 4.5 \\;\\; \\mbox{grams}\r\n\\end{align*}	4	00:05:00	[jmm] Tue, 21 Sep 2010 20:42:10 -0700	Homework problem #6 from sheet handed out on 9/17/10 in the\nclass MATH-40 taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
20	Integrate: (x^2 - 1)/(x*(x^2 + 1))	Integrate:\n\\begin{align*}\n    \\int \\frac{x^2 - 1}{x (x^2 + 1)}\n\\end{align*}\n	In its current form it cannot be integrated easily.\nNoticing that the degree of the denominator is greater than the\nnumerator it can likely be reduced using partial fractions.\n\n\\begin{align*}\n    \\frac{x^2 - 1}{x (x^2 + 1)} &= \\frac{A}{x} + \\frac{B x + C}{x^2 + 1} \\\\\n    x^2 - 1 &= A \\cdot (x^2 + 1) + x \\cdot (B x + C) \\\\\n    \\ldots \\\\\n    \\frac{x^2 - 1}{x (x^2 + 1)} &= \\frac{-1}{x} + \\frac{2 x + 0}{x^2 + 1}\n\\end{align*}\n\nNow it is in a form that can be integrated easily.\n\\begin{align*}\n    \\int \\Big( \\frac{-1}{x} + \\frac{2 x + 0}{x^2 + 1} \\Big) \\; dx\n      &= \\frac{1}{x^2} + \\ln|x^2 + 1| + C\n\\end{align*}\n	4	00:03:00	[jmm] 2010-09-19 01	An example made up by the author on 19 Sep 2010.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
21	Derive the kinematic equation for position.	Knowing that acceleration, position, and velocity are related as\n\\begin{align*}\n    a &= \\frac{dv}{dt} \\;\\;\\; [m/s^2] \\\\\n    v &= \\frac{dx}{dt} \\;\\;\\; [m/s]\n\\end{align*}\nderive the kinematic equation that describes the position ($x(x_0, v_0, t, a) \\;\\; [m]$).\n	\\begin{align*}\n    a &= \\frac{dv}{dt} \\;\\;\\; [m/s^2]\n\\end{align*}\n\nSeparate the variables and integrate.\n\n\\begin{align*}\n    \\int a \\; dt &= \\int dv \\\\\n    a \\cdot t &= v + C\n\\end{align*}\n\nTo determine what $C$ should be check the units.\nIn this case the units are $[m/s]$ which means $C$ represents velocity,\nspecifically the initial velocity.\n\n\\begin{align*}\n    a \\cdot t &= v + v_0 \\;\\;\\; [m/s]\n\\end{align*}\n\nSubstitute for velocity ($v$) with $\\frac{dx}{dt}$ then separate\nand integrate.\n\n\\begin{align*}\n    \\frac{dx}{dt} &= a \\cdot t + v_0 \\\\\n    \\int dx &= \\int (a \\cdot t + v_0) dt \\\\\n    x &= \\frac{1}{2} \\cdot a \\cdot t^2 + v_0 \\cdot t + C\n\\end{align*}\n\nDetermine what $C$ should be just like before by checking the units.\n\n\\begin{align*}\n    x_f &= \\frac{1}{2} \\cdot a \\cdot t^2 + v_0 \\cdot t + x_0 \\;\\;\\; [m]\n\\end{align*}\n\nThis final equation determines the position based on acceleration, velocity,\netc.\n	4	00:05:00	[jmm] Thu, 09 Sep 2010 22:03:06 -0700	A common example that is relevant to both a Physics class and\na class in Differential Equations.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
22	Solve: (x^2 + 1)y'' - 2xy' + 2y = 0.	Solve the ODE\n\\begin{align*}\n(x^2 + 1) y'' - 2 x y' + 2 y &= 0\n\\end{align*}\nknowing that one solution is $y = x$.\n	Because we are given one of the solution it is most likely\na Reduction of Order problem.\nBut it needs to be in the form\n\\begin{align*}\n    y'' + P(x) y' + Q(x) y &= 0\n\\end{align*}\nbefore it can be solved.\n\n\\begin{align*}\n    y'' - \\frac{2 x}{x^2 + 1} y' + \\frac{2}{x^2 + 1} y &= 0\n\\end{align*}\n\nTo find a second answer, $y_2$, we must solve $y_2 = v \\cdot y_1$ where\n\\begin{align*}\n    v &= \\int \\frac{e^{-\\int P(x) \\; dx}}{(y_1)^2}\n\\end{align*}\n\nPlugging in the values and solving results in the value:\n\\begin{align*}\n    v &= x - \\frac{1}{x}\n\\end{align*}\n\n\\begin{align*}\n    y_2 &= v \\cdot y_1 \\\\\n        &= (x - \\frac{1}{x}) x \\\\\n        &= x^2 - 1\n\\end{align*}\n\nChecking the second answer by deriving and plugging back in to the original\nequation will confirm that it is indeed a valid solution.\n\nCombine both the solutions in to a single general solution for the\nfinal answer.\n\n\\begin{align*}\n    y_g &= C_1 x + C_2 x^2 - 1\n\\end{align*}\n\n	4	00:05:00	[jmm] Tue, 26 Oct 2010 18:41:12 -0700	This was a test question given on 10/20/10 in MATH-40 taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
23	Solve the ODE: y' = 2*x	Solve the ODE:\n\\begin{align*}\n    y' = 2 x\n\\end{align*}\n	Separate and integrate.\n\n\\begin{align*}\n    \\frac{dy}{dx} &= 2 x \\\\\n    dy &= 2 x \\; dx \\\\\n    \\int dy &= \\int 2 x \\; dx \\\\\n    y &= x^2\n\\end{align*}\n\nThe answer can be verified by deriving it and verifying that\nit is the same as the original equation.\n\n\\begin{align*}\n    y &= x^2 \\\\\n    y' &= 2 x\n\\end{align*}\n	4	00:02:00	[jmm] Tue, 08 Aug 2010 00:00:00 -0700	An example given in class (MATH-40) taught by Mr Bigler at Butte Community College on 2010-Aug-24.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
24	Solve the ODE: y' = 1 + y^2	Solve the ODE:\n\\begin{align*}\n    y' = 1 + y^2\n\\end{align*}\n	Seperate and integrate.\n\n\\begin{align*}\n    \\frac{dy}{dx} &= 1 + y^2 \\\\\n    dy &= (1 + y^2) \\; dx \\\\\n    \\frac{dy}{1 + y^2} &= dx \\\\\n    \\int \\frac{dy}{1 + y^2} &= \\int dx \\\\\n    \\arctan(y) &= x + C \\\\\n    y &= \\tan(x + C) & \\mbox{(explicit, one parameter, family of solutions)} \\\\\n    x &= 0, C = 0 \\rightarrow y = 0 \\\\\n    y &= \\tan(x) & \\mbox{(particular solution)}\n\\end{align*}\n	4	00:02:00	[jmm] Tue, 08 Aug 2010 00:00:01 -0700	An example given in class (MATH-40) taught by Mr Bigler at Butte Community College on 2010-Aug-24.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
25	Solve the IVP: y' = -x/y; y(0) = 1	Solve the ODE:\n\\begin{align*}\n    \\frac{dy}{dx} &= \\frac{-x}{y} ; \\;\\;\\; y(0) = 1\n\\end{align*}\n	\nFirst solve the ODE (separate and integrate).\n\n\\begin{align*}\n    \\int y \\; dy &= - \\int x \\; dx \\\\\n    \\frac{y^2}{2} &= -\\frac{x^2}{2} + C \\\\\n    y^2 &= -x^2 + C \\\\\n    y &= \\pm \\sqrt{C - x^2}\n\\end{align*}\n\nSubstitute the values of the initial condition ($y(0) = 1$) to find\nthe value of $C$.\n\n\\begin{align*}\n    y(0) &= 1 \\\\\n    1 &= \\pm \\sqrt{C - 0^2} \\\\\n    1 &= \\pm \\sqrt{C} & \\mbox{(cannot be negative)} \\\\\n    y &= \\sqrt{1 - x^2}\n\\end{align*}\n	4	00:02:00	[jmm] Tue, 08 Aug 2010 00:00:02 -0700	An example given in class (MATH-40) taught by Mr Bigler at Butte Community College on 2010-Aug-24.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
18	A pan of hot water is removed ...	Assume that the rate at which radioactive nuclei decay is proporitonal to the\r\nnumber of such nuclei that are present in a given sample.  In a certain sample\r\none-fourth of the original number of radioactive nuclei have undergone\r\ndisintegration in a period of 500 years.\r\n\r\n(a)  What fraction of the original radioactive nuclei will remain after 1000\r\nyears?\r\n(b)  In how many years will one-half of the original number remain?	\\begin{align*}\r\n    \\frac{dA}{dt} &= k \\cdot A \\\\\r\n    A &= A_0 \\cdot e^{k \\cdot t} \\\\\r\n    \\frac{3}{4} A_0 &= A_0 \\cdot e^{k \\cdot 500} \\\\\r\n    k &= \\frac{\\ln(3/4)}{500} \\\\\r\n    A &= A_0 \\cdot e^{ \\frac{\\ln(3/4)}{500} \\cdot t}\r\n\\end{align*}\r\n\r\na)\r\n\\begin{align*}\r\n    t &= 1000 \\;\\; \\mbox{years} \\\\\r\n    z \\cdot A_0 &= A_0 \\cdot e^{ \\frac{\\ln(3/4)}{500} \\cdot 1000} \\\\\r\n    z &= 9/16\r\n\\end{align*}\r\n\r\nb)\r\n\\begin{align*}\r\n    z &= 1/2 \\\\\r\n    t &= ? \\\\\r\n    \\frac{1}{2} &= e^{ \\frac{\\ln(3/4)}{500} \\cdot t} \\\\\r\n    t &= \\frac{ \\ln(1/2) \\cdot 500 }{ \\ln(3/4) } \\\\\r\n      &= 1205 \\;\\; \\mbox{years}\r\n\\end{align*}	4	00:05:00	[jmm] Tue, 21 Sep 2010 20:53:36 -0700	Homework problem #8 from sheet handed out on 9/17/10 in the\nclass MATH-40 taught by Mr Bigler at Butte College.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
2	Devise the formula for the area of a circle.	Devise the formula for the area of a circle.\r\n(HINT: use polar coordinates)	Using a double integral and polar coordinates sum the area from the\r\nradius from $0$ to $r$ and then sum this over all the angles $0$ to $2 \\theta$.\r\n\\begin{align*}\r\n    A &= \\int_0^{2 \\pi} \\int_0^r r \\; dr \\; d\\theta \\\\\r\n      &= \\int_0^{2 \\pi} \\frac{r^2}{2} \\; d\\theta \\\\\r\n      &= \\int_0^{2 \\pi} \\frac{2 \\pi r^2}{2} \\\\\r\n    A &= \\pi \\cdot r^2\r\n\\end{align*}\r\n\r\nAn alternative is to integrate over half the angle and then double it.\r\n\\begin{align*}\r\n    A &= 2 \\cdot \\int_0^{\\pi} \\int_0^r r \\; dr \\; d\\theta \\\\\r\n      &= 2 \\cdot \\int_0^{\\pi} \\Big[ \\frac{r^2}{2} \\Big]_0^r \\; d\\theta \\\\\r\n      &= 2 \\cdot \\int_0^{\\pi} \\frac{r^2}{2} \\; d\\theta \\\\\r\n      &= 2 \\cdot \\int_0^{\\pi} \\frac{r^2}{2} \\cdot \\pi \\\\\r\n    A &= \\pi \\cdot r^2\r\n\\end{align*}	4	00:05:00	[jmm] Thu, 16 Sep 2010 08:59:22 -0700	This example is commonly given in a Calculus 2 (MATH-31) class.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-21 12:50:54-08
53	equation of line through (2, 4, -1) and (5, 0, 7)	Find the equation for the line through point $(2, 4, -1)$ and $(5, 0, 7)$. 	To find the line first find the vector between the points.\nThen find the equation of the line that is parallel to that vector and\nthrough one of the points\n\n\\begin{align*}\nv &= <5 - 2, 0 - 4, 7 - (-1)>\\\\\n &= <3, -4, 8>\n\\end{align*}\n\n\\begin{align*}\nx &= 2 + 3 \\; t\\\\\ny &= 4 - 4 \\; t\\\\\nz &= -1 - 8 \\; t\n\\end{align*}\n\nThere is more than one correct answer depending on which\npoint you choose.	4	00:01:00	[jmm] Tue Feb 16 09:18:45 2010	Problems from Calculus 2 (MATH-32) taught by Mr Bigler at Butte College in 2010.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:37:42-08
54	equation of plane through (2, 1, 3), (3, 3, 5), (1, 3, 6)	Find the equation of the plane through the three points $(2, 1, 3)$, $(3, 3, 5)$ and $(1, 3, 6)$.	First convert the three points in to two vectors with a shared base at one point.\n\n\\begin{align*}\nPQ &= <1, 2, 2>\\\\\nPR &= <-1, 2, 3>\n\\end{align*}\n\nTake the cross product of these two vectors to find the normal vector of the plane.\n\n\\begin{align*}\nPQ \\times PR = <2, -5, 4>\\\\\n\\end{align*}\n\nSubstitute the normal vector and one of the points back in to the general\nequation for a plane for the final answer.\n\n\\begin{align*}\n2(x - 2) - 5 (y - 1) + 4 (z - 3) = 0\n\\end{align*}	4	00:01:00	[jmm] Tue Feb 23 20:12:02 2010	Problems from Calculus 2 (MATH-32) taught by Mr Bigler at Butte College in 2010.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:37:42-08
55	equation of line perpendicular to plane	Find the equation of the line that is perpendicular to the plane\n$3x - 4y + 6z = 1$ and contains the point $(1, 4, 5)$.	First find the normal vector of the plane by extracting the general vector:\n\n\\begin{align*}\n<3, -4, 6>\n\\end{align*}\n\nThen, using the general equation, back substitute using the vector and the point.\n\n\\begin{align*}\nx &= 1 + 3t\\\\\ny &= 4 - 4t\\\\\nz &= 5 + 6t\n\\end{align*}	4	00:01:00	[jmm] Tue Feb 23 20:42:47 2010	Problems from Calculus 2 (MATH-32) taught by Mr Bigler at Butte College in 2010.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:37:42-08
56	equation of line parallel to axis	Find the equation of the line that is parallel to the x axis\n\tand goes through point (2, 3, 4)	The general vector for the x-axis is:\n\\begin{align*}\n<1, 0, 0>\n\\end{align*}\n\nThen, using the general equation, back substitute using the vector and the point.\n\n\\begin{align*}\nx &= 2 + t\\\\\ny &= 3\\\\\nz &= 4\n\\end{align*}\n\nCan be confirmed by verify that when $t=0$ it goes through the point.	4	00:01:00	[jmm] Tue Feb 23 20:46:57 2010	Problems from Calculus 2 (MATH-32) taught by Mr Bigler at Butte College in 2010.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:37:42-08
57	equation of line parallel to 2 planes	Find the equation of the line that goes through $(1, 5, 7)$ and\nis parallel to the planes $2x - y + z = 0$ and $3x + y + 4z = 2$.	The cross product of the normal vectors of the planes will be a\nline parallel to both of them.\n\nFirst find the normal vectors of each plane using the general equation.\n\\begin{align*}\nn_1 &= <2, -1, 1>\\\\\nn_2 &= <3, 1, 4>\n\\end{align*}\n\nThen find the cross product.\n\\begin{align*}\nn_1 \\times n_2 &= <-5, -5, 5>\n\\end{align*}\n\nThen back substitute using the original point to find an equation\nfor the line.\n\\begin{align*}\nx &= 1 - 5t\\\\\nx &= 5 - 5t\\\\\nx &= 7 + 5t\n\\end{align*}\n\nAnother solution is to normalize the resulting vector to $<-1, -1, 1>$.\nSince the result is a scalar multiple (parallel) and also goes through\nthe point it is also a valid solution.\n\\begin{align*}\nx &= 1 - t\\\\\nx &= 5 - t\\\\\nx &= 7 + t\n\\end{align*}	4	00:01:00	[jmm] Tue Feb 23 21:06:56 2010	Problems from Calculus 2 (MATH-32) taught by Mr Bigler at Butte College in 2010.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:37:42-08
58	find intersection of two planes	Find the intersection of the planes $2x + y + 3z = 5$ with $x - y + z = 4$.	First find the normal vectors of each plane then take the cross product to find the equation for a line parallel to both planes.\n\\begin{align*}\nn_1 &= <2, 1, 3>\\\\\nn_2 &= <1, -1, 1>\\\\\nn_1 \\times n_2 &= <4, 1, -3>\n\\end{align*}\n\nThen find an equation for the line intersecting them both.\nSolve the system of equations by setting one variable to zero and then subtracting.\nLook for variables that will cancel out and reduce it to one variable to solve for.\n\\begin{align*}\nz &= 0\\\\\n2x + y &= 5\\\\\nx - y &= 4\\\\\n3x &= 9\\\\\nx &= 3\\\\\ny &= -1\n\\end{align*}\n\nUse the found point and the resultant vector to find a new equation.\n\\begin{align*}\nx &= 3 + 4t\\\\\ny &= -1 + t\\\\\nz &= -3 t\n\\end{align*}\n\nThere is more than one valid solution depending upon which values are chosen.	4	00:01:00	[jmm] Tue Feb 23 22:46:32 2010	Problems from Calculus 2 (MATH-32) taught by Mr Bigler at Butte College in 2010.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:37:42-08
59	find intersection of a line with a plane	Find the intersection of the line\n\\begin{align*}\nx &= 1 + 2t\\\\\ny &= 3 - 6\\\\\nz &= 2 + 2t\n\\end{align*}\nwith the plane\n\\begin{align*}\n3x + y + z &= 8\n\\end{align*}	If there is an answer there will be a single value of $t$ with a valid point on the plane and the line.\n\nSubstitute the line in to the equation for the plane then solve for $t$.\n\\begin{align*}\n3(1 + 2t) + (3 - t) + (2 + 2t) = 8\\\\\n3 + 6t + 3 - t + 2 + 2t = 8\\\\\n8 + 7t = 8\\\\\n7t = 0\\\\\nt = 0\n\\end{align*}\n\nSubstitute $t = 0$ in to the equation for a line results in the point $(1, 3, 2)$.\nSubstituting this point in to the equation for the plane results in $8 = 8$ which is valid meaning there is a point of intersection.\nIf it was invalid this would indicate there is no point of intersection.	4	00:01:00	[jmm] Tue Feb 23 23:43:21 2010	Problems from Calculus 2 (MATH-32) taught by Mr Bigler at Butte College in 2010.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:37:42-08
50	equation of line parallel and through (1, 2, 3)	Find the equation for the line containing the point (1, 2, 3) that\nis parallel to the line:\n\\begin{align*}\nx &= 3 + t\\\\\ny &= 4 - 2t\\\\\nz &= 1 + 5t\n\\end{align*}\n	First, using the equation of a line, find the general vector.\n\n\\begin{align*}\n<1, -2, 5>\n\\end{align*}\n\nThen, using the general equation, back substitute using the vector and the point.\n\n\\begin{align*}\nx &= 1 + t\\\\\ny &= 2 - 2t\\\\\nz &= 3 + 5t\n\\end{align*}\n\nTo verify that it goes through the point $(1, 2, 3)$, $0$ can be plugged\nin for $t$ and calculated for $(x, y, z)$.	4	00:01:00	[jmm] Tue Feb 23 20:19:01 2010	Problems from Calculus 2 (MATH-32) taught by Mr Bigler at Butte College in 2010.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:37:42-08
60	find the volume of a parallelpiped	What is the volume of the parallelpiped (3d parallelogram) \ndefined by the points $(0, 0, 0)$, $(10, 0, 0)$, $(0, 0, 2)$ and $(5, 5, 0)$?	First the vectors must be found that represent the points.\n\\begin{align*}\n\\vec{a} &= <10, 0, 0>\\\\\n\\vec{b} &= <5, 5, 0>\\\\\n\\vec{c} &= <0, 0, 2>\n\\end{align*}\n\nPerform a triple scalar product to compute the volume.\n\\begin{align*}\n|\\vec{a} \\cdot (\\vec{b} \\times \\vec{c})| &= 100\n\\end{align*}	4	00:01:00	[jmm] Tue Feb 23 23:40:20 2010	Problems from Calculus 2 (MATH-32) taught by Mr Bigler at Butte College in 2010.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:37:42-08
61	find the distance between planes	Find the shortest distance between the two planes:\n\\begin{align*}\n3x - y + 2z - 6 &= 0\\\\\n6x - 2y + 4z + 4 &= 0\n\\end{align*}	Find an arbitrary point on the planes by setting two variables to zero\nand solving for the other.\n\\begin{align*}\n(0, 0, 3)\\\\\n(0, 0, -1)\n\\end{align*}\n\nFind the normal vector of one of the planes.\n\\begin{align*}\n\\vec{n} &= <6, -2, 4>\n\\end{align*}\n\nCompute the distance.\n\\begin{align*}\nD &= \\frac{\\lvert \\vec{PQ} \\cdot \\vec{n} \\rvert}{\\lVert \\vec{n} \\rVert}\\\\\n &= \\frac{16}{\\sqrt{56}}\n\\end{align*}	4	00:01:00	[jmm] Wed Feb 24 01:06:47 2010	Problems from Calculus 2 (MATH-32) taught by Mr Bigler at Butte College in 2010.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:37:42-08
443	number conversion	Convert the number 5 to -5 using using binary 2s compliment.	\\begin{verbatim}\n5           (decimal)\n0000_0101   (5 binary)\n1111_1010   (invert all bits (NOT))\n1111_1011   (add one, answer -5)\n\nTo check your answer, do the operation again.\n1111_1011   (-5 binary)\n0000_0100   (invert all bits)\n0000_0101   (add one, answer 5)\n\\end{verbatim}\n	4	00:02:00	[jmm] Sun Nov  8 20:11:00 2009	Problems from Assembly Language Programming (CSCI-10) taught by Boyd Trolinger at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:55:53-08
444	number conversion	Give the 2s compliment binary representation of -32767 (base 10)	\\begin{verbatim}\nConvert 32767 to binary.\n\n32767                      1\n16383                     11\n8191                     111\n4095                    1111\n2047                  1 1111\n1023                 11 1111\n511                 111 1111\n255                1111 1111\n127              1 1111 1111\n63              11 1111 1111\n31             111\n15            1111\n7           1\n3          11\n1         111\n0        0111 1111 1111 1111\n\n0111 1111 1111 1111\t\t32767\n1000 0000 0000 0000\t\tinvert\n1000 0000 0000 0001\t\tadd 1, answer -32767\n\\end{verbatim}\n	4	00:02:00	[jmm] Sun Nov  8 20:15:59 2009	Problems from Assembly Language Programming (CSCI-10) taught by Boyd Trolinger at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:55:53-08
445	number conversion	Convert 12345 (base-10) to hexadecimal using the 'largest power of sixteen' algorithm.	\\begin{verbatim}\nTable of powers of 16\n---------------------\n16^4\t65536\n16^3\t4096\n16^2\t256\n16^1\t16\n16^0\t1\n\n12345 (based 10)\n3*16^3\t12345-12288=57\n0*16^2\n3*16^1\t57-48=9\n9*16^0  \n\n$3039\n\\end{verbatim}\n	4	00:02:00	[jmm] Sun Nov  8 20:18:32 2009	Problems from Assembly Language Programming (CSCI-10) taught by Boyd Trolinger at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:55:53-08
446	number conversion	Convert 33 (base-10) to hexadecimal using the 'largest power of sixteen' algorithm.	\\begin{verbatim}\nTable of powers of 16\n---------------------\n16^2    256\n16^1    16\n16^0    1\n\n33   (base 10)\n2*16^1  33-32=1\n1*16^0\n\n$0021\n\\end{verbatim}\n	4	00:02:00	[jmm] Sun Nov  8 20:20:35 2009	Problems from Assembly Language Programming (CSCI-10) taught by Boyd Trolinger at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:55:53-08
447	number conversion	Give the 2s complement binary representation of 321 (base 10).	\\begin{verbatim}\n2^9 = 512\n2^8 = 256\n2^7 = 128\n2^6 = 64\n2^5 = 32\n2^4 = 16\n2^3 = 8\n2^2 = 4\n2^1 = 2\n2^0 = 1\n\n1*2^8  321-256 = 65\n0*2^7\n1*2^6  65-64 = 1\n0*2^5\n0*2^4\n0*2^3\n0*2^2\n0*2^1\n1*2^0\n\n0000 0001 0100 0001\n\\end{verbatim}	4	00:02:00	[jmm] Sun Nov  8 20:22:43 2009	Problems from Assembly Language Programming (CSCI-10) taught by Boyd Trolinger at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:55:53-08
448	number conversion	Give the 2s complement binary representation of -25 (base 10).	\\begin{verbatim}\ndecimal -> binary\n1*2^4  25 - 16 = 9\n1*2^3  9 - 8 = 1\n0*2^2\n0*2^1\n1*2^0\n\n0001 1001   (25)\n\nFirst Method:\n0001 1001   25\n1110 0110        invert\n1110 0111        add 1\n\n1110 0111   -25  answer)\n\nTo check the answer, perform the procedure again\n0001 1000        invert\n0001 1001        add 1, OK\n\nSecond method:\n0001 1001   25   express as a positive\n---- ---1        start at right, write all bits through first 1\n1110 011-        invert remaining bits\n1110 0111        combine, answer, -25\n1110 0111   -25\n\\end{verbatim}	4	00:02:00	[jmm] Sun Nov  8 20:25:11 2009	Problems from Assembly Language Programming (CSCI-10) taught by Boyd Trolinger at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:55:53-08
449	number conversion	Give the 2s complement binary representation of -1234	\\begin{verbatim}\n1234 (decimal) -> binary\n\n1*2^10  1234-1024 = 210\n0*2^9\n0*2^8\n1*2^7   210 - 128 = 82\n1*2^6   82 - 64 = 18\n0*2^5\n1*2^4   18 - 16 = 2\n0*2^3\n0*2^2\n1*2^1   2 - 2 = 0\n0*2^0   \n\n0100 1101 0010  (1234 binary)\n\n0000 0100 1101 0010\n1111 1011 0010 1101  invert\n1111 1011 0010 1110  add 1, answer -1234\n\ncheck you answer\n0000 0100 1101 0001 invert\n0000 0100 1101 0010 add 1, 1234, OK\n\\end{verbatim}	4	00:02:00	[jmm] Sun Nov  8 20:26:51 2009	Problems from Assembly Language Programming (CSCI-10) taught by Boyd Trolinger at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:55:53-08
450	number conversion	Convert \\verb+0xAA+ (base-16) to decimal.	\\begin{verbatim}\n10*16^1 + 10*16^0 = 170 (decimal)\n\\end{verbatim}	4	00:02:00	[jmm] Sun Nov  8 20:28:52 2009	Problems from Assembly Language Programming (CSCI-10) taught by Boyd Trolinger at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:55:53-08
451	number conversion	Convert \\verb+0x12AB+ (base-16) to decimal.	\\begin{verbatim}\n1*16^3 + 2*16^2 + 10*16^1 + 11*16^0 = 4779 (decimal)\n\\end{verbatim}	4	00:02:00	[jmm] Sun Nov  8 20:29:40 2009	Problems from Assembly Language Programming (CSCI-10) taught by Boyd Trolinger at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:55:53-08
452	number conversion	Subtract 32 from 10 but do the operation in binary.	\\begin{verbatim}\n\nConvert 32 to binary (divide by 2).\n32               0\n16              00\n8              000\n4             0000\n2           0 0000\n1          10 0000\n         0010 0000\n\nConvert 10 to binary (divide by 2). \n10               0\n5               10\n2              010\n1             1010\n         0000 1010\n\nMake 10 negative converting to 2s compliment form.\n         0000 1010  10\n         1111 0101  invert\n         1111 0110  add 1\n         1111 0110  -10\n\nAdd 32 -10\n\n @c 111\n     0010 0000\n   + 1111 0110\n   -----------\n     0001 0110\n\nTo check your answer, convert 22 to binary.\n\n22            0\n11           10\n5           110\n2          0110\n1     0001 0110\n\nCORRECT :-)\n\\end{verbatim}	4	00:02:00	[jmm] Sun Nov  8 20:43:42 2009	Problems from Assembly Language Programming (CSCI-10) taught by Boyd Trolinger at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:55:53-08
453	number conversion	Convert 32165 to hex using "divide by 16"	\\begin{verbatim}\n32165\t\t\t      1\n16082                01\n8041                101\n4020               0101\n2010             0 0101\n1005            10 0101\n502            010 0101\n251           1010 0101\n125         1 \n62         01\n31        101\n15       1101\n7      1 1101\n3     11 1101\n1    111 1101\n    0111 1101 1010 0101\n\n\\end{verbatim}	4	00:02:00	[jmm] Sun Nov  8 20:52:06 2009	Problems from Assembly Language Programming (CSCI-10) taught by Boyd Trolinger at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:55:53-08
454	number conversion	Write all program code to do the following:\\\\\nDefine a record named testRecord with 2 entries, a\nuns16 and a character.\\\\\nCreate an instance of this object and assign 32 to\nits number and 'A' to its character.\nPrint the size of the object.\nClean up any left over objects.\n	\\begin{verbatim}\n\nprogram TestPgm;\n\n#include("stdlib.hhf");\n\ntype\n  testRecord: record\n    num: uns16;\n    chr: char;\n  endrecord;\n\nstatic\n  myRec: pointer to testRecord;\n\nbegin TestPgm;\n  malloc(@size(testRecord));\n  mov(eax, myRec);\n  mov(myRec, eax);\n\n  mov(32, (type testRecord [eax]).num);\n  mov('A', (type testRecord [eax]).chr);\n\n  mov(@size(testRecord), ebx);\n  stdout.put("size: ebx ", (type uns32 ebx), nl);\n\n  free(myRec);\n\nend TestPgm;\n\n\\end{verbatim}	4	00:02:00	[jmm] Sun Nov  8 21:15:16 2009	Problems from Assembly Language Programming (CSCI-10) taught by Boyd Trolinger at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:55:53-08
455	HLA	Provide a detailed description of the static, var, readonly and const data sections of an HLA program.	The static section is used for declaring variables that will possibly be modified.  Initialization is optional.\\\\\n\nThe var section is like the static section but memory is allocated/de-allocated depending on scope.  Most often used for procedures to to allocate/de-allocate memory for a variable when the function is entered.\\\\\n\nThe readonly section is like the static section except the variables must be initialized and they cannot be modified afterwards.\\\\\n\nThe const section declares constant values to be substitued during compile time.\n	4	00:02:00	[jmm] Sun Nov  8 21:52:58 2009	Problems from Assembly Language Programming (CSCI-10) taught by Boyd Trolinger at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:55:53-08
456	HLA	In HLA, when is it appropriate to use the address-of (\\&) operator?  When '\\&' cannot be used, what instruction allows you to access an address in HLA/assembly?	\nThe address-of operator is used to get the memory address of a static variable.\\\\\n\nThe address-of operator cannot be used for dynamic variables such as var but the lea instruction can be used instead.\n	4	00:02:00	[jmm] Sun Nov  8 22:02:37 2009	Problems from Assembly Language Programming (CSCI-10) taught by Boyd Trolinger at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:55:53-08
457	HLA	Perform the logical operation: \\verb+%1010 XOR 1010+.	\n\\begin{verbatim}\n     1010\n XOR 1010\n --------\n     0000\n\\end{verbatim}\n	4	00:02:00	[jmm] Mon Nov  9 11:34:22 2009	Problems from Assembly Language Programming (CSCI-10) taught by Boyd Trolinger at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:55:53-08
458	HLA	Perform the logical operation: \\verb+%11001100 OR %00110001+.	\n\\begin{verbatim}\n    1100 1100\n OR 0011 0001\n ------------\n    1111 1101\n\\end{verbatim}\n	4	00:02:00	[jmm] Mon Nov  9 11:37:06 2009	Problems from Assembly Language Programming (CSCI-10) taught by Boyd Trolinger at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:55:53-08
459	HLA	Perform the logical operation: \\verb+NOT %10000000+	\n\\begin{verbatim}\n NOT 1000 0000\n ------------\n     0111 1111\n\\end{verbatim}\n	4	00:02:00	[jmm] Mon Nov  9 11:39:49 2009	Problems from Assembly Language Programming (CSCI-10) taught by Boyd Trolinger at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:55:53-08
460	HLA	Perform the logical operation: \\verb+%11110000 AND %00001111+.	\n\\begin{verbatim}\n     1111 0000\n AND 0000 1111\n ------------\n     0000 0000\n\\end{verbatim}\n	4	00:02:00	[jmm] Mon Nov  9 11:41:34 2009	Problems from Assembly Language Programming (CSCI-10) taught by Boyd Trolinger at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:55:53-08
461	HLA	Perform the logical operation: \\verb+$F0 OR $0F+ (result in \\$hex)	\\begin{verbatim}\n$F0 -> %1111 0000\n$0F -> %0000 1111\n\n    1111 0000\n OR 0000 1111\n ------------\n    1111 1111\n\n   %1111 1111 -> $FF\n\\end{verbatim}\n	4	00:02:00	[jmm] Mon Nov  9 11:49:01 2009	Problems from Assembly Language Programming (CSCI-10) taught by Boyd Trolinger at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:55:53-08
462	HLA	Perform the logical operation: \\verb+99 OR 99+ (result in decimal)	\\begin{verbatim}\n\n 99 -> binary\n\n 99          1\n 49         11\n 24        011\n 12       0011\n 6      0 0011\n 3     10 0011\n 1    110 0011\n 0   0110 0011\n -------------\n    %0110 0011\n\n 98 -> binary\n\n 98           0\n 49          10\n 24         010\n 12        0010\n 6       0 0010\n 3      10 0010\n 1     110 0010\n 0    0110 0010\n --------------\n     %0110 0010\n\n \n     0110 0011\n XOR 0110 0010\n -------------\n     0000 0001\n\n %0000 0001 -> 1 (decimal)\n\\end{verbatim}\n	4	00:02:00	[jmm] Mon Nov  9 12:04:41 2009	Problems from Assembly Language Programming (CSCI-10) taught by Boyd Trolinger at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:55:53-08
463	HLA	Perform the operation: \\verb#$0F + $01# (result in binary)	\\begin{verbatim}\n\n $0F -> binary\n %0000 1111\n\n $01 -> binary\n %0000 0001\n\n  @c    1 111\n     0000 1111\n   + 0000 0001\n -------------\n    %0001 0000\n\\end{verbatim}\n	4	00:02:00	[jmm] Mon Nov  9 12:15:24 2009	Problems from Assembly Language Programming (CSCI-10) taught by Boyd Trolinger at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:55:53-08
464	HLA	Perform the operation: \\verb#-86 + 100#. Perform the addition in binary and leave the result in binary	\\begin{verbatim}\n\n Convert -86 to 2scompliment form\n\n 86 -> binary\n\n 86          0\n 43         10\n 21        110\n 10       0110\n 5      1 0110\n 2     01 0110\n 1    101 0110\n 0   0101 0110\n\n     1010 1001  invert\n     1010 1010  add 1\n\n 1111 1111 1010 1010  (-86)\n\n 100 -> binary\n 100         0\n 50         00\n 25        100\n 12       0100\n 6      0 0100\n 3     10 0100\n 1    110 0100\n 0   0110 0100\n\n @c  \n     1111 1111 1010 1010  (-86)\n   + 0000 0000 0110 0100  (100)\n -----------------------\n     0000 0000 0000 1110  (14)\n\\end{verbatim}\n	4	00:02:00	[jmm] Mon Nov  9 12:54:47 2009	Problems from Assembly Language Programming (CSCI-10) taught by Boyd Trolinger at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:55:53-08
465	HLA	Perform the operation: \\verb#%1011 + %0101#.	\\begin{verbatim}\n\n @c  \n     1011\n   + 0101\n --------\n  1  0000\n\\end{verbatim}\n	4	00:02:00	[jmm] Mon Nov  9 13:14:55 2009	Problems from Assembly Language Programming (CSCI-10) taught by Boyd Trolinger at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:55:53-08
466	HLA	Perform the operation: \\verb#$00F0 - 1#.	\\begin{verbatim}\n\n $00F0 -> binary\n  0000 0000 1111 0000\n\n 1 -> binary\n  0000 0000 0000 0001\n\n  1111 1111 1111 1110  invert\n  1111 1111 1111 1111  add 1\n\n  @c 11111 1111 111\n      0000 0000 1111 0000  $00F0\n    + 1111 1111 1111 1111  -1\n    ---------------------\n      0000 0000 1110 1111\n\n\\end{verbatim}\n	4	00:02:00	[jmm] Mon Nov  9 13:28:11 2009	Problems from Assembly Language Programming (CSCI-10) taught by Boyd Trolinger at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:55:53-08
467	HLA	Declare a HLA record for SuperHero with the following properties: initial on\ncostume (e.g., Superman would have 'S' on his costume), flies (yes or no),\nstrength (0-255).  Choose the most appropriate HLA data type for each property.	\\begin{verbatim}\ntype\n  SuperHero: record\n\tinitial: char;\n\tflies: boolean;\n\tstrength: uns8;\n  endrecord;\n\\end{verbatim}\n	4	00:02:00	[jmm] Mon Nov  9 15:27:59 2009	Problems from Assembly Language Programming (CSCI-10) taught by Boyd Trolinger at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:55:53-08
468	first problem to test	\n\\begin{equation*}\nx^2 = 4\n\\end{equation*}\n	$x = 2$	4	00:05:55	[jmm] Sun Nov  8 20:01:11 2009	Problems from Assembly Language Programming (CSCI-10) taught by Boyd Trolinger at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:55:53-08
299	find exact sum	\nFind the exact sum:\\\\\n\\begin{equation*}\n\\sum_{n=1}^\\infty \\; 3 \\Big( \\frac{2}{3} \\Big)^{n+1}\\\n\\end{equation*}\n	\n$r = \\frac{2}{3}$\\\\\nSince $n = 1$, (not $n = 0$) write out a the first term to find $a$.\\\\\n\n\\begin{equation*}\na = 3 \\Big( \\frac{2}{3} \\Big)^{2} = \\frac{4}{3}\n\\end{equation*}\n\nSubstitue in to the geometric form $\\frac{a}{1-r}$ to find the exact value.\n\n\\begin{equation*}\n\\frac{\\frac{4}{3}}{1 - \\frac{2}{3}} = 4\n\\end{equation*}\n\n	4	00:03:00	[jmm] Thu Nov  5 14:58:08 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
300	find exact sum (2/n - 2/(n+1))	\nFind the exact sum:\\\\\n\\begin{equation*}\n\\sum_{n=1}^\\infty \\; \\Big( \\frac{2}{n} - \\frac{2}{n+1} \\Big)\\\n\\end{equation*}\nThen find the sum:\n\\begin{equation*}\n\\sum_{n=1}^{100} \\; \\Big( \\frac{2}{n} - \\frac{2}{n+1} \\Big)\\\n\\end{equation*}\n	\nThe exact sum to infinity is: 2\\\\\nThe sum to 100 is: $\\frac{200}{101}$\\\\\n	4	00:03:00	[jmm] Sun Dec 13 23:28:29 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
301	does it converge (n/(3n+1))^n	Does it converge?\\\\\n\\begin{equation*}\n\\sum_{n=1}^\\infty \\; \\Big( \\frac{n}{3n+1} \\Big)^{n}\\\n\\end{equation*}\n	\nUsing the Root Test produces a value of $L = \\frac{1}{3}$ which \nsatisfies $L < 1$ which means it converges.\n	4	00:02:00	[jmm] Sun Dec 13 23:29:20 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
302	does it converge: (n+1)/sqrt(n^4 + n)	Does it converge?\\\\\n\\begin{equation*}\n\\sum_{n=1}^\\infty \\; \\frac{n+1}{\\sqrt{n^4+n}} \\\n\\end{equation*}\n	\nUse Direct Compare with $\\frac{1}{n}$ which diverges.\\\\\n\\begin{align*}\n\ta_n &>= b_n\\\\\n\t\\frac{n+1}{\\sqrt{n^4+n}} &>= \\frac{1}{n}\\\\\n\tn(n + 1) &>= n \\; \\sqrt{n^2+\\frac{1}{n}}\\\\\n\t(n + 1) &>= \\sqrt{n^2+\\frac{1}{n}}\\\\\n\\end{align*}\n\nwhich is true for all $n$.\\\\\nAccording to the Direct Comparison test the series diverges.\n	4	00:03:00	[jmm] Sun Dec 13 23:30:50 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
303	does it converge	Does it converge?\\\\\n\\begin{equation*}\n\\sum_{n=10}^\\infty \\; \\frac{(2n)!}{5^{n}(n+1)!} \\\n\\end{equation*}\n	\nBy the Ratio Test $L < 1$ so it converges.\n	4	00:03:00	[jmm] Thu Nov  5 15:55:32 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
304	does it converge	Does it converge?\\\\\n\\begin{equation*}\n\\sum_{n=1}^\\infty \\; \\Big( \\frac{1}{2} + \\frac{1}{3n} \\Big)\n\\end{equation*}\n	\nDiverges by the Limit Test ($L \\neq 0$).\n	4	00:03:00	[jmm] Thu Nov  5 15:58:37 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
305	does it converge	Does it converge?\\\\\n\\begin{equation*}\n\\sum_{n=1}^\\infty \\; \\frac{2*5*8* \\ldots (3n-1)}{8^n(n+1)!}\n\\end{equation*}\n	\nUsing the Ratio Test a value of $L = \\frac{3}{8}$ satisfies $L < 1$ so it converges.\n	4	00:03:00	[jmm] Thu Nov  5 16:01:21 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
306	does it converge	Does it converge?\\\\\n\\begin{equation*}\n\\sum_{n=1}^\\infty \\; \\frac{(-1)^{n+1} n}{n^2 + 4}\n\\end{equation*}\n	\nUsing the Limit Test, the limit goes to $1$ which is $\\neq 0$ so it diverges.\n	4	00:03:00	[jmm] Thu Nov  5 16:04:14 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
307	does it converge	Does it converge?\\\\\n\\begin{equation*}\n\\sum_{n=1}^\\infty \\; 3 \\; \\Big( \\frac{\\pi}{4} \\Big)^{n}\n\\end{equation*}\n	\nThe series is Geometric and $r = \\frac{\\pi}{4}$ which satisfies $|r| < 1$ so it converges.\n	4	00:03:00	[jmm] Thu Nov  5 16:08:26 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
308	does it converge	Does it converge?\\\\\n\\begin{equation*}\n\\sum_{n=1}^\\infty \\; \\frac{1}{n \\; \\ln(n)}\n\\end{equation*}\n	\nUsing the integral test it diverges.\n	4	00:03:00	[jmm] Thu Nov  5 17:10:38 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
309	does it converge	Does it converge?\\\\\n\\begin{equation*}\n1 + \\frac{1}{4} + \\frac{1}{5} + \\frac{1}{6} + \\frac{1}{7} + \\frac{1}{8} \\ldots\n\\end{equation*}\n	\n\\begin{equation*}\n\\sum_{n=1}^{\\infty} \\frac{1}{n+2}\n\\end{equation*}\n\nDirect compare with $\\frac{1}{n}$ .\n\n\\begin{align*}\n\\frac{1}{n+2} &\\leq \\frac{1}{n}\\\\\nn &\\leq n + 2\\\\\n\\end{align*}\n\nConverges.\n	4	00:03:00	[jmm] Thu Nov  5 17:03:41 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
310	does it converge	Does it converge?\\\\\n\\begin{equation*}\n\\sum_{n=1}^{\\infty} \\frac{4}{\\sqrt[3]{n}}\n\\end{equation*}\n	\n\\begin{equation*}\n\\sum_{n=1}^{\\infty} \\frac{4}{n^{\\frac{1}{3}}}\\\n\\end{equation*}\n\nP Series with $P \\leq 1$, diverges.\n	4	00:03:00	[jmm] Thu Nov  5 17:09:06 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
311	Find series of 3/(5+x)	a) Find the Series centered at $c = -2$ of:\\\\\n\\begin{equation*}\n\\frac{3}{5+x}\n\\end{equation*}\nb) find the radius of convergence ($R$)\\\\\nc) find the interval of convergence\\\\\n	\nSubstitue in to $x$ for $x-c$ leaving the constant $?$ unknown.\n\n\\begin{align*}\n& \\frac{3}{?+(x-(-2))}\\\\\n\\end{align*}\n\nFind a value for $y$ that makes the new denominator equivalent to the\noriginal denominator.\n\n$y \\pm (x + 2) = 5 + x$\n\nChoose a value for $\\pm$ so that $x$ cancels.\n\\begin{align*}\ny + (x + 2) &= 5 + x\\\\\ny + 2 &= 5\\\\\ny  &= 3\\\\\n\\end{align*}\n\nSubstitute in to the original equation:\n\\begin{align*}\n& \\frac{3}{3+(x + 2)}\\\\\n\\end{align*}\n\nFactor the equation to convert it to the form $\\frac{a}{1-r}$.\nAdd a $- (-1)$ to make it negative if needed.\n\n\\begin{align*}\n& \\frac{1}{1-\\frac{(-1)(x + 2)}{3}}\\\\\n\\end{align*}\n\nSubstitute the values in to the original Geometric Sum equation.\n\n\n\\begin{align*}\n& \\sum_{n=0}^{\\infty} \\; \\Big[ \\frac{(-1)(x + 2)}{3} \\Big]^n\\\\\n& \\sum_{n=0}^{\\infty} \\; \\frac{(-1)^{n}(x + 2)^{n}}{3^{n}}\\\\\n\\end{align*}\n\nIt is $n=0$ because it must be $0$ to satisfy the geometric equation.\\\\\n\nRadius of convergence:\\\\\n\\begin{align*}\n& \\Big| \\frac{x+2}{3} \\Big| < 1\\\\\n& \\Big| x+2 \\Big| < 3\\\\\n\\end{align*}\n$ R = 3$\\\\\n\nInterval of convergence:\\\\\n\\begin{align*}\n& \\Big| x+2 \\Big| < 3\\\\\n& -5 < x < 1\\\\\n\\end{align*}\n	4	00:05:00	[jmm] Tue Nov 10 15:15:32 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
323	find series for sin(x)/2x	Find the series for:\n\\begin{align*}\n\\frac{\\sin(x)}{2x}\n\\end{align*}\n	The $x^{2}$ is kept along and just multiplies against the series.\nThen just find the series for $\\cos(x)$.\n\n\\begin{align*}\n\\frac{\\sin(x)}{2x} &= \\frac{1}{2x} \\sin(x)\\\\\n &= \\sum_{n=0}^{\\infty} \\frac{(-1)^{n} \\; x^{2n + 1}}{2 x (2n + 1)!}\n\\end{align*}	4	00:01:00	[jmm] Tue Nov 10 19:57:34 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
312	Find series of x^2 * e^(-x)	a) Find the Power Series for:\\\\\n\\begin{equation*}\nx^{2} \\; e^{-x}\n\\end{equation*}\n	\nFrom the chart of Power Series for Elementary Functions (yellow sheet) we know\nthat:\\\\\n\\begin{equation*}\ne^{x} = \\sum_{n=0}^{\\infty} \\; \\frac{x^{n}}{n!}\n\\end{equation*}\n\nAnd substituting $-x$ for $x$ yields:\n\n\\begin{equation*}\ne^{-x} = \\sum_{n=0}^{\\infty} \\; \\frac{(-x)^{n}}{n!}\n\\end{equation*}\n\nAnd since $x^{2}$ can be considered a constant we have:\n\n\\begin{align*}\nx^{2} \\; e^{-x} &= x^{2} \\; \\sum_{n=0}^{\\infty} \\; \\frac{(-x)^{n}}{n!}\\\\\n&= \\sum_{n=0}^{\\infty} \\; \\frac{ (-1)^{n} \\; x^{n + 2} }{n!}\\\\\n\\end{align*}\n	4	00:05:00	[jmm] Tue Nov 10 15:15:14 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
313	Find the  series of sinh	Develop the series for $sinh(x)$.	We know that the following is true:\n\n\\begin{align*}\nsinh(x) &= \\frac{(e^{x} - e^{-x})}{2}\\\\\n&= \\frac{(e^{x})}{2} - \\frac{(e^{-x})}{2}\\\\\ne^{x} &= \\sum_{n=0}^{\\infty} \\; \\frac{x^{n}}{n!}\\\\\ne^{-x} &= \\sum_{n=0}^{\\infty} \\; \\frac{(-x)^{n}}{n!}\\\\\n\\end{align*}\n\nTherefore:\n\n\\begin{align*}\n\\frac{1}{2} \\; \\sum_{n=0}^{\\infty} \\; \\frac{x^{n}}{n!}\n- \\frac{1}{2} \\;  \\sum_{n=0}^{\\infty} \\; \\frac{(-x)^{n}}{n!}\\\\\n\\end{align*}\n\nWrite out some terms of each and then subtract to find the resulting series:\n\n\\begin{align*}\n& \\frac{1}{2} \\; \\Big[ 1 + x + \\frac{x^2}{2} + \\frac{x^3}{6} + \\frac{x^4}{24} + \\frac{x^{5}}{120} + \\ldots\\\\\n& - \\frac{1}{2} \\; \\Big[ 1 - x + \\frac{x^2}{2} - \\frac{x^3}{6} + \\frac{x^4}{24} - \\frac{x^{5}}{120} + \\ldots\\\\\n&= x + \\frac{x^{3}}{3!} + \\frac{x^{5}}{5!} + \\frac{x^{7}{7!}} + \\ldots\\\\\n\\end{align*}\n\ndeciphering the resultant pattern results in the sum:\n\n\\begin{align*}\n\\sum_{n=0}^{\\infty} \\; \\frac{x^{2 n+1}}{(2 n + 1)!}\\\\\n\\end{align*}\n	4	00:05:00	[jmm] Tue Nov 10 15:37:23 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
314	find series 5/(4-x)	Find the series for:\n\\begin{align*}\n& \\frac{5}{4-x}\\\\\n& c = -2\\\\\n\\end{align*}\n	\n\n\\begin{align*}\n\\frac{5}{? \\pm (x - (x + 2))} &\\\\\ny - (x + 2) &= 4 - 6\\\\\ny - 2 &= 4\\\\\ny  &= 6\\\\\n\\frac{5}{6 - (x + 2)} &\\\\\n\\frac{\\frac{5}{6}}{1 - \\frac{(x + 2)}{6}}\\\\\n \\sum_{n=0}^{\\infty} \\frac{5}{6} \\Big( \\frac{(x+2)}{6} \\Big)^{n}\n\\end{align*}\n\n\\begin{align*}\n\\frac{1}{6} \\Big| x + 2 \\Big| < 1\\\\\n\\Big| x + 2 \\Big| < 6\\\\\n-8 < x < 4\\\\\n\\end{align*}\n	4	00:05:00	[jmm] Tue Nov 10 20:04:33 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
315	find series for 1/x	Find the series for:\n\\begin{align*}\n& \\frac{1}{x}\\\\\n\\end{align*}\n	Convert it to geometric form and find the sum.\n\n\\begin{align*}\n& \\frac{1}{x}\\\\\n& \\frac{1}{1 - (-1) (x - 1)}\\\\\n& \\sum_{n=0}^{\\infty} (-1)^{n} (x - 1)^{n}\n\\end{align*}\n	4	00:05:00	[jmm] Tue Nov 10 15:53:20 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
316	find series for 1/(1+x)	Find the series for:\n\\begin{align*}\n& \\frac{1}{1 + x}\\\\\n\\end{align*}\n	Convert it to geometric form and find the sum.\n\n\\begin{align*}\n& \\frac{1}{1 - (-1)(x)}\\\\\n& \\sum_{n=0}^{\\infty} (-1)^{n} (x)^{n}\n\\end{align*}\n	4	00:05:00	[jmm] Tue Nov 10 15:57:05 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
317	find series for ln(x)	Find the series for:\n\\begin{align*}\n& ln(x)\\\\\n\\end{align*}\n	The integral of $1/x$ is $ln(x)$, so find the series for $1/x$ then integrate\nthat series to find the series for $ln(x)$.\n\n\\begin{align*}\n& ln(x) = \\int \\frac{1}{x}\\\\\n&= \\int \\sum_{n=0}^{\\infty} (-1)^{n} (x-1)^{n}\\\\\n&= \\sum_{n=0}^{\\infty} \\frac{(-1)^{n} (x-1)^{n + 1}}{(n+1)} + C\\\\\n&= \\sum_{n=0}^{\\infty} \\frac{(-1)^{n} (x-1)^{n + 1}}{(n+1)} + 0\\\\\n&= \\sum_{n=0}^{\\infty} \\frac{(-1)^{n} (x-1)^{n + 1}}{(n+1)}\\\\\n\\end{align*}\n	4	00:05:00	[jmm] Tue Nov 10 16:15:34 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
318	find series for arctan(x)	Find the series for:\n\\begin{align*}\n& arctan(x)\\\\\n\\end{align*}\n	The integral of $arctan(x)$ is $\\frac{1}{1+x^{2}}$ which is geometric.\n\n\\begin{align*}\n& \\arctan(x) = \\int \\frac{1}{1 + x^{2}}\\\\\n& = \\int \\frac{1}{1 - (-1) x^{2}}\\\\\n&= \\int \\sum_{n=0}^{\\infty} (-1)^{n} (x)^{2n}\\\\\n&= \\sum_{n=0}^{\\infty} \\frac{(-1)^{n} (x)^{2n + 1}}{(2n+1)} + C\\\\\n&= \\sum_{n=0}^{\\infty} \\frac{(-1)^{n} (x)^{2n + 1}}{(2n+1)} + 0\\\\\n&= \\sum_{n=0}^{\\infty} \\frac{(-1)^{n} (x)^{2n + 1}}{(2n+1)}\\\\\n\\end{align*}\n	4	00:05:00	[jmm] Sun Dec 13 23:42:31 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
319	develop series for e^(x)	Develop the series for:\\\\\n\\begin{align*}\n& e^{x}\\\\\n\\end{align*}\n	Integration and differentiation of $e^{x}$ does not change.\nDevelop the series by using Taylors Theorem to find a few values than\ndecipher the pattern for the sum.\n\n\\begin{align*}\nf(x) &= e^{x} &\\;\\;\\; f(0) &= 1\\\\\nf'(x) &= e^{x} &\\;\\;\\; f'(0) &= 1\\\\\nf''(x) &= e^{x} &\\;\\;\\; f''(0) &= 1\\\\\n&= 1 + x + \\frac{x^{2}}{2!} + \\frac{x^{3}}{3!} + \\ldots\\\\\n&= \\sum_{n=0}^{\\infty} \\frac{x^{n}}{n!}\\\\\n\\end{align*}\n	4	00:05:00	[jmm] Mon Dec 14 01:03:04 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
320	develop series for sin(x)	Develop the series for:\\\\\n\\begin{align*}\n\\sin(x)\\\\\n\\end{align*}\n	Develop the series by using Taylors Theorem.\n\n\\begin{align*}\nf(x) &= \\sin(x) &\\;\\;\\; f(0) &= 0\\\\\nf'(x) &= \\cos(x) &\\;\\;\\; f'(0) &= 1\\\\\nf''(x) &= -\\sin(x) &\\;\\;\\; f''(0) &= 0\\\\\nf'''(x) &= -\\cos(x) &\\;\\;\\; f'''(0) &= -1\\\\\n&= 0 + x + 0 - \\frac{x^{3}}{3!} + 0 + \\frac{x^{5}}{5!} + \\ldots\\\\\n&= x - \\frac{x^{3}}{3!} + \\frac{x^{5}}{5!} + \\ldots\\\\\n&= \\sum_{n=0}^{\\infty} \\frac{(-1)^{n} x^{2n + 1}}{(2n + 1)!}\\\\\n\\end{align*}\n	4	00:05:00	[jmm] Mon Dec 14 01:02:46 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
321	find series for x*e^(2x)	Find the series for:\\\\\n\\begin{align*}\nx e^{2x}\\\\\n\\end{align*}\n	The $x$ is kept along and just multiplies against the series.\nThen just plug in $2x$ for $x$ in the series of $e^{x}$.\n\n\\begin{align*}\nx e^{2x} &= x \\sum_{n=0}^{\\infty} \\frac{2x^{n}}{n!}\n\\end{align*}\n	4	00:01:00	[jmm] Tue Nov 10 19:49:34 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
322	find series for x^2*cos(x)	Find the series for:\n\\begin{align*}\nx^{2} \\cos(x)\\\\\n\\end{align*}\n	The $x^{2}$ is kept along and just multiplies against the series.\nThen just find the series for $\\cos(x)$.\n\n\\begin{align*}\nx^{2} \\cos(x) &= x^{2} \\sum_{n=0}^{\\infty} \\frac{(-1)^{n} \\; x^{2n}}{(2n)!}\n\\end{align*}	4	00:01:00	[jmm] Tue Nov 10 19:54:30 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
324	find series for (cos(2x))^2	Find the series for:\n\\begin{align*}\n\\cos^{2}(2x)\\\\\n\\end{align*}\n	\n\\begin{align*}\n\\cos^{2}(2x) &= \\frac{1}{2} + \\frac{\\cos(4x)}{2}\\\\\n &= \\frac{1}{2} + \\sum_{n=0}^{\\infty} \\frac{(-1)^{n} \\; (4x)^{2n}}{2 (2n)!}\n\\end{align*}	4	00:02:00	[jmm] Tue Nov 10 20:03:45 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
325	find series for sin^2(3x)	Find the series for:\n\\begin{align*}\n\\sin^{2}(3x)\\\\\n\\end{align*}\n	\n\\begin{align*}\n\\sin^{2}(3x) &= \\frac{1}{2} - \\frac{\\cos(6x)}{2}\\\\\n &= \\frac{1}{2} - \\sum_{n=0}^{\\infty} \\frac{(-1)^{n} \\; (6x)^{2n}}{2 (2n)!}\n\\end{align*}	4	00:02:00	[jmm] Tue Nov 10 20:09:23 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
326	find series for sin(2x)*cos(2x)	Find the series for:\n\\begin{align*}\n\\sin(2x) \\cos(2x)\\\\\n\\end{align*}\n	\n\\begin{align*}\n\\sin(2x) \\cos(2x) &= \\frac{1}{2} \\Big[ \\sin(4x) + \\sin(0) \\Big]\\\\\n&= \\frac{1}{2} \\sin(4x)\\\\\n&= \\frac{1}{2} \\sum_{n=0}^{\\infty} \\frac{(-1)^{n} \\; (4x)^{2n + 1}}{2n + 1)!}\\\\\n\\end{align*}	4	00:02:00	[jmm] Tue Nov 10 20:13:25 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
327	develop series for cosh(x)	Develop the series for:\n\\begin{align*}\n\\cosh(x)\\\\\n\\end{align*}\n	\n\\begin{align*}\n\\cosh(x) &= \\frac{e^{-x} + e^{x}}{2}\\\\\n&= \\frac{1}{2} \\Big[ e^{-x} + e^{x} \\Big]\\\\\n&= \\frac{1}{2} \\Big[\n\\Big[1 - x + \\frac{x^{2}}{2!} - \\frac{x^{3}}{3!} + \\frac{x^{4}}{4!} - \\ldots \\Big]\n+ \\Big[1 + x + \\frac{x^{2}}{2!} + \\frac{x^{3}}{3!} + \\frac{x^{4}}{4!} + \\ldots \\Big]\n\\Big]\\\\\n&= \\frac{1}{2} \\Big[2 + \\frac{2x^{2}}{2!} + \\frac{2x^{4}}{4!} - \\ldots \\Big]\\\\\n&= \\Big[1 + \\frac{x^{2}}{2!} + \\frac{x^{4}}{4!} - \\ldots \\Big]\\\\\n&= \\sum_{n=0}^{\\infty} \\frac{x^{2n}}{(2n)!}\\\\\n\\end{align*}	4	00:03:00	[jmm] Tue Nov 10 20:40:29 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
328	int(x*cos(4x))	Integrate\n\\begin{align*}\n\t\\int x \\cos(4x) \\; dx\n\\end{align*}	Integration by parts.\n\n\\begin{align*}\n\t\\int{x \\cos(4x)} \\; dx\n\\end{align*}\n\n\\begin{tabular}{l l}\n\t$u = x$ & $dv = \\cos(4x) \\; dx$\\\\\n\t$du = dx$ & $v = \\frac{\\sin(4x)}{4}$\n\\end{tabular}\n\n\\begin{align*}\n\t&\\frac{x \\sin(4x)}{4} - \\int{\\frac{\\sin(4x)}{4}} \\; dx\\\\\n\t&\\frac{x \\sin(4x)}{4} + \\frac{\\cos(4x)}{16} + C\n\\end{align*}\n	10	00:03:00	[jmm] Sat Dec 12 20:58:48 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
329	int(arctan(2x))	Integrate:\n\\begin{align*}\n\t\\int \\arctan(2x) \\; dx\n\\end{align*}	Integration by parts.\n\n\\begin{align*}\n\t\\int \\arctan(2x) \\; dx\n\\end{align*}\n\n\\begin{tabular}{l l}\n\t$u = \\arctan(x)$ & $dv =  dx$\\\\\n\t$du = \\frac{2}{1 + (2x)^2} \\; dx$ & $v = x$\\\\\n\\end{tabular}\n\n\\begin{align*}\n\t&x \\cdot \\arctan(2x) - \\int \\frac{2x}{1 + (2x)^2} \\; dx\\\\\n\t&x \\cdot \\arctan(2x) - 2 \\int \\frac{x}{1 + 4x^2} \\; dx\\\\\n\t&x \\cdot \\arctan(2x) - \\frac{\\ln(1 + 4x^2)}{4} + C\n\\end{align*}	8	00:03:00	[jmm] Sat Dec 12 21:22:14 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
330	int(arcsin(x))	Integrate:\n\\begin{align*}\n\t\\int \\arcsin(x) \\; dx\n\\end{align*}	Integration by parts.\n\n\\begin{align*}\n\t\\int \\arcsin(x) \\; dx\n\\end{align*}\n\n\\begin{tabular}{l l}\n\t\\; $u = \\arcsin(x)$ & $dv =  dx$\\\\\n\t$du = \\frac{1}{\\sqrt{1 - x^2}} \\; dx$ & \\; $v = x$\\\\\n\\end{tabular}\n\n\\begin{align*}\n\t&x \\cdot \\arcsin(x) - \\int \\frac{x}{\\sqrt{1 + x^2}} \\; dx\\\\\n\t&x \\cdot \\arcsin(x) + \\sqrt{1 + x^2} + C\n\\end{align*}	8	00:03:00	[jmm] Sat Dec 12 21:39:05 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
331	int(x*e^(-2*x))	Integrate:\n\\begin{align*}\n\t\\int x \\cdot e^{-2x} \\; dx\n\\end{align*}	Integration by parts using the table method is the easiest way.\n\n\\begin{align*}\n\t\\int x \\cdot e^{-2x} \\; dx\\\\\n\t-\\frac{x e^{-2x}}{2} - \\frac{e^{-2x}}{4}\n\\end{align*}	8	00:03:00	[jmm] Sat Dec 12 21:52:28 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
332	int(x*e^(-2*x^2))	Integrate:\n\\begin{align*}\n\t\\int x \\cdot e^{-2x^2} \\; dx\n\\end{align*}	Let $u = -2x^2$ and $du = -4x$.\n\n\\begin{align*}\n\t&\\int x \\cdot e^{-2x^{2}} \\; dx\\\\\n\t&\\int e^u \\; du\\\\\n\t&-\\frac{e^{-2x^2}}{4}\n\\end{align*}	8	00:03:00	[jmm] Sat Dec 12 22:16:35 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
333	int(sqrt(t)*ln(t))	Integrate:\n\\begin{align*}\n\t\\int \\sqrt{t} \\cdot \\ln(t) \\; dt\n\\end{align*}	Integrate by parts.\n\n\\begin{align*}\n\t\\frac{2t^{3/2}(\\ln(t) \\cdot 3 - 2)}{9}\n\\end{align*}	6	00:03:00	[jmm] Sat Dec 12 22:23:09 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
334	int(sin^3(2x))	Integrate:\n\\begin{align*}\n\t\\int \\sin^3(2x) \\; dx\n\\end{align*}	\\begin{align*}\n\t\\int \\sin^3(2x) \\; dx\n\\end{align*}\n\n\\begin{align*}\n\t&\\int \\sin^3(2x) \\; dx\\\\\n\t&\\int \\sin(2x) \\cdot (1 - \\cos^2(2x)) \\; dx\\\\\n\t&\\int \\sin(2x)  - \\int \\sin(2x) \\cdot \\cos^2(2x)) \\; dx\\\\\n\t&\\frac{\\cos^3(2x)}{6} - \\frac{\\cos(2x)}{2} \n\\end{align*}	6	00:03:00	[jmm] Sat Dec 12 23:00:18 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
335	int(cos^2(2x))	Integrate:\n\\begin{align*}\n\t\\int \\cos^2(2x) \\; dx\n\\end{align*}	\\begin{align*}\n\t&\\int \\cos^2(2x) \\; dx\\\\\n\t&\\int \\frac{1 + \\cos(4x)}{2} \\; dx\\\\\n\t&\\frac{1}{2} \\int \\; dx + \\frac{1}{2} \\int \\cos(4x) \\; dx\\\\\n\t&\\frac{x}{2} + \\frac{\\sin(4x)}{8}\n\\end{align*}	6	00:03:00	[jmm] Sat Dec 12 23:09:19 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
336	int(sec^2(x)*tan(x))	Integrate:\n\\begin{align*}\n\t\\int \\sec^2(x) \\cdot \\tan(x) \\; dx\n\\end{align*}	\\begin{align*}\n\t&\\int \\sec^2(x) + \\tan(x) \\; dx\\\\\n\t&\\int \\sec(x) \\cdot \\sec(x) \\cdot \\tan(x) \\; dx\\\\\n\t&\\frac{\\sec^2(x)}{2}\n\\end{align*}	6	00:03:00	[jmm] Sat Dec 12 23:15:53 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
337	int(cos^2(2x)*sin(2x))	Integrate:\n\\begin{align*}\n\t\\int \\cos^2(2x) \\cdot \\sin(2x) \\; dx\n\\end{align*}	\\begin{align*}\n\t&\\int \\cos^2(2x) \\cdot \\sin(2x) \\; dx\\\\\n\t&\\frac{1}{2} \\cdot \\int \\cos^2(2x)(-2)\\sin(2x) \\; dx\\\\\n\t&-\\frac{\\cos^3(2x)}{6}\n\\end{align*}	6	00:03:00	[jmm] Sat Dec 12 23:44:44 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
338	int(sec^3(x)*tan(x))	Integrate:\n\\begin{align*}\n\t\\int \\sec^3(x) \\cdot \\tan(x) \\; dx\n\\end{align*}	\\begin{align*}\n\t&\\int \\sec^3(x) \\cdot \\tan(x) \\; dx\\\\\n\t&\\int \\sec^2(x) \\cdot \\sec(x) \\cdot \\tan(x) \\; dx\\\\\n\t&\\frac{\\sec^3(x)}{3}\n\\end{align*}	6	00:03:00	[jmm] Sat Dec 12 23:50:43 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
339	int(sec^3(x)*tan^3(x))	Integrate:\n\\begin{align*}\n\t\\int \\sec^3(x) \\cdot \\tan^3(x) \\; dx\n\\end{align*}	\\begin{align*}\n\t&\\int \\sec^3(x) \\cdot \\tan^3(x) \\; dx\\\\\n\t&\\int \\sec^2(x) \\cdot \\tan^2(x) \\cdot \\sec(x) \\cdot \\tan(x) \\; dx\\\\\n\t&\\int \\sec^2(x) \\cdot (\\sec^2(x) - 1) \\cdot \\sec(x) \\cdot \\tan(x) \\; dx\\\\\n\t&\\int (\\sec^4(x) - \\sec^2(x)) \\cdot \\sec(x) \\cdot \\tan(x) \\; dx\\\\\n\t&\\int (\\sec^4(x) \\cdot \\sec(x)) \\cdot \\tan(x)\n\t\t-\\int (\\sec^2(x) \\cdot \\sec(x)) \\cdot \\tan(x)\\\\\n\t&\\frac{\\sec^5(x)}{5} - \\frac{\\sec^3(x)}{3}\n\\end{align*}	6	00:03:00	[jmm] Sun Dec 13 00:03:30 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
340	int(x/sqrt(9-x^2))	Integrate:\n\\begin{align*}\n\t\\int \\frac{x}{\\sqrt{9 - x^2}} \\; dx\n\\end{align*}	Use trig substitution.\n\n\\begin{align*}\n\tx &= 3 \\cdot \\sin(\\theta)\\\\\n\tdx &= 3 \\cdot \\cos(\\theta) \\; d\\theta\\\\\n\t\\sqrt{} &= 3 \\cdot \\cos(\\theta)\n\\end{align*}\n\n\\begin{align*}\n\t&\\int \\frac{3 \\sin(\\theta) 3 \\cos(\\theta) \\; d\\theta}{3 \\cos(\\theta)}\\\\\n\t&3 \\int \\sin(\\theta) \\; d\\theta\\\\\n\t&-3 \\cos(\\theta) \\; d\\theta\\\\\n\t&-\\sqrt{9 - x^2} + C\n\\end{align*}	6	00:03:00	[jmm] Sun Dec 13 13:34:17 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
341	int(x/sqrt(x^2-9))	Integrate:\n\\begin{align*}\n\t\\int \\frac{x}{\\sqrt{x^2 - 9}} \\; dx\n\\end{align*}	Use trig substitution.\n\n\\begin{align*}\n\tx &= 3 \\cdot \\sec(\\theta)\\\\\n\tdx &= 3 \\cdot \\sec(\\theta) \\cdot \\tan(\\theta) \\; d\\theta\\\\\n\t\\sqrt{} &= 3 \\cdot \\tan(\\theta)\n\\end{align*}\n\n\\begin{align*}\n\t&\\int \\frac{3 \\sec(\\theta) 3 \\sec(\\theta) \\tan(\\theta) \\; d\\theta}\n\t\t{3 \\tan(\\theta)}\\\\\n\t&3 \\sec^2(\\theta) \\; d\\theta\\\\\n\t&3 \\tan(\\theta)\\\\\n\t&\\sqrt{x^2 - 9} + C\n\\end{align*}	6	00:03:00	[jmm] Sun Dec 13 13:38:53 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
342	int(x^2/sqrt(x^2 + 16))	Integrate:\n\\begin{align*}\n\t\\int \\frac{x^2}{\\sqrt{x^2 + 16}} \\; dx\n\\end{align*}	Use trig substitution.\n\n\\begin{align*}\n\tx &= 4 \\cdot \\tan(\\theta)\\\\\n\tdx &= 4 \\cdot \\sec^2(\\theta) \\; d\\theta\\\\\n\t\\sqrt{} &= 4 \\cdot \\sec(\\theta)\n\\end{align*}\n\n\\begin{align*}\n\t&\\int \\frac{(4 \\tan(\\theta))^2 4 \\sec^2(\\theta) \\; d\\theta}\n\t\t{4 \\sec(\\theta)}\\\\\n\t&4^2 \\int \\tan^2(\\theta) \\sec(\\theta) \\; d\\theta\\\\\n\t&4^2 \\Big[ \\int \\sec^3(\\theta) \\; d\\theta - \\int \\sec(\\theta) \\; d\\theta \\Big]\\\\\n\\end{align*}\nThe rest is done using trig identities.\n	6	00:03:00	[jmm] Sun Dec 13 13:44:13 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
343	int((2x^2-x+4)/(x(x^2+4)))	Integrate:\n\\begin{align*}\n\t\\int \\frac{2x^2-x+4}{x (x^2+4)} \\; dx\\\\\n\\end{align*}	\\begin{align*}\n\t\\int \\frac{2x^2-x+4}{x (x^2+4)} \\; dx\\\\\n\\end{align*}\n\nFirst reduce the equation using Partial Fractions of case 3.\n\n\\begin{align*}\n\t\\frac{2x^2-x+4}{x (x^2+4)} &= \\frac{A}{x} + \\frac{Bx+C}{(x^2+4)}\\\\\n\t2x^2 - x + 4 &= A(x^2 + 4) + x (Bx+C)\\\\\n\t2x^2 - x + 4 &= Ax^2 + 4A + Bx^2 + Cx\\\\\n\t2x^2 - x + 4 &= Ax^2 +Bx^2 + Cx + 4A\\\\\n\t2x^2 &= Ax^2 + Bx^2\\\\\n\tA + B &= 2\\\\\n\t-x &= Cx\\\\\n\tC &= -1\\\\\n\t4 &= 4A\\\\\n\tA &= 1\\\\\n\tB &= 1\n\\end{align*}\n\n\\begin{align*}\n\t&\\int \\frac{1}{x} \\; dx + \\int \\frac{x - 1}{x^2 + 4} \\; dx\\\\\n\t&\\int \\frac{1}{x} \\; dx + \\int \\frac{x}{x^2 + 4} \\; dx + \\int \\frac{1}{x^2 + 4} \\; dx\\\\\n\t&\\ln(x) + \\frac{\\ln(x^2+4)}{2} - \\frac{\\arctan(\\frac{x}{2})}{2} + C\n\\end{align*}	10	00:07:00	[jmm] Sun Dec 13 15:53:06 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
344	find the limit sin(x)/x	Find the limit:\\\\\n\\begin{align*}\n\\lim_{x \\rightarrow 0} \\frac{\\sin(x)}{x}\\\n\\end{align*}	\\begin{align*}\n\\lim_{x \\rightarrow 0} \\frac{\\sin(x)}{x} &= 1\\\n\\end{align*}\nThis may seem odd knowing that $sin(0) = 0$ and $0/0$ is indeterminate.\nBut knowing that it is a limit where $x$ gets close to $0$ but never quite\nreaches $0$ it makes sense.\n\\begin{align*}\n\\frac{\\sin(0.000001)}{0.000001} &= 1\\\n\\end{align*}	3	00:05:55	[jmm] Sun Nov 15 20:16:10 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
345	limit (1 + 4/x)^x	Find the limit of:\n\\begin{align*}\n\t\\lim_{x \\rightarrow \\infty} \\Big( 1 + \\frac{4}{x} \\Big)^x\n\\end{align*}	Because the limit has an exponent, take the log of both sides.\n\nConvert $x$ to $1/x$ in the denominator.\nThe limit is indeterminate when $0/0$ so use Hopitals Rule.\n\\begin{align*}\n\ty &= \\lim_{x \\rightarrow \\infty} \\Big( 1 + \\frac{4}{x} \\Big)^x\\\\\n\t\\ln(y) &= \\lim_{x \\rightarrow \\infty} x \\cdot \\ln \\Big( 1 + \\frac{4}{x} \\Big)\\\\\n\t&=  \\lim_{x \\rightarrow \\infty} \\frac{\\ln \\Big( 1 + \\frac{4}{x} \\Big)}\n\t\t{\\frac{1}{x}}\\\\\n\t&= \\frac{0}{0}\\\\\n\t&= \\lim_{x \\rightarrow \\infty} \\frac{-\\frac{4}{x(x+4)}}{-\\frac{1}{x^2}}\\\\\n\t&= \\lim_{x \\rightarrow \\infty} \\frac{4x^2}{x(x+4)}\\\\\n\t&= \\lim_{x \\rightarrow \\infty} \\frac{4x}{(x+4)}\\\\\n\t&= \\lim_{x \\rightarrow \\infty} \\frac{4}{(1 + \\frac{4}{x})}\\\\\n\t&= 4\\\\\n\t\\ln(y) &= 4\\\\\n\ty &= e^{4}\n\\end{align*}	10	00:05:00	[jmm] Sun Dec 13 17:29:01 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
346	center of mass of y=x^2-2x, y=2x	Where is the center of mass of the area between $y = x^2-2x$ and $y = 2x$?	Exact answers are not shown.  The answer is correct as long as it is\nsetup correct.\n\n\\begin{align*}\n\tM_y &= p \\cdot \\sum x \\cdot (2x) - (x^2 - 2x) \\cdot \\Delta x\\\\\n\t    &= p \\cdot \\int_{0}^{4} p \\cdot \\sum (2x) - (x^2 - 2x)\\\\\n\tM_x &= p \\cdot \\sum \\frac{(2x + (x^2 - 2x))}{2} \\cdot (2x - (x^2 - 2x)) \\cdot \\Delta x\\\\\n\t    &= p \\cdot \\int_{0}^{4} \\frac{(2x + (x^2 - 2x))}{2} \\cdot (2x - (x^2 - 2x)) \\cdot \\; dx\\\\\n\tm &= p \\cdot \\sum (2x) - (x^2 - 2x) \\cdot \\Delta x\\\\\n\tx &= \\frac{M_y}{m}\\\\\n\tx &= \\frac{M_x}{m}\n\\end{align*}	8	00:02:00	[jmm] Sat Dec 12 16:56:02 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
369	arc length: x = t^2-2*t+1, y = 4-t^3	\\begin{align*}\n\tx &= t^2 - 2t + 1\\\\\n\ty &= 4 - t^3\n\\end{align*}\nFind the arc length from $(0, 3)$ to $(9, -60)$	\\begin{align*}\n\t\\frac{dx}{dt} &= 2t - 2\\\\\n\t\\frac{dy}{dt} &= -3t^2\\\\\n\\end{align*}\n\nTo find $t$ plug in values for $x$ or $y$ (which ever is easiest) and solve.\n\n\\begin{align*}\n\t3 &= 4 - t^3\\\\\n\t1 &= -t^3\\\\\n\tt &= 1\\\\\n\t-60 &= 4 - t^3\\\\\n\t-64 &= -t^3\\\\\n\t64 &= t^3\\\\\n\tt &= 4\n\\end{align*}\n\n\\begin{align*}\n\t\\int_{t=1}^{t=4}{\\sqrt{(2t-2)^2+(-3t)^2} \\; dt} &= 63.6481\n\\end{align*}	3	00:08:00	[jmm] Tue Dec  8 23:26:31 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
347	center of mass of y=x^2-2x, y=2x	Of the area contained by the equations:\n\\begin{align*}\n\tx &= 1 - y\\\\\n\tx &= e^y\\\\\n\ty &= 3\n\\end{align*}\n\nWhere is the center of mass located?	Since this is in terms of $x$ ($x = y$) the strip is horizontal.\n\n\\begin{align*}\n\tm &= p \\sum \\Delta A\\\\\n\t  &= p \\int_{0}^{3} e^y - (1 - y)\\\\\n\t  &= p \\cdot e^{3} + \\frac{1}{2}\\\\\n\t  &= p \\cdot 20.58\n\\end{align*}\n\n\\begin{align*}\n\tM_x &= p \\sum (moment \\; arm \\; to \\; x \\; axis) \\cdot \\Delta A\\\\\n\t    &= p \\sum y \\cdot (e^y - (1 - y)) \\Delta y\\\\\n\t    &= p \\cdot \\int_{0}^{3} y \\cdot (e^y - 1 + y)) \\; dy\\\\\n\t\t&= p \\cdot 45.6711\n\\end{align*}\n\n\\begin{align*}\n\tM_y &= p \\sum (moment \\; arm \\; to \\; y \\; axis) \\cdot \\Delta A\\\\\n\t    &= p \\sum \\frac{(1 - y) + e^y}{2} \\cdot (e^y - (1 - y)) \\Delta y\\\\\n\t    &= p \\cdot \\int_{0}^{3} \\frac{(1 - y) + e^y}{2} \\cdot (e^y - (1 - y)) \\; dy\\\\\n\t\t&= p \\cdot 99.1072\n\\end{align*}\n\n\\begin{align*}\n\tx &= \\frac{M_y}{m}\\\\\n\t  &= 4.815\\\\\n\ty &= \\frac{M_x}{m}\\\\\n\t  &= 2.219\\\\\n\t  &(x, y) = (4.815, 2.219)\n\\end{align*}	8	00:02:00	[jmm] Sat Dec 12 17:15:53 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
348	solve integral \\int 4x	Solve the integral:\\\\\n\\begin{align*}\n\\int \\; 4x \\; dx\n\\end{align*}	\\begin{align*}\n2x^{2} + C\n\\end{align*}\n	4	00:05:55	[jmm] Sun Nov 15 19:52:36 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
349	solve integral x^2/(x^2+4)	Find the integral:\\\\\n\\begin{align*}\n& \\int \\frac{x^{2}}{x^{2}+4} dx\\\n\\end{align*}	\\begin{align*}\n& \\int \\frac{x^{2}}{x^{2}+4} dx\\\\\n& \\frac{x^2}{x^2-4} = 1 - \\frac{4}{x^2+4}  \\qquad\\text{(long division steps not show)}\\\\\n& \\int dx - 4 \\int \\frac{1}{x^{2}+4} dx\\\\\n& x - 4 \\frac{1}{2} \\arctan(\\frac{x}{2}) + C\\\\\n& x - 2 \\arctan(\\frac{x}{2}) + C\\\\\n\\end{align*}\nSee [ \\href{http://en.wikipedia.org/wiki/Polynomial_long_division}{wikipedia:Polynomial Long Division} ] for a detailed description and examples of performing Polynomial Long Division.	4	00:01:00	[jmm] Sun Nov 15 20:35:39 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
350	solve integral (tan(x))^2	Find the integral:\\\\\n\\begin{align*}\n& \\int (\\tan(x))^{2} dx\\\n\\end{align*}	\\begin{align*}\n& \\int (\\tan(x))^{2} dx\\\\\n& \\int (\\sec(x))^{2} - 1 \\  dx\\\\\n& \\int (\\sec(x))^{2} dx \\; - \\int dx\\\\\n& \\tan(x) - x + C\\\\\n\\end{align*}	4	00:02:00	[jmm] Sun Nov 15 20:45:31 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
351	find integral 1/(x^2-4)	Find the integral:\\\\\n\\begin{align*}\n& \\int \\frac{dx}{x^2-4}\\\n\\end{align*}	It must be multiplied by $-1$ to swap the signs so that it matches\nthe integration rule (see Pink sheet) correctly.\n\\begin{align*}\n&\\;\\;\\;\\int \\frac{dx}{x^2-4}\\\\\n&-\\int \\frac{dx}{4-x^2}\\\\\n&-\\int \\frac{du}{a^2-u^2}\\\\\n&-\\frac{1}{4} \\ln \\Big( \\frac{2+x}{2-x} \\Big) + C\\\\\n\\end{align*}	4	00:02:00	[jmm] Sun Nov 15 21:24:46 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
352	differentiate (x^2+2)^3	Differentiate:\\\\\n\\begin{align*}\ng(x) &= (x^{2} + 2)^{3}\\\\\n\\end{align*}	\\begin{align*}\ng(x) &= (x^{2} + 2)^{3}\\\\\nu &= (x^{2} + 2)\\\\\ndu &= 2x\\\\\ng'(x) &= 6x (x^{2} + 2)^{2}\\\\\n\\end{align*}	3	00:01:00	[jmm] Sun Nov 15 21:42:30 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
353	integrate sin(2x)	Integrate:\\\\\n\\begin{align*}\n\\int &\\sin(2x) dx\\\\\n\\end{align*}	\\begin{align*}\n\\int &\\sin(2x) dx\\\\\nu &= 2x\\\\\ndu &= 2\\\\\n\\frac{1}{2} &\\int \\sin(2x) \\; 2 \\; dx\\\\\n-\\frac{1}{2} &\\int \\cos(2x) + C\\\\\n\\end{align*}	3	00:01:00	[jmm] Sun Nov 15 21:46:28 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
354	integrate sin(x)^2 * cos(x)	Integrate:\\\\\n\\begin{align*}\n\\int &(\\sin(x))^{2} \\cos(x) dx\\\\\n\\end{align*}	\\begin{align*}\n\\int &(\\sin(x))^{2} \\cos(x) dx\\\\\nu &= \\sin(x)\\\\\ndu &= \\cos(x)\\\\\n\\int &(u)^{n} du = \\frac{u^{n + 1}}{n + 1} + C\\\\\n\\int & \\frac{\\sin(x)^{3}}{3} + C\\\\\n\\end{align*}	3	00:01:00	[jmm] Sun Nov 15 21:53:17 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
355	integrate (x^2+4)/x	Integrate:\\\\\n\\begin{align*}\n& \\int \\frac{x^{2}+4}{x} dx\\\\\n\\end{align*}	\\begin{align*}\n& \\int \\frac{x^{2}+4}{x} dx\\\\\n= &\\int x dx + \\int \\frac{4}{x} dx\\\\\n= &\\frac{x^{2}}{2} + 4 \\ln|x| + C\\\\\n\\end{align*}	3	00:01:00	[jmm] Sun Nov 15 21:59:35 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
356	integrate cos^3(x) * sin(x)	Integrate:\\\\\n\\begin{align*}\n& \\int (\\cos(x))^{3} \\sin(x) dx\\\\\n\\end{align*}	\\begin{align*}\n& \\int (\\cos(x))^{3} \\sin(x) dx\\\\\nu &= \\cos(x)\\\\\ndu &= -\\sin(x)\\\\\n&\\int (u)^{n} du = \\frac{u^{n + 1}}{n + 1} + C, n \\ne 1\\\\\n& -\\int (\\cos(x))^{3} (-\\sin(x)) dx\\\\\n& -\\frac{(\\cos(x))^{4}}{4} + C\\\\\n\\end{align*}	4	00:02:00	[jmm] Sun Nov 15 22:02:43 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
357	convert y = x + 1 to parametric and polar	Given the rectangular equation:\n\\begin{align*}\n\ty &= x + 1\n\\end{align*}\nConvert it in to 3 different parametric forms and 1 polar form.	Rectangular converted to parametric.\n\\begin{align*}\n\tx &= t\\\\\n\ty &= t + 1\\\\\n\tx &= t - 1\\\\\n\ty &= t\\\\\n\tx &= 2t + 3\\\\\n\ty &= 2t + 4\n\\end{align*}\n\nRectangular converted to polar.\n\\begin{align*}\n\tx &= r \\cos(\\theta)\\\\\n\ty &= r \\sin(\\theta)\\\\\n\tr \\sin(\\theta) &= r \\cos(\\theta) + 1\\\\\n\tr (\\sin(\\theta) -\\cos(\\theta)) &= 1\\\\\n\tr &= \\frac{1}{\\sin(\\theta) -\\cos(\\theta)}\n\\end{align*}	5	00:02:00	[jmm] Mon Dec  7 20:26:11 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
358	convert r = 2*sin(theta) to parametric, rectangular	Convert the following polar equation to parametric and rectangular.\n\\begin{align*}\n\tr &= 2 \\sin(\\theta)\n\\end{align*}	Polar converted to parametric.\n\\begin{align*}\n\tx &= r \\cos(\\theta)\\\\\n\ty &= r \\sin(\\theta)\\\\\n\tx &= 2 \\sin(\\theta) \\cos(\\theta)\\\\\n\ty &= 2 \\sin(\\theta) \\sin(\\theta)\\\\\n\t  &= 2 \\sin(\\theta)^2\n\\end{align*}\n\nPolar converted to rectangular.\\\\\nIt helps consider the pythagorean theorem and try to\nsolve $x^2 + y^2 = r^2$.\n\\begin{align*}\n\tr &= 2 \\sin(\\theta)\\\\\n\tr^2 &= 4 \\sin(\\theta)^2\\\\\n\t2y &= r^2\\\\\n\t2y &= x^2 + y^2\n\\end{align*}	5	00:03:00	[jmm] Mon Dec  7 20:50:07 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
359	x = sin(theta), y = cos^2(theta)-2)	Given the the parametric equation:\n\\begin{align*}\n\tx &= \\sin(\\theta)\\\\\n\ty &= \\cos(\\theta)^2-2\n\\end{align*}\nA) Find the first derivative.\\\\\nB) Remove the parameter (convert to rectangular).	A) First derivative.\\\\\n\\begin{align*}\n\t\\frac{dy}{dx} &= \\frac{\\frac{dy}{dt}}{\\frac{dx}{dt}}\\\\\n\t&= \\frac{-2 \\sin(\\theta) \\cos(\\theta)}{\\cos(\\theta)}\\\\\n\t&= -2 \\sin(\\theta)\n\\end{align*}\n\n\nB) Remove the parameter.\\\\\n\\begin{align*}\n\t&\\sin(\\theta)^2 + \\cos(\\theta)^2 = 1\\\\\n\ty &= \\cos(\\theta)^2 - 2\\\\\n\tx^2 &= \\sin(\\theta)^2\\\\\n\ty + 2 &= \\cos(\\theta)^2\\\\\n\t1 &= x^2 + y + 2\\\\\n\ty &= -x^2 - 1\n\\end{align*}	8	00:05:00	[jmm] Tue Dec  8 21:07:41 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
360	convert y = x^2 + 2 to parametric	Convert $y = x^2 + 2$ to parametric 3 different ways with 1 way using the slope.	Convert to parametric\n\\begin{align*}\n\tx &= t\\\\\n\ty &= t^2 + 2\\\\\n\tx &= -t\\\\\n\ty &= (-t)^2 + 2\\\\\n\t  &= t^2 + 2\\\\\n\\end{align*}\n\nconvert using slope\n\\begin{align*}\n\t\\frac{dy}{dx} &= 2x\\\\\n\tm &= 2x\\\\\n\tx &= \\frac{m}{2}\\\\\n\ty &= \\Big( \\frac{m}{2} \\Big)^2 + 2\\\\\n\ty &= \\frac{m^2}{4} + 2\n\\end{align*}	5	00:03:00	[jmm] Mon Dec  7 21:10:43 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
361	x = sin(theta), y = cos^2(theta)-2) area	Given the the parametric equation:\n\\begin{align*}\n\tx &= \\sin(\\theta)\\\\\n\ty &= \\cos(\\theta)^2-2\n\\end{align*}\n\nEvaluate the integral:\n\\begin{align*}\n\\int_{y = -2}^{-1}{x \\; dy}\n\\end{align*}	\\begin{align*}\n\t&\\int_{y = -2}^{-1}{x \\; dy}\\\\\n\t&\\int_{y = -2}^{-1}{\\sin(\\theta) 2 \\cos(\\theta) (-\\sin(\\theta)) \\; d\\theta}\\\\\n\t&-2 \\int_{\\theta = \\frac{\\pi}{2}}^{0}{\\sin(\\theta)^2 \\cos(\\theta) \\; d\\theta}\\\\\n\t&= \\frac{2}{3}\n\\end{align*}	5	00:05:00	[jmm] Mon Dec  7 21:29:28 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
362	x = 1 - cos(2* t), y = sqrt(3)*t - 2*cos(t)	Given the the parametric equation:\n\\begin{align*}\n\tx &= 1 - \\cos(2 t)\\\\\n\ty &= \\sqrt{3} t - 2 \\cos(t)\n\\end{align*}\nwithin the range $0 \\le t \\le 3 \\pi$.\n\\\\\n\\\\\nA) Find all horizontal tangents (values of $t$ and points).\\\\\nB) Find all vertical tangents.\\\\\nC) Find the length of the loop.\\\\\nD) Find the area under the loop and between the vertical tangents.\\\\\n	A) All horizontal tangents (values of $t$ and points).\n\\begin{align*}\n\t\\frac{dy}{dt} &= 0\\\\\n\t\\frac{dy}{dt} &= \\sqrt{3} + 2 \\sin(t)\\\\\n\t0 &= \\sqrt{3} + 2 \\sin(t)\\\\\n\t\\frac{\\sqrt{3}}{2} &= \\sin{t}\\\\\n\tt &= \\frac{4 \\pi}{3}, \\frac{5 \\pi}{3}\\\\\n\t&\\Big(\\frac{3}{2}, \\frac{4 \\pi \\sqrt{3} + 3}{3} \\Big)\n\t\\Big(\\frac{3}{2}, \\frac{5 \\pi \\sqrt{3} + 3}{3} \\Big)\n\\end{align*}\n\nB) All vertical tangents (values of $t$ and points).\n\\begin{align*}\n\t\\frac{dx}{dt} &= 0\\\\\n\t\\frac{dx}{dt} &= 2 \\sin(2 t)\\\\\n\t0 &= 2 \\sin(2 t)\\\\\n\t2t &= 0\\\\\n\t2t &= \\pi, 2 \\pi\\\\\n\tt &= \\frac{\\pi}{2}, \\pi\\\\\n\t&\\Big( 2, \\frac{\\pi \\sqrt{3}}{2} \\Big)\n\t\\Big( 0, \\pi \\sqrt{3} + 2 \\Big)\n\\end{align*}\n\nC) Length of loop.\\\\\nUse your calculator to find approximate starting and ending points of\nthe loop then find the arc length.\n\\begin{align*}\n\t&\\int_{t = 3.79}^{5.6}{\\sqrt{(2 \\sin(2t))^2 + (\\sqrt{3} + 2 \\sin(t))^2} dt}\\\\\n\t&= 2.533\n\\end{align*}\n\nD) Area.\\\\\n\\begin{align*}\n\t2 &\\int_{t = \\pi}^{3.79} x \\; dy\\\\\n\t2 &\\int_{t = \\pi}^{3.79}{ (1 - \\cos(2t)) (\\sqrt{3} + 2 \\sin(t)) \\; dt}\\\\\n\t&= 1.76845\n\\end{align*}	15	00:10:00	[jmm] Tue Dec  8 19:11:47 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
363	x = 2-t, y = t^2-2t+2)	Remove the parameter from the following parametric equation:\n\\begin{align*}\n\tx &= 2-t\\\\\n\ty &= t^2 - 2 t + 2\n\\end{align*}	\\begin{align*}\n\tx &= 2-t\\\\\n\ty &= t^2 - 2 t + 2\\\\\n\tt &= 2 - x\\\\\n\ty &= (2-x)^2 - 2(2-x) + 2\\\\\n\t  &= 4 - 4x + x^2 - 4 + 2x + 2\\\\\n\t  &= x^2 - 2x + 2\n\\end{align*}	3	00:02:00	[jmm] Tue Dec  8 21:17:31 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
364	x = cos(t), y = sin(t))	Remove the parameter from the following parametric equation:\n\\begin{align*}\n\tx &= \\cos(t)\\\\\n\ty &= \\sin(t)\n\\end{align*}	\\begin{align*}\n\tx &= \\cos(t)\\\\\n\ty &= \\sin(t)\\\\\n\t&\\cos(t)^2 + \\sin(t)^2 = 1\\\\\n\t&x^2 + y^2 = 1\n\\end{align*}	3	00:02:00	[jmm] Tue Dec  8 21:19:43 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
365	x = 1 + sin(t), y = 2 + 4 * cos(t))	Remove the parameter from the following parametric equation:\n\\begin{align*}\n\tx &= 1 + \\sin(t)\\\\\n\ty &= 2 + 4 * \\cos(t)\n\\end{align*}	\\begin{align*}\n\tx &= 1 + \\sin(t)\\\\\n\ty &= 2 + 4 * \\cos(t)\\\\\n\tx - 1 &= \\sin(t)\\\\\n\t\\frac{y - 2}{4} &= \\cos(t)\\\\\n\t\\sin(t)^2 + \\cos(t)^2 &= 1\\\\\n\t(x-1)^2 + \\Big( \\frac{y - 2}{4} \\Big)^2 &= 1\n\\end{align*}	3	00:02:00	[jmm] Tue Dec  8 21:26:05 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
366	position: x = t^2-2*t+1, y = 4-t^3	\\begin{align*}\n\tx &= t^2 - 2t + 1\\\\\n\ty &= 4 - t^3\n\\end{align*}\n\nWhat is the position at $t = 0$, $t = 3$?	Substitue for $t$ to find $x$ or $y$.\n\\begin{align*}\n\tx &= 0^2 - 2 \\cdot 0 + 1 = 1\\\\\n\ty &= 4 - 0^3 = 4\\\\\n\t&(1, 4)\\\\\n\tx &= 3^2 - 2 \\cdot 3 + 1 = 4\\\\\n\ty &= 4 - 3^3 = -23\\\\\n\t&(4, -23)\\\\\n\\end{align*}	3	00:02:00	[jmm] Tue Dec  8 21:54:32 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
367	tangent: x = t^2-2*t+1, y = 4-t^3	\\begin{align*}\n\tx &= t^2 - 2t + 1\\\\\n\ty &= 4 - t^3\n\\end{align*}\nFind the equation of the tangent line when $t = 3$.	\\begin{align*}\n\t\\frac{dy}{dx} &= \\frac{\\frac{dy}{dt}}{\\frac{dx}{dt}}\\\\\n\t&= \\frac{-3t^2}{2t-2}\n\\end{align*}\n\n\\begin{align*}\n\tm &= \\frac{dy}{dx}\\\\\n\t&= \\frac{-3 \\cdot 3^2}{2 \\cdot 3-2}\\\\\n\t&= -\\frac{27}{4}\n\\end{align*}\n\n\\begin{align*}\n\ty - y_1 &= m (x - x_1)\\\\\n\ty - 4 + 3^3 &= \\Big( -\\frac{27}{4} \\Big) (x - 3^2 + 2 \\cdot 3 + 1)\\\\\n\ty + 23 &= \\Big( -\\frac{27}{4} \\Big) (x - 4)\n\\end{align*}	3	00:02:00	[jmm] Tue Dec  8 22:10:27 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
368	concave up: x = t^2-2*t+1, y = 4-t^3	\\begin{align*}\n\tx &= t^2 - 2t + 1\\\\\n\ty &= 4 - t^3\n\\end{align*}\nFind the intervals over which it is \\emph{concave up}.	First derivative.\n\\begin{align*}\n\t\\frac{dy}{dx} &= \\frac{\\frac{dy}{dt}}{\\frac{dx}{dt}}\\\\\n\t&= \\frac{-3t^2}{2t-2}\n\\end{align*}\n\nSecond derivative.\n\\begin{align*}\n\t\\frac{\\frac{d \\Big( \\frac{-3t^2}{2t-2} \\Big)}{dt} }{\\frac{dx}{dt}}\n\t\t&= \\frac{-6(t)^2 + 12t}{(2t-2)^3}\n\\end{align*}\n\nThe second derivate will be negative when it is concave up and positive\nwhen it is concave down.\\\\\n\\\\\n\nIt is nearly impossible to tell by looking at the plot where it is\nconcave up.\nIf the second derivative is plotted (rectangular) the concavity is more obvious.\n\nIt is concave up when $t < 0$ or $1 < t <= 2$.	10	00:08:00	[jmm] Tue Dec  8 22:56:11 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
370	tangent: x = t^2-4t+6, y=t^3-4t^2+3t+1	\\begin{align*}\n\tx &= t^2 - 4t + 6\\\\\n\ty &= t^3 - 4t^2 + 3t + 1\n\\end{align*}\nFind the exact value of all horizontal tangents on the interval $1 < t < 4$.	The tangent will be horizontal when $\\frac{dy}{dt} = 0$. \n\n\\begin{align*}\n\t\\frac{dy}{dt} &= 3t^2 - 8t + 3\n\\end{align*}\n\nThere is no easy way to find the exact values of $t$ so use\nthe quadratic formula.\n\n\\begin{align*}\n\t&ax^2 + bx^2 + c = 0\\\\\n\t&3t^2 - 8t + 3 = 0\\\\\n\t&\\frac{8 \\pm \\sqrt{64 - 36}}{6}\\\\\n\tt &= \\frac{4 + \\sqrt{7}}{3}, \\frac{4 - \\sqrt{7}}{3}\n\\end{align*}	5	00:05:00	[jmm] Wed Dec  9 12:45:03 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
371	xy=4 to polar	Convert the following rectangualr equation to a polar equation.\n\\begin{equation*}\nxy = 4\n\\end{equation*}	\\begin{align*}\n\t(r \\cos(\\theta)) (r \\sin(\\theta)) &= 4\\\\\n\tr^{2} \\sin(\\theta) \\cos(\\theta) &= 4\\\\\n\tr^{2} &= \\frac{4}{\\sin(\\theta) \\cos(\\theta)}\\\\\n\tr &= \\pm \\sqrt{ \\frac{4}{\\sin(\\theta) \\cos(\\theta)} }\n\\end{align*}	3	00:02:00	[jmm] Tue Dec  1 20:11:46 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
372	3x-y+2=0 to polar	Convert the following rectangular equation to a polar equation.\n\\begin{equation*}\n3x-y+2=0\n\\end{equation*}	\\begin{align*}\n\t3 r \\cos(\\theta) - r \\sin(\\theta) &= -2\\\\\n\tr (3 \\cos(\\theta) - \\sin(\\theta)) &= 2\\\\\n\tr &= \\frac{-2}{3\\cos(\\theta) - \\sin(\\theta)}\n\\end{align*}	3	00:02:00	[jmm] Tue Dec  8 15:08:50 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
373	x^2+y^2=r^2 to polar	Convert the following rectangualr equation to a polar equation.\n\\begin{equation*}\nx^2+y^2=r^2\n\\end{equation*}	\\begin{align*}\n\tx^{2} + y^{2} &= r^{2}\\\\\n\tx^{2} + y^{2} &= 4\\\\\n\tr^{2} &= 4\\\\\n\tr &= \\pm 2\n\\end{align*}	3	00:02:00	[jmm] Tue Dec  1 20:18:08 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
374	x = 10	Convert the following rectangualr equation to a polar equation.\n\\begin{equation*}\n\tx = 10\n\\end{equation*}	\\begin{align*}\n\tr\\cos(\\theta) &= 10\\\\\n\tr &= \\frac{10}{\\cos(\\theta)}\\\\\n\tr &= 10 \\sec(\\theta)\n\\end{align*}	3	00:02:00	[jmm] Tue Dec  1 20:07:43 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
375	r = sin(\\theta) to rectangular	Convert the following polar equation to a rectangular equation.\n\\begin{equation*}\n\tr = \\sin(\\theta)\n\\end{equation*}	\\begin{align*}\n\tr^{2} &= r \\sin(\\theta)\\\\\n\tx^{2} + y^{2} &= y\\\\\n\tx^{2} + y^{2} - y &= 0\\\\\n\tx^{2} + y^{2} - y + \\frac{1}{4} &= \\frac{1}{4}\\\\\n\tx^{2} + \\Big( y - \\frac{1}{2} \\Big)^{2} &= \\frac{1}{2}\\\\\n\\end{align*}	3	00:02:00	[jmm] Tue Dec  1 20:25:10 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
376	r = cos(\\theta) to rectangular	Convert the following polar equation to a rectangular equation.\n\\begin{equation*}\n\tr = \\cos(\\theta)\n\\end{equation*}	\\begin{align*}\n\tr &= \\cos(\\theta)\\\\\n\tr^{2} &= r \\cos(\\theta)\\\\\n\tx^{2} + y^{2} &= x\n\\end{align*}	3	00:02:00	[jmm] Tue Dec  1 20:27:13 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
377	\\theta = \\frac{5 \\pi}{6} to rectangular	Convert the following polar equation to a rectangular equation.\n\\begin{equation*}\n\t\\theta = \\frac{5 \\pi}{6}\n\\end{equation*}	\\begin{align*}\n\t\\theta &= \\frac{5 \\pi}{6}\\\\\n\ty &= mx\\\\\n\tm &= \\tan \\frac{5 \\pi}{6}\\\\\n\t&= -\\frac{\\sqrt{3}}{3}\\\\\n\ty &= -\\frac{\\sqrt{3}}{3} x\n\\end{align*}	3	00:02:00	[jmm] Tue Dec  8 23:48:17 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
378	r = 3 to rectangular	Convert the following polar equation to a rectangular equation.\n\\begin{equation*}\n\tr = 3\n\\end{equation*}	\\begin{align*}\n\tx^{2} + y^{2} &= 9\n\\end{align*}	3	00:02:00	[jmm] Tue Dec  1 20:40:00 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
379	r = 2 sin(\\theta) to parametric	Convert the following polar equation to a parametric equation.\n\\begin{equation*}\n\tr = 2 \\sin(\\theta)\n\\end{equation*}	\\begin{align*}\n\tr &= 2 \\sin(\\theta)\\\\\n\tx &= r \\cos(\\theta)\\\\ \n\t&= (2 \\sin(\\theta)) \\cos(\\theta)\\\\\n\ty &= r \\sin(\\theta)\\\\ \n\t&= (2 \\sin(\\theta)) \\sin(\\theta)\n\\end{align*}	3	00:02:00	[jmm] Tue Dec  1 20:53:29 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
380	find area, arc, tangent of r = 2 sin(2 \\theta)	Given the polar equation:\n\\begin{align*}\n\tr &= 2 \\sin(2 \\theta)\n\\end{align*}\nA) find the area of 1 leaf.\\\\\nB) find the arc length of 1 leaf.\\\\\nC) find a vertical tangent betwee $0 \\le \\theta \\le \\frac{\\Pi}{2}$.	\\begin{equation*}\n\\Big[ \\pi, \\frac{3 \\pi}{2} \\Big]\n\\end{equation*}	10	00:02:00	[jmm] Tue Dec  8 16:56:45 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
381	Write polar (2, 2\\pi/3) 3 ways	Rewrite the following polar coordinate in 3 different ways.\n\\begin{equation*}\n\\Big( 2, \\frac{2 \\pi}{3} \\Big)\n\\end{equation*}	\\begin{align*}\n\t&\\Big( -2, -\\frac{\\pi}{3} \\Big)\\\\\n\t&\\Big( 2, \\frac{8\\pi}{3} \\Big)\\\\\n\t&\\Big( 2, \\frac{-4 \\pi}{3} \\Big)\\\\\n\t&\\Big( -2, \\frac{5 \\pi}{3} \\Big)\n\\end{align*}	3	00:02:00	[jmm] Tue Dec  8 16:56:14 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
382	Convert rectangular (2, -3) to polar	Convert the followin rectangular equation to polar.\n\\begin{equation}\n\\Big( 2, -3 \\Big)\n\\end{equation}	\\begin{align*}\n\t&\\Big( -2, \\frac{2\\pi}{3} \\Big)\\\\\n\t&\\Big( 2, \\frac{5\\pi}{3} \\Big)\\\\\n\t&\\Big( 2, \\frac{11 \\pi}{3} \\Big)\\\\\n\t&\\Big( -2, -\\frac{4 \\pi}{3} \\Big)\n\\end{align*}	3	00:02:00	[jmm] Tue Dec  1 22:55:01 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
383	Write polar (2, -\\pi/3) 3 ways	Write the following polar equation in 3 different ways.\n\\begin{equation*}\n\\Big( 2, -\\frac{\\pi}{3} \\Big)\n\\end{equation*}	\\begin{align*}\n\t&\\Big( -2, \\frac{2\\pi}{3} \\Big)\\\\\n\t&\\Big( 2, \\frac{5\\pi}{3} \\Big)\\\\\n\t&\\Big( 2, \\frac{11 \\pi}{3} \\Big)\\\\\n\t&\\Big( -2, -\\frac{4 \\pi}{3} \\Big)\n\\end{align*}	3	00:02:00	[jmm] Tue Dec  8 15:27:14 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
384	Convert rectangular (-2, Pi/3) to rectangular (x, y)	Convert the following polar coordinates to rectangular.\n\\begin{equation*}\n\\Big(-2, \\Pi/3 \\Big)\n\\end{equation*}	\\begin{align*}\n\t&\\Big( -2, \\frac{\\pi}{3} \\Big)\\\\\n\tx &= (-2) \\cos( \\frac{\\pi}{3} )\\\\\n\tx &= -1\\\\\n\ty &= (-2) \\sin( \\frac{\\pi}{3} )\\\\\n\ty &= -\\sqrt{3}\\\\\n\t&\\Big( -1, -\\sqrt{3} \\Big)\n\\end{align*}	4	00:02:00	[jmm] Tue Dec  8 14:48:59 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
386	find area, arc, tangent of r = 2 cos(3 \\theta)	Given the polar equation:\n\\begin{align*}\n\tr &= 2 \\cos(3 \\theta)\n\\end{align*}\nA) find the area of 1 leaf.\\\\\nB) find the perimeter of 1 leaf.\\\\\nC) find all vertical tangents between $\\frac{Pi}{2}$ to $\\Pi$.	In the following answers there is more than one way to partition the interval\nbut the final value must be the same.\n\\\\\n\\\\\nA) The graph loops once from $0$ to $\\Pi$ and there are 3 leaves\nso the period is $\\frac{\\Pi}{3}$.\nTherfore the area of one leaf is:\n\\begin{align*}\n\t&\\frac{1}{2} \\int_{0}^{\\frac{\\Pi}{3}}(2 \\cos{3\\theta)}^2 d\\theta\\\\\n\t&=1.047197551\n\\end{align*}\n\nB) Using the starting and ending points found in the previous step, the\narc length is:\n\\begin{align*}\n\t&\\int_{0}^{\\frac{\\Pi}{3}}\\sqrt{(2 \\cos{3\\theta)}^2 + (-6 \\sin{3\\theta})^2} d\\theta\\\\\n\t&=4.454964407\n\\end{align*}\n\nC) A vertical tanget between $\\frac{\\Pi}{2}$ to $\\Pi$ will\nbe when $\\frac{dx}{d\\theta} = 0$.\n\n\\begin{align*}\n\tr &= 2 \\cos(3 \\theta)\\\\\n\tx &= (2 \\cos(3 \\theta)) (\\cos(\\theta))\\\\\n\t\\frac{dx}{d\\theta} &= (2 \\cos(3 \\theta)) (-\\sin(\\theta)) + \\cos(\\theta) (-6 \\sin(3 \\theta))\\\\\n\\end{align*}\n\nUsing a TI-89 you can solve to find the answer.\n\\begin{verbatim}\nsolve(<dxdt>, {t=Pi/2});\n\\end{verbatim}\n\\verb+t+ is some guess, and \\verb+<dxdt>+ is the derivative.\nYou could also plot the derivative in rectangular mode and find where it intersects zero.\n\\\\\n\\\\\nA vertical tangent present at all the following points of $x$:\\\\\n$x = \\frac{\\Pi}{2}, 2.22985, \\Pi$.	12	00:10:00	[jmm] Sun Dec  6 14:40:38 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
387	find area, perimeter of r = 5 cos(theta), r= 3 sin(theta)	Given the polar equations:\n\\begin{align*}\n\tr &= 5 \\cos(\\theta)\\\\\n\tr &= 3 \\sin(\\theta)\\\\\n\\end{align*}\nA) Find the area of the intersecting region.\\\\\nB) Find the perimeter of the intersecting region.	In the following answers there is more than one way to partition the interval\nbut the final value must be the same.\n\\\\\n\\\\\nFirst the points where they intersect must be found.\n\\\\\n\\\\\nWhen $\\theta = 0$, $r = 5 \\cos(\\theta)$ is $0$ and when $\\theta = \\frac{\\pi}{2}$,\n $r = 3 \\sin(\\theta)$ is 0 so this is one point where they intersect.\n\\\\\nTo find the other point where the intersect set each equation for $r$ equal\nto each other and solve.\n\n\\begin{align*}\n\tr &= 5 \\cos(\\theta)\\\\\n\tr &= 3 \\sin(\\theta)\\\\\n\t5 \\cos(\\theta) &= 3 \\sin(\\theta)\\\\\n\t\\frac{5}{3} &= \\tan(\\theta)\\\\\n\t\\theta_1 &= \\arctan{\\frac{5}{3}}\n\\end{align*}\n\nA) The area is:\n\n\\begin{align*}\n\t&\\frac{1}{2} \\int_{0}^{\\theta_1} (3 \\sin{\\theta})^2 d\\theta\n     + \\frac{1}{2} \\int_{\\theta_1}^{\\frac{\\pi}{2}} (5 \\cos{\\theta})^2 d\\theta\\\\\n\t&=1.945969736\n\\end{align*}\n\nB) Using the points of intersection found in the previous step the perimiter\nis found similarly.\n\n\\begin{align*}\n\t&\\int_{0}^{\\theta_1} \\sqrt{ (3 \\sin{\\theta})^2 + (3 \\cos(\\theta))^2 } d\\theta\n\t+ \\int_{\\theta_1}^{\\frac{\\pi}{2}} \\sqrt{ (5 \\cos{\\theta})^2 + (-5 \\sin(\\theta))^2}  d\\theta\\\\\n\t&=5.793227981\n\\end{align*}\n	25	00:10:00	[jmm] Tue Dec  8 15:09:37 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
388	find area, perimeter of r = 3 - 5 cos(theta), r= 4	Given the polar equations:\n\\begin{align*}\n\tr &= 3 - 5 \\cos(\\theta)\\\\\n\tr &= 4\\\\\n\\end{align*}\nA) Find the area of the left most region.\\\\\nB) Find all positive horizontal and vertical tangents that\nare enclosed but not on the x or y axis and not part of $r = 4$.\\\\\nC) Find $\\theta$ when the inner loop intersects with itself.	A) area\\\\\nTo find the area the points where they intersect must be found.\nTry to conceptualize the plots as sweeping across an arc may be helpful\nin finding the area.\\\\\n\\\\\n\\\\\nThe first point of intersection.\n\\begin{align*}\n\tr &= 3 - 5 \\cos(\\theta)\\\\\n\tr &= 4\\\\\n\t4 &= 3 - 5 \\cos(\\theta)\\\\\n\t-\\frac{1}{5} &= \\cos(\\theta)\\\\\n\t\\theta_1 &= \\arccos{-\\frac{1}{5}}\n\\end{align*}\n\nSince it is symmetrical the area of one half is found and then doubled instead\nof finding the second point of intersection.\n\\begin{align*}\n\t& 2 \\Big[ \\frac{1}{2} \\int_{\\theta_1}^{\\pi} (3 - 5 \\cos{\\theta})^2 d\\theta\n     - \\frac{1}{2} \\int_{\\theta_1}^{\\pi} (4)^2 d\\theta \\Big]\\\\\n\t&=30.17863590\n\\end{align*}\n\nB) tangents\n\\\\\n\\\\\nThe vertical tangents are located where $\\frac{dx}{d\\theta} = 0$.\n\\begin{align*}\n\tx &= (3 - 5 \\cos(\\theta)) \\cos(\\theta)\\\\\n\t\\frac{dx}{d\\theta} &= -3 \\sin(\\theta) + 10 \\cos(\\theta) \\sin(\\theta)\\\\\n\t&= \\sin(\\theta) \\Big[ -3 + 10 \\cos(\\theta) \\Big]\\\\\n\t\\theta &= 0, \\arccos{\\frac{3}{10}}, \\pi\\\\\n\\end{align*}\nThe vertical tangent in the first quadrant is at $\\arccos{\\frac{3}{10}}$.\n\\\\\n\\\\\nThe horizontal tangents are located where $\\frac{dy}{d\\theta} = 0$.\n\\begin{align*}\n\ty &= (3 - 5 \\cos(\\theta)) \\sin(\\theta)\\\\\n\t\\frac{dy}{d\\theta} &= (3 - 5 \\cos(\\theta)) \\cos(\\theta) + 5 \\sin(\\theta)^2\\\\\n\t&=.78538, 2.35619, 3.926, 5.4977\\\\\n\t&=\\frac{\\pi}{4}, \\frac{2 \\pi}{4}, \\frac{5 \\pi}{4},\\frac{7 \\pi}{4} \n\\end{align*}\nThe horizontal tangent located at the top of the inner loop is at $\\frac{7 \\pi}{4}$.\n\\\\\n\\\\\nC) inner loop crossing\\\\\n\\\\\nThere are 2 points where $r$ is the same but $\\theta$ is different, this is where\nthe inner loop crosses itself.\nSolving by hand where $r = 3 - 5 \\cos(\\theta)$ finds $\\arccos(\\frac{3}{5})$.\nIf you plot $r = 3 - 5 \\cos(x)$ as a rectangular equation you will see the second\npoint near $5.355$.  Since it is symmetrical this point is $2\\pi - \\arccos(\\frac{3}{5})$.\n	25	00:12:00	[jmm] Tue Dec  8 15:08:10 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
406	Find series of 4/(5+x) and interval of convergence	Find the series for:\n\\begin{align*}\n& \\frac{4}{5+x}\\\\\n& c = 3\\\\\n\\end{align*}\n	\n\n\\begin{align*}\n\\frac{4}{? \\pm (x - 3)} &\\\\\ny + (x - 3) &= 5 + x\\\\\ny - 3 &= 5\\\\\ny  &= 8\\\\\n\\frac{4}{8 + (x - 3)} &\\\\\n\\frac{\\frac{1}{2}}{1 - \\frac{(-1)(x - 3)}{8}}\\\\\n \\sum_{n=0}^{\\infty} \\frac{1}{2} \\Big( \\frac{(-1)^{n} (x-3)^{n}}{8} \\Big)\n\\end{align*}\n\n\\begin{align*}\n\\frac{1}{8} \\Big| x - 3 \\Big| < 1\\\\\n\\Big| x - 3 \\Big| < 8\\\\\n-5 < x < 11\\\\\n\\end{align*}\n\nNote: A constant added to a series does not change the interval of convergence.\n	10	00:05:00	[jmm] Sun Dec 13 23:26:54 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
389	find area of r = 4 sin(3 theta), r= 2	Given the polar equations:\n\\begin{align*}\n\tr &= 4 \\sin(3 \\theta)\\\\\n\tr &= 2\\\\\n\\end{align*}\nA) Find the area of one leaf outside the circle.\\\\\nB) Find the area of one leaf inside the circle.	First find the points of interest.\nThe plot has three leaves and completes 1 loop in $\\pi$, therfore\nthe period is $\\frac{\\pi}{3}$.\n\\\\\n\\\\\nOne point where the circle intersects the flower is found by\nsetting the equations equal to each other and solving for $\\theta$.\n\\\\\n\\\\\n\\begin{align*}\n\tr &= 4 \\sin(3 \\theta)\\\\\n\tr &= 2\\\\\n\t2 &= 4 \\sin(3 \\theta)\\\\\n\t\\frac{1}{2} &= \\sin(3 \\theta)\\\\\n\t3 \\theta &= \\frac{\\pi}{6}\\\\\n\t\\theta &= \\frac{\\pi}{18}\n\\end{align*}\n\\\\\n\\\\\nNow that we have the points we need we can find the area.\n\\\\\n\\\\\nA) Area of one leaf outside the circle.\n\\begin{align*}\n\t& 2 \\frac{1}{2} \\int_{\\frac{\\pi}{18}}^{\\frac{\\pi}{6}} (4 \\sin{3 \\theta})^2 d\\theta\n\t- 2 \\frac{1}{2} \\int_{\\frac{\\pi}{18}}^{\\frac{\\pi}{6}} (2)^2 d\\theta\\\\\n\t&=2.550963940\n\\end{align*}\n\\\\\n\\\\\nB) Area of one leaf inside the circle.\n\\\\\n\\\\\n\\begin{align*}\n\t& 2 \\frac{1}{2} \\int_{0}^{\\frac{\\pi}{18}} (4 \\sin{3 \\theta})^2 d\\theta\n\t+ 2 \\frac{1}{2} \\int_{\\frac{\\pi}{18}}^{\\frac{\\pi}{6}} (2)^2 d\\theta\\\\\n\t&=1.637826265\n\\end{align*}	10	00:12:00	[jmm] Sun Dec  6 20:52:19 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
390	find area of r = 2 + 3 cos(theta)	Given the polar equation:\n\\begin{align*}\n\tr &= 2 + 3 \\cos(\\theta)\\\\\n\\end{align*}\nFind the area inside that excludes the small loop.	First find the point where the loop intersects itself.\nThe value of $r$ will be identical for two different $\\theta$.\n\\begin{align*}\n\tr &= 2 + 3 \\cos(\\theta)\\\\\n\t0 &= 2 + 3 \\cos(\\theta)\\\\\n\t-\\frac{2}{3} &= \\cos(\\theta)\\\\\n\t\\theta_1 &= \\arccos{\\frac{-2}{3}}\\\\\n\t\\theta_1 &= \\pi - \\arccos{\\frac{2}{3}}\\\\\n\t\\theta_2 &= 2 \\pi - \\arccos{\\frac{-2}{3}}\\\\\n\t\\theta_2 &= \\pi + \\arccos{\\frac{2}{3}}\n\\end{align*}\n\n\\begin{align*}\n\t& 2 \\frac{1}{2} \\int_{0}^{\\theta_1} (2 + 3 \\cos{\\theta})^2 d\\theta\n\t- \\frac{1}{2} \\int_{\\theta_1}^{\\theta_2} (2 + 3 \\cos{\\theta})^2 d\\theta\\\\\n\t&=25.82177802\n\\end{align*}	10	00:12:00	[jmm] Sun Dec  6 21:19:34 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
391	length of a roll of tape	Find the total length of a roll of tape with inner diameter\nof 1 inch and an outer diamter of 2 inches and a tape thickness of .01 inch.	\\begin{align*}\n\tr &= (rev) (.01)\\\\\n\t&= \\Big( \\frac{\\theta}{2*\\pi} \\Big) \\Big( .01 \\Big)\\\\\n\t&= \\Big( \\frac{\\theta}{2*\\pi} \\Big) \\Big( \\frac{1}{100}\\Big)\\\\\n\t&= \\frac{\\theta}{200 \\pi} \n\\end{align*}\n\\\\\n\\\\\nIt is easier to solve it as at a polar equation but it can be solved\nas a parametric also.\n\\\\\n\\\\\n\\begin{align*}\n\t&\\int_{\\theta_1}^{\\theta_2}{\\sqrt{ r^2 + \\Big(\\frac{dr}{d \\theta} \\Big)^2 } d\\theta}\\\\\n\t&\\int_{\\theta_1}^{\\theta_2}{\\sqrt{ \\Big(\\frac{\\theta}{200 \\pi} \\Big)^2 +\n\t\t\\Big( \\frac{1}{200 \\pi } \\Big)^2 } d\\theta}\\\\\n\t\\frac{1}{200 \\pi } &\\int_{\\theta_1}^{\\theta_2}{\\sqrt{ \\theta^2 +\n\t\t1 } \\; d\\theta}\n\\end{align*}\n\\\\\n\\\\\n\\begin{align*}\n\t1 &= \\frac{\\theta_1}{200 \\pi}\\\\\n\t\\theta_1 &= 200 \\pi\\\\\n\t2 &= \\frac{\\theta_2}{200 \\pi}\\\\\n\t\\theta_2 &= 400 \\pi\n\\end{align*}\n\\\\\n\\\\\n\\begin{align*}\n\t&\\frac{1}{200 \\pi } \\int_{200 \\pi}^{400 \\pi}{\\sqrt{ \\theta^2 +\n\t\t1 } \\; d\\theta}\\\\\n\t&= 942.478\n\\end{align*}	10	00:10:00	[jmm] Mon Dec  7 20:09:44 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
392	pressure on round gate	Find the force on a round gate that has a radius of 2 ft and is\nsubmerged vertically 3 ft down in the water.	\n\n\\begin{align*}\n\t\\Delta F &= p \\cdot depth \\cdot area\\\\\n\t  &= p \\cdot (3 + (2 - x)) \\cdot (2 \\cdot \\sqrt{2^2 - x^2}) \\; \\Delta x\\\\\n\tF &= 2 \\cdot p \\cdot \\int_{-2}^{2} (5 - x) \\cdot \\sqrt{2^2 - x^2} \\; \\Delta x\\\\\n\t  &= 20 \\pi p\n\\end{align*}	8	00:02:00	[jmm] Sat Dec 12 17:39:45 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
393	pressure on triangle gate	A gate shaped as a right triangle with a height of 4 ft and width of\n2 ft (larger end towards the top) is submerged 3 ft under water.\\\\\nWhat is the total force on the gate?	\n\\begin{align*}\n\t\\Delta F &= w \\cdot (x + 3) \\cdot \\; \\Delta A\\\\\n\t         &= p \\cdot (x + 3) \\cdot \\; (a \\cdot \\Delta x)\\\\\n\t\t\t &= p \\cdot (x + 3) \\cdot (\\frac{1}{2} (4 - x)) \\Delta x\\\\\n\tF &= \\frac{p}{2} \\int_{0}^{4} (x + 3) \\cdot (4 - x) \\; dx\\\\\n\t  &= \\frac{52 p}{3}\n\\end{align*}	10	00:04:00	[jmm] Sat Dec 12 17:47:03 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
394	develop series for e^(2x) + e^(-2x)	Develop the series for:\\\\\n\\begin{align*}\n\t& e^{2x} + e^{-2x}\\\\\n\\end{align*}	\nModify the series for $e^x$ by substituting for $x$.\nWrite out the terms of the first series.\nWrite out the terms of the second series.\nCombine terms to find the resulting series.\nDecipher a series.\n\n\\begin{align*}\n\t&= \\sum_{n=0}^{\\infty} \\frac{2 (2x)^{2n}}{2n!}\\\\\n\\end{align*}	10	00:05:00	[jmm] Mon Dec 14 01:50:37 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
395	Find 5th degree Taylor Polynomial of cos(x/2) 	\nFind the 5th degree Taylor Polynomial for $y=cos(x/2)$ about $c=0$.\\\\\nAnd using your calculator find the interval such that $|P_5 - cos(\\frac{x}{2})| < 0.2$.\n	\n\n$f(x) = cos(\\frac{x}{2})$\\\\\n$f'(x) = -\\frac{sin(\\frac{x}{2})}{2}$\\\\\n\\ldots\\\\\n$f^{5}(x)$\\\\\n\n\n$P_5 = $\\\n\n$P_5 = $\\\n\n$P_5 = $\\\n\n\\begin{equation*}\nP_5 = 1 - \\frac{1}{8}x^2 - \\frac{1}{384}x^4\n\\end{equation*}\n\n$Y_1 = P_5$\\\\\n$Y_2 = cos(\\frac{x}{2})$\\\\\n$Y_3 = Y_2 - Y_1$\\\\\n$Plot Y_3$\\\\\nThe interval of which the error is less than $0.2$ is $[-\\pi, \\pi]$.\\\\\n	10	00:10:00	[jmm] Tue Nov 10 10:07:00 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
405	interval of convergence: (2(x-3)^n)/(7 * 5^n)	Find the interval of convergence for the integral of the Power Series for $F(3) = 2$ and reindex:\\\\\n\\begin{align*}\nP(x) &= \\sum_{n=0}^{\\infty} \\frac{2(x-3)^{n}}{7 \\; 5^{n}}\\\\\n\\int P(x) &= F(x) = ?\\\\\n\\end{align*}\n	Take the derivative then use the Ratio Test to find the interval of convergence.\n\n\\begin{align*}\n\\int P(x) \\; dx &= C + \\sum_{n=0}^{\\infty} \\frac{2(x-3)^{n+1}}{7 \\; 5^{n} (n+1)}\\\\\nN &= n + 1\\\\\nn &= N - 1\\\\\n&= C + \\sum_{N=1}^{\\infty} \\frac{2(x-3)^{N}}{7 \\; 5^{N - 1} N}\\\\\n\\end{align*}\n\nSubstitue $F(3) = 2$ and find $C = 2$\n\n\\begin{align*}\n&= 2 + \\sum_{N=1}^{\\infty} \\frac{2(x-3)^{N}}{7 \\; 5^{N - 1} N}\\\\\n\\end{align*}\n\n\\begin{align*}\n& \\lim_{n \\rightarrow \\infty} \\Big| \\frac{2(x-3)^{n+1}}{7 \\; 5^{n}(n+1)} \\frac{7 \\; 5^{n-1} n}{2} \\Big|\n\\Big| x - 3 \\Big|\\\\\n& \\frac{1}{5} \\Big| x - 3 \\Big| < 1\\\\\n& \\Big| x - 3 \\Big| < 5\\\\\n& R = 5\\\\\n& -2 < x < 8\\\\\n\\end{align*}\n\nNote: A constant added to a series does not change the interval of convergence.\n	10	00:05:00	[jmm] Sun Dec 13 23:25:30 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
396	Find 5th degree Taylor Polynomial of sin(x/2) 	Find the 5th degree Taylor Polynomial for $y=sin(x/2)$ about $c=0$.\\\\\nAnd using your calculator find the interval such that $|P_5 - sin(\\frac{x}{2})| < 0.2$.\n	\n\n$f(x) = sin(\\frac{x}{2})$\\\\\n$f'(x) = \\frac{cos(\\frac{x}{2})}{2}$\\\\\n\\ldots\\\\\n\n\n$P_5 = $\\\n\n$P_5 = $\\\n\n$P_5 = $\\\n\n\\begin{align*}\nf(x) & = sin(\\frac{x}{2})  & f'(0) & = 0\\\\\nf'(x) & = \\frac{1}{2} cos(\\frac{x}{2})  & f'(0) & = 1\\\\\nf''(x) & = -\\frac{1}{4} sin(\\frac{x}{2})  & f''(0) & = 0\\\\\nf'''(x) & = -\\frac{1}{8} sin(\\frac{x}{2}) & f'''(0) & = -\\frac{1}{8}\\\\\nf^{4}(x) & = \\frac{1}{16} sin(\\frac{x}{2}) & f^{4}(0) & = 0\\\\\nf^{5}(x) & = \\frac{1}{32} cos(\\frac{x}{2}) & f^{4}(0) & = \\frac{1}{32}\\\\\nP_5 & = 0 + x + 0 - \\frac{x^{3}}{8 \\; 3!} + 0 \\frac{x^{5}}{32 \\; 5!}\\\\\n& =  x - \\frac{x^{3}}{8 \\; 3!} + \\frac{x^{5}}{32 \\; 5!}\\\\\n\\end{align*}\n\nTo find the error enter the following in to the calculator and plot\n$y3$ which is the error.  Trace along the error until you find a minimum\nand maximum of $x$ which is less than $.2$.\n\n\\begin{verbatim}\ny1 = 1/2*x - 1/48*x^3 - 1/3840*x^5\ny2 = sin(x/2)\ny3 = y2(x) - y1(x)\n\\end{verbatim}\n\nThe interval of which the error is less than $0.2$ is $[-5.44, 5.44]$.\\\\\n	10	00:10:00	[jmm] Tue Nov 10 10:08:44 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
397	interval of convergence: (n(x-2)^n)/3^n	\nFind the interval of convergence of the Power Series:\\\\\n\\begin{align*}\n\\sum_{n=1}^{\\infty} \\frac{n (x-2)^{n}}{3^{n}}\\\\\n\\end{align*}\n	\nUse the Ratio Test to find the radius (R) and the interval of convergence.\n\n\\begin{align*}\n& \\lim_{n \\rightarrow \\infty} \\Big| \\frac{(n+1) 3^{n}}{3^{n+1} n} \\Big| \\Big| x - 2 \\Big|\\\\\n& \\frac{1}{3} \\Big| x - 2 \\Big| < 1\\\\\n& \\Big| x - 2 \\Big| < 3\\\\\n& -1 < x < 5\\\\\n\\end{align*}\n\nRadius is $3$.\n	10	00:03:00	[jmm] Sun Dec 13 23:16:17 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
398	interval of convergence: (-1^n x^(2n+1))/(2n+1)!	\nFind the interval of convergence of the Power Series:\\\\\n\\begin{align*}\n\\sum_{n=0}^{\\infty} \\frac{(-1)^{n} (x)^{2n+1}}{(2n+1)!}\\\\\n\\end{align*}\n	\nUse the Ratio Test to find the radius (R) and the interval of convergence.\n\n\\begin{align*}\n& \\lim_{n \\rightarrow \\infty} \\Big| \\frac{(2n+1)!}{(2n+3)!} \\Big| \\Big| x \\Big|\\\\\n& \\lim_{n \\rightarrow \\infty} \\Big| \\frac{1}{(2n+3)(2n+2)} \\Big| \\Big| x \\Big|\\\\\n& = 0\\\\\n& -\\infty < x < \\infty\\\\\n\\end{align*}\nRadius is 0\n	10	00:03:00	[jmm] Sun Dec 13 23:17:02 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
399	interval of convergence: n!/(5^n) (x+1)^n 	\nFind the interval of convergence for the Power Series:\\\\\n\\begin{align*}\n\\sum_{n=0}^{\\infty} \\frac{n!}{5^{n}}(x+1)^{n}\\\\\n\\end{align*}\n	\nThe Ratio Test results in a value of $\\infty$ which is not conclusive (TODO - check what this really means?).\n\nSeeing that this function is geometric with $r = (x+1)^{n}$ it is found:\n\n\\begin{align*}\n\\Big| x + 1 \\Big| &< 1\\\\\n-1 < x &< -1\\\\\n\\end{align*}\n\nMeaning the only time it converges is when $x = -1$.\n	10	00:05:00	[jmm] Sun Dec 13 23:17:55 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
400	interval of convergence: (x-2)^n/5^n	\nFind the interval of convergence for the Power Series:\\\\\n\\begin{align*}\n\\sum_{n=1}^{\\infty} \\frac{(x-2)^{n}}{5^{n}}\\\\\n\\end{align*}\n	\nFind the interval of convergence using the Ratio Test.\n\n\\begin{align*}\n& \\lim_{n \\rightarrow \\infty} \\Big| \\frac{(x-2)^{n+1}}{5^{n+1}} \\frac{5^{n}}{(x-2)^{n}} \\Big|\\\\\n& \\lim_{n \\rightarrow \\infty} \\Big| \\frac{x - 2}{5} \\Big|\\\\\n& \\Big| x - 2 \\Big| < 5\\\\\n& -3 < x < 7\\\\\n\\end{align*}\n\nRadius: 5\n	10	00:05:00	[jmm] Sun Dec 13 23:18:10 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
401	interval of convergence: (x+3)^n/(n(n+1)!)	Find the interval of convergence for the Power Series:\\\\\n\\begin{align*}\nG(x) &= \\sum_{n=1}^{\\infty} \\frac{(x+3)^{n}}{n(n+1)!}\\\\\n\\end{align*}\n	Use the Ratio Test.\n\n\\begin{align*}\n& \\lim_{n \\rightarrow \\infty} \\Big| \\frac{1}{(n+1)(n+2)!} \\frac{n(n+1)!}{1} \\Big|\n\\Big|x + 3 \\Big|\\\\\n& 0 \\; \\Big| x + 3 \\Big|\\\\\n& R = 0\\\\\n& -\\infty < x < \\infty\\\\\n\\end{align*}\n	10	00:05:00	[jmm] Sun Dec 13 23:23:16 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
402	interval of convergence: (x+3)^n/(n(n+1))!	Find the interval of convergence for the first derivative of the Power Series and reindex:\\\\\n\\begin{align*}\nG(x) &= \\sum_{n=1}^{\\infty} \\frac{(x+3)^{n}}{n(n+1)!}\\\\\nG'(x) &= ?\n\\end{align*}\n	Use the Ratio Test.\n\n\\begin{align*}\nG'(x) &= \\sum_{n=1}^{\\infty} \\frac{n(x+3)^{n-1}}{n(n+1)!}\\\\\n&= \\sum_{n=1}^{\\infty} \\frac{(x+3)^{n-1}}{(n+1)!}\\\\\nN &= n-1\\\\\nn &= N + 1\\\\\n&= \\sum_{N=0}^{\\infty} \\frac{(x+3)^{N}}{(N+2)!}\\\\\n\\end{align*}\n\n\\begin{align*}\n& \\lim_{n \\rightarrow \\infty} \\Big| \\frac{1}{(n+2)!} \\frac{(n+1)!}{1} \\Big|\n\\Big| x + 3 \\Big|\\\\\n& R = 0\\\\\n& -\\infty < x < \\infty\\\\\n\\end{align*}\n	10	00:05:00	[jmm] Sun Dec 13 23:23:35 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
403	interval of convergence: (x+3)^n/(n(n+1))!	Find the interval of convergence for the integral of the Power Series and reindex:\\\\\n\\begin{align*}\nG(x) &= \\sum_{n=1}^{\\infty} \\frac{(x+3)^{n}}{n(n+1)!}\\\\\n\\int G(x) \\; dx &= ?\n\\end{align*}\n	Use the Ratio Test to find the interval of convergence.\n\n\\begin{align*}\n\\int G(x) \\; dx &= C + \\sum_{n=1}^{\\infty} \\frac{(x+3)^{n+1}}{n(n+1)(n+1)!}\\\\\n&= C + \\sum_{n=1}^{\\infty} \\frac{(x+3)^{n+1}}{(n+1)!}\\\\\nN &= n-1\\\\\nn &= N + 1\\\\\n&= C + \\sum_{N=0}^{\\infty} \\frac{(x+3)^{N + 1}}{(N+1)(N+2)(N+2)!}\\\\\n\\end{align*}\n\n\\begin{align*}\n& \\lim_{n \\rightarrow \\infty} \\Big| \\frac{1}{(n+2)(n+3)(n+3)!} \\frac{(n+1)(n+2)(n+2)!}{1} \\Big|\n\\Big| x + 3 \\Big|\\\\\n& R = 0\\\\\n& -\\infty < x < \\infty\\\\\n\\end{align*}\n	10	00:05:00	[jmm] Sun Dec 13 23:24:26 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
404	interval of convergence: (2(x-3)^n)/(7*5^n)	Find the interval of convergence for the first derivative of the Power Series and reindex:\\\\\n\\begin{align*}\nP(x) &= \\sum_{n=0}^{\\infty} \\frac{2(x-3)^{n}}{7 \\; 5^{n}}\\\\\n\\end{align*}\n	Take the derivative then use the Ratio Test to find the interval of convergence.\n\n\\begin{align*}\nP'(x) &= \\sum_{n=1}^{\\infty} \\frac{2n(x-3)^{n-1}}{7 \\; 5^{n}}\\\\\nN &= n - 1\\\\\nn &= N + 1\\\\\nP'(x) &= \\sum_{N=0}^{\\infty} \\frac{2(N + 1)(x-3)^{N}}{7 \\; 5^{N + 1}}\\\\\n\\end{align*}\n\n\\begin{align*}\n& \\lim_{n \\rightarrow \\infty} \\Big| \\frac{2(n+2)}{7 \\; 5^{n+2}} \\frac{7 \\; 5^{n+1}}{2(n + 1)} \\Big|\n\\Big| x - 3 \\Big|\\\\\n& \\frac{1}{5} \\Big| x - 3 \\Big| < 1\\\\\n& \\Big| x - 3 \\Big| < 5\\\\\n& R = 5\\\\\n& -2 < x < 8\\\\\n\\end{align*}\n	10	00:05:00	[jmm] Sun Dec 13 23:24:59 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
407	find the Taylor Polynomial	Using Taylors Theorem find the 3rd Taylor Polynomial and then find the sum for:\n\\begin{align*}\n& f(x) = e^{-\\frac{x}{2}}\\\\\n& c = 0\\\\\n\\end{align*}\n	\n\n\\begin{align*}\nf(x) & = e^{-\\frac{x}{2}}  & f'(0) & = -\\frac{1}{2}\\\\\nf''(x) & = \\frac{1}{4} e^{-\\frac{x}{2}} & f''(0) & = \\frac{1}{4}\\\\\nf'''(x) & = -\\frac{1}{8} e^{-\\frac{x}{2}}\n& f'''(0) & = -\\frac{1}{8}\\\\\nP_3 & = 1 - \\frac{x}{2 \\; 1!} + \\frac{x^{2}}{4 \\; 2!} - \\frac{x^{3}}{8 \\; 3!}\\\\\n& \\sum_{n=0}^{\\infty} \\frac{(-1)^{n} x^{n}}{2^{n} n!}\\\\\n\\end{align*}\n	10	00:05:00	[jmm] Tue Nov 10 09:46:39 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
408	integrate x/sqrt(9 - x^2)	Integrate:\n\\begin{align*}\n\t\\frac{x}{\\sqrt{9 - x^2}}\n\\end{align*}	Use Trigonometric Substitution to find the answer.\n\n(triangle not shown)\n\n\\begin{align*}\n\tx &= 3 \\cdot \\sin(\\theta)\\\\\n\tdx &= 3 \\cdot \\cos(\\theta) \\; d \\theta\\\\\n\t\\sqrt{} &= 3 \\cdot \\cos(\\theta)\n\\end{align*}\n\n\\begin{align*}\n\t&\\int \\frac{3 \\sin(\\theta) \\cdot 3 \\cos(\\theta)}{3 \\cos(\\theta)} \\; d \\theta\\\\\n\t&3 \\int \\sin(\\theta) d \\theta\\\\\n\t&-3 \\cos(\\theta)\n\\end{align*}\n\nNow that the answer has been found in terms of trigonometric functions,\nreverse the substitution to get the final answer. \n\n\\begin{align*}\n\t-\\sqrt{9 - x^2} + C\n\\end{align*}	3	00:02:00	[jmm] Sat Dec 12 13:09:25 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
409	integrate x/sqrt(x^2 - 9)	Integrate:\n\\begin{align*}\n\t\\frac{x}{\\sqrt{x^2 - 9}}\n\\end{align*}	Use Trigonometric Substitution to find the answer.\n\n(triangle not shown)\n\n\\begin{align*}\n\tx &= 3 \\cdot \\sec(\\theta)\\\\\n\tdx &= 3 \\cdot \\sec(\\theta) \\tan(\\theta) \\; d \\theta\\\\\n\t\\sqrt{} &= 3 \\cdot \\tan(\\theta)\n\\end{align*}\n\n\\begin{align*}\n\t&\\int \\frac{3 \\sec(\\theta) \\cdot 3 \\sec(\\theta) \\tan(\\theta)}{3 \\tan(\\theta)} \\; d \\theta\\\\\n\t&3 \\int \\sec(\\theta)^2 d \\theta\\\\\n\t&3 \\tan(\\theta)\n\\end{align*}\n\nNow that the answer has been found in terms of trigonometric functions,\nreverse the substitution to get the final answer. \n\n\\begin{align*}\n\t\\sqrt{x^2 - 9} + C\n\\end{align*}	3	00:02:00	[jmm] Sat Dec 12 13:13:18 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
410	prove equation of a sphere	Use the equations for finding the volume of a shell/washer to prove\nthe equation for the volume of a sphere.\n\n\\begin{align*}\n\tV &= \\frac{4}{3} \\pi r^3\n\\end{align*}	\\begin{align*}\n\t\\Delta V &= \\pi (r^2 - x^2) \\Delta x\\\\\n\tV &= \\pi \\int_{-r}^{r} (r^2 - x^2) \\; dx\\\\\n\t&= \\pi \\Big[ xr^2 - \\frac{x^2}{3} \\Big]_{-r}^{r}\\\\\n\t&= \\pi \\Big[ r^3 - \\frac{r^3}{3} + r^3 - \\frac{r^3}{3} \\Big]\\\\\n\t&= \\pi \\Big[ 2r^3 - \\frac{2r^3}{3} \\Big]\\\\\n\t&= \\pi \\Big[ \\frac{6r^3}{3} - \\frac{2r^3}{3} \\Big]\\\\\n\tV &= \\frac{4}{3} \\pi r^3\\\\\n\\end{align*}	10	00:05:00	[jmm] Sun Dec 13 22:47:28 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
411	work, pump water, cone shaped tank, 3 feet, 8 feet	You have a tank that is shaped like a cone.\nIt is 8 feet tall with a 2 foot radius on the bottom and a 3 foot pipe on\nthe top.  If the tank is full of\nwater how much work will it take to pump all of it out?	Area of a circle is $A = \\pi \\cdot r^2$.\n\n(triangle not shown)\n\n\\begin{align*}\n\t\\Delta w &= p \\cdot \\Delta v (dist \\; pump)\\\\\n\t&= p \\cdot \\pi \\cdot r^2 * \\Delta x \\cdot (3 + x)\\\\\n\t&= p \\cdot \\pi \\int_{0}^{8} \\Big( \\frac{2 x}{8} \\Big)^2 \\cdot (3 + x) \\; dx\n\\end{align*}	3	00:02:00	[jmm] Sat Dec 12 14:04:13 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
412	work, spring, 10 ft.lbs of work	It takes 10 ft.lbs of work to move a spring from rest to 1 ft.\nHow much work will it take to move it from 1 ft to 2 ft?	First the constant $k$ of the spring  must be found.\n\n\\begin{align*}\n\t10 &= \\int_{0}^{1}k x \\; dx\\\\\n\t&= k \\int_{0}^{1}x \\; dx\\\\\n\t10 &= k \\cdot \\frac{1}{2}\\\\\n\tk &= 20\n\\end{align*}\n\n\\begin{align*}\n\t\\Delta w &= F \\cdot \\Delta x\\\\\n\t&= 20 \\cdot x \\cdot \\Delta x\\\\\n\tw &= \\int_{1}^{2} 20 x \\; dx\\\\\n\t&= 30 ft.lbs\n\\end{align*}	6	00:02:00	[jmm] Sat Dec 12 14:28:21 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
413	work to raise chain 40 feet	Joe is standing on top of a building and holding a 40 ft long chain\nof the side.  The chain weighs 3 lbs/ft.  He needs to raise the chain 20 ft.\nHow much work will it take?	\\begin{align*}\n\t\\Delta w &= F \\cdot \\Delta x\\\\\n\t&= 3 \\cdot (-x) \\cdot \\Delta x\\\\\n\t&= \\int_{40}^{20} 3 \\cdot (-x) \\; dx\\\\\n\t&= 1800\n\\end{align*}	3	00:02:00	[jmm] Sat Dec 12 14:50:45 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
414	work to empty half sphere tank	You have a tank full of water shaped like the top half of a sphere with\na 4 ft radius and a 10 ft spout on top.\nIf the tank is full, how much work will it take to empty the top 2 ft?	\\begin{align*}\n\t\\Delta w &= p \\cdot \\Delta v \\cdot (dist \\; pump)\\\\\n\t&= p \\cdot \\pi \\cdot r^2 \\cdot \\Delta x \\cdot (x + 10)\\\\\n\\end{align*}\n\n\\begin{align*}\n\tr^2 + (4 - x)^2 &= 16\\\\\n\tr^2 &= 16 - (4 - x)^2\n\\end{align*}\n\n\\begin{align*}\n\t&= p \\cdot \\pi \\int_{0}^{2} \\cdot (16 - (4 - x)^2) \\cdot (x + 10) \\; dx\\\\\n\t&= p \\cdot \\pi 150.666\n\\end{align*}	4	00:02:00	[jmm] Sat Dec 12 15:08:30 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
415	work, spring, 3 lbs, 6 inch	If 3 lbs moves a spring 6 inches.\nHow much work will it take to move the spring from rest to 1 ft?	$6$ inches = $1/2$ ft.\n\n(picture not shown)\n\n\\begin{align*}\n\tF &= k x\\\\\n\t3 &= k \\cdot \\frac{1}{2}\\\\\n\t6 &= k\\\\\n\tF &= 6 \\cdot x\n\\end{align*}\n\n\\begin{align*}\n\t\\Delta w &= F \\cdot \\Delta x\\\\\n\t&= 6 \\cdot x \\cdot \\Delta x\\\\\n\tw &= \\int_{0}^{1} 6 x \\; dx\\\\\n\t&= 3 \\; ft.lbs\n\\end{align*}	6	00:02:00	[jmm] Sat Dec 12 15:22:20 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
416	work, spring, 3 ft.lbs, 6 inch	If 3 ft.lbs moves a spring 6 inches.\nHow much work will it take to move the spring from rest to 1 ft?	\n(picture not shown)\n\n\\begin{align*}\n\t3 &= \\int_{0}^{1/2} k \\; x \\; dx\\\\\n\t  &= k \\cdot \\Big[ \\frac{x^2}{2} \\Big]_{0}^{1/2}\\\\\n\t3 &= \\frac{k}{8}\\\\\n\tk &= 24\\\\\n\tF &= 24 \\cdot x\n\\end{align*}\n\n\\begin{align*}\n\t\\Delta w &= F \\cdot \\Delta x\\\\\n\t&= 24 \\cdot x \\cdot \\Delta x\\\\\n\tw &= \\int_{0}^{1} 24 x \\; dx\\\\\n\t&= 12 \\; ft.lbs\n\\end{align*}	6	00:02:00	[jmm] Sat Dec 12 15:44:52 2009	Problems from Calculus 1 (MATH-31) taught by Mr Campbell at Butte College in 2009.	Jeremiah Mahler <jmmahler@gmail.com>\nhttp://www.google.com/profiles/jmmahler#about	2011-01-23 20:47:31-08
\.


--
-- Data for Name: problemscores; Type: TABLE DATA; Schema: public; Owner: -
--

COPY problemscores (pscore_id, test_id, problem_id, user_id, assignedtest_id, start_t, end_t, score) FROM stdin;
\.


--
-- Data for Name: problemtags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY problemtags (pt_id, problem_id, tag) FROM stdin;
1	1	ODE
2	1	separable ODE
3	1	class:MATH-31
4	1	difficulty:moderate
5	1	proof
6	1	pythagorean theorem
7	1	arc length
200	50	math32
201	50	vectors
202	50	parallel
203	50	parametric
204	50	line
13	3	ODE
14	3	nonlinear ODE
15	3	Bernoulli ODE
16	3	teacher:Mr. Bigler
17	3	class:MATH-40
18	3	in class example
19	4	ODE
20	4	nonlinear ODE
21	4	Bernoulli ODE
22	4	class:MATH-40
23	5	ODE
24	5	nonlinear ODE
25	5	IVP
26	5	Bernoulli ODE
27	5	class:MATH-40
28	6	math
29	6	class:MATH-40
30	6	ODE
31	6	exact ODE
32	7	math
33	7	class:MATH-40
34	7	ODE
35	7	exact ODE
36	8	physics
37	8	math
38	8	E&M
39	8	class:PHYS-42
40	9	ODE
41	9	separable ODE
42	9	class:MATH-40
43	9	difficulty:medium
44	9	trig
45	10	ODE
46	10	separable ODE
47	10	class:MATH-40
48	10	difficulty:medium
49	10	trig
50	10	partial fractions
51	11	ODE
52	11	separable ODE
53	11	class:MATH-40
54	11	difficulty:hard
55	11	polynomial long division
56	11	partial fractions
57	12	IVP
58	12	ODE
59	12	separable IVP
60	12	class:MATH-40
61	12	difficulty:hard
62	12	trig
63	12	table method of integration
64	13	IVP
65	13	ODE
66	13	linear
67	13	class:MATH-40
68	13	difficulty:hard
69	13	trig
70	14	math
71	14	class:MATH-40
72	14	ODE
73	14	difficulty:hard
74	14	clever substitution
75	14	ultimate method
76	15	math
77	15	class:MATH-40
78	15	orthogonal trajectories
79	15	polynomial long division
80	16	math
81	16	class:MATH-40
82	16	falling bodies
205	51	math32
206	51	vectors
207	51	parallel
208	51	parametric
209	51	symmetric
210	52	math32
89	19	math
90	19	class:MATH-40
91	19	mixture
92	19	linear ODE
93	20	math
94	20	partial fractions
95	20	integration
96	20	class:MATH-31
97	21	physics
98	21	math
99	21	ODE
100	21	Newton
101	21	class:PHYS-41
102	21	class:MATH-40
103	22	ODE
104	22	difficulty:moderate
105	22	class:MATH-40
106	22	reduction of order
107	22	reduction of order - one solution to find another
108	22	test
109	23	ODE
110	23	separable ODE
111	23	class:MATH-40
112	23	difficulty:easy
113	24	ODE
114	24	separable ODE
115	24	class:MATH-40
116	24	difficulty:easy
117	25	ODE
118	25	separable IVP
119	25	class:MATH-40
120	25	difficulty:easy
121	18	math
122	18	class:MATH-40
123	18	exponential decay
211	52	vectors
212	52	parallel
213	52	parametric
214	52	line
215	53	math32
216	53	vectors
130	17	math
131	17	class:MATH-40
132	17	exponential growth
217	53	parametric
218	53	line
219	54	math32
220	54	vectors
221	54	parametric
138	2	math
139	2	class:MATH-31
140	2	difficulty:easy
141	2	proof
142	2	polar
222	54	plane
223	54	3 points
224	55	math32
225	55	vectors
226	55	parallel
227	55	perpendicular
228	55	parametric
229	55	plane
230	56	math32
231	56	vectors
232	56	parallel
233	56	parametric
234	57	math32
235	57	vectors
236	57	parallel
237	57	plane
238	58	math32
239	58	vectors
240	58	intersection
241	58	plane
242	58	systems of equations
243	59	math32
244	59	vectors
245	59	intersection
246	59	plane
247	59	line
248	60	math32
249	60	vectors
250	60	cross product
251	60	dot product
252	60	triple scalar product
253	60	volume
254	61	math32
255	61	vectors
256	61	distance
2063	385	math31
2064	385	polar
2065	385	notes
2143	443	csci10
2144	443	number conversion
2145	443	2s compliment
2146	444	csci10
2147	444	number conversion
2148	444	2s compliment
2149	444	divide by 2
2150	445	csci10
2151	445	number conversion
2152	445	largest power of sixteen
2153	446	csci10
2154	446	number conversion
2155	446	largest power of sixteen
2156	447	csci10
2157	447	number conversion
2158	447	2s compliment
2159	448	csci10
2160	448	number conversion
2161	448	2s compliment
2162	449	csci10
2163	449	number conversion
2164	449	2s compliment
2165	450	csci10
2166	450	number conversion
2167	450	2s compliment
2168	451	csci10
2169	451	number conversion
2170	451	2s compliment
2171	452	csci10
2172	452	number conversion
2173	452	2s compliment
2174	453	csci10
2175	453	number conversion
2176	453	divide by 16
2177	454	csci10
2178	454	number conversion
2179	454	divide by 16
2180	455	csci10
2181	455	hla
2182	456	csci10
2183	456	hla
2184	457	csci10
2185	457	test
2186	457	number conversion
2187	458	csci10
2188	458	test
2189	458	number conversion
2190	459	csci10
2191	459	test
2192	459	number conversion
2193	460	csci10
2194	460	test
2195	460	number conversion
2196	461	csci10
2197	461	test
2198	461	number conversion
2199	462	csci10
2200	462	test
2201	462	number conversion
2202	463	csci10
2203	463	test
2204	463	number conversion
2205	464	csci10
2206	464	test
2207	464	number conversion
2208	465	csci10
2209	465	test
2210	465	number conversion
2211	466	csci10
2212	466	test
2213	466	number conversion
2214	467	csci10
2215	467	test
2216	467	hla
2217	468	testing
2218	468	foo
2219	468	bar
1461	299	math31
1462	299	test
1463	299	geometric
1464	299	exact value
1465	300	math31
1466	300	test
1467	300	telescopic
1468	300	exact sum
1469	301	math31
1470	301	test
1471	301	sum
1472	301	root
1473	301	convergence
1474	302	math31
1475	302	test
1476	302	sum
1477	302	direct compare
1478	302	convergence
1479	303	math31
1480	303	test
1481	303	sum
1482	303	ratio test
1483	303	convergence
1484	304	math31
1485	304	test
1486	304	sum
1487	304	limit test
1488	304	convergence
1489	304	telescopic
1490	305	math31
1491	305	test
1492	305	sum
1493	305	ratio test
1494	305	convergence
1495	306	math31
1496	306	test
1497	306	sum
1498	306	limit test
1499	306	convergence
1500	306	alternating series
1501	307	math31
1502	307	test
1503	307	sum
1504	307	convergence
1505	307	geometric
1506	308	math31
1507	308	test
1508	308	sum
1509	308	convergence
1510	308	integral test
1511	308	log
1512	308	integral
1513	309	math31
1514	309	test
1515	309	sum
1516	309	convergence
1517	309	direct compare
1518	310	math31
1519	310	test
1520	310	sum
1521	310	convergence
1522	310	p series
1523	311	math31
1524	311	power series
1525	311	geometric
1526	311	series
1527	311	find series
1528	311	test
1529	311	test3
1530	312	math31
1531	312	power series
1532	312	series
1533	312	find series
1534	312	test
1535	312	test3
1536	313	math31
1537	313	power series
1538	313	series
1539	313	find series
1540	313	hyperbolic
1541	313	trig
1542	313	test
1543	313	test3
1544	314	math31
1545	314	test
1546	314	test3
1547	314	series
1548	314	power series
1549	314	geometric
1550	315	math31
1551	315	test
1552	315	test3
1553	315	series
1554	315	power series
1555	315	geometric
1556	315	find series
1557	316	math31
1558	316	test
1559	316	test3
1560	316	series
1561	316	power series
1562	316	geometric
1563	316	find series
1564	317	math31
1565	317	test
1566	317	test3
1567	317	series
1568	317	power series
1569	317	log
1570	317	find series
1571	317	sum integration
1572	318	math31
1573	318	test
1574	318	test3
1575	318	series
1576	318	power series
1577	318	geometric
1578	318	find series
1579	318	sum integration
1580	319	math31
1581	319	test
1582	319	test3
1583	319	series
1584	319	power series
1585	319	develop series
1586	319	find series
1587	319	taylors
1588	320	math31
1589	320	test
1590	320	test3
1591	320	series
1592	320	power series
1593	320	develop series
1594	320	find series
1595	320	taylors
1596	320	trig
1597	321	math31
1598	321	test
1599	321	test3
1600	321	series
1601	321	power series
1602	321	find series
1603	322	math31
1604	322	test
1605	322	test3
1606	322	series
1607	322	power series
1608	322	find series
1609	323	math31
1610	323	test
1611	323	test3
1612	323	series
1613	323	power series
1614	323	find series
1615	324	math31
1616	324	test
1617	324	test3
1618	324	series
1619	324	power series
1620	324	find series
1621	324	trig
1622	325	math31
1623	325	test
1624	325	test3
1625	325	series
1626	325	power series
1627	325	find series
1628	325	trig
1629	326	math31
1630	326	test
1631	326	test3
1632	326	series
1633	326	power series
1634	326	find series
1635	326	trig
1636	327	math31
1637	327	test
1638	327	test3
1639	327	series
1640	327	power series
1641	327	find series
1642	327	trig
1643	328	math31
1644	328	integration
1645	328	integration by parts
1646	328	test
1647	329	math31
1648	329	integration
1649	329	integration by parts
1650	329	test
1651	330	math31
1652	330	integration
1653	330	integration by parts
1654	330	test
1655	331	math31
1656	331	integration
1657	331	integration by parts
1658	331	table method
1659	331	test
1660	332	math31
1661	332	integration
1662	332	u sub
1663	332	test
1664	333	math31
1665	333	integration
1666	333	integration by parts
1667	333	test
1668	334	math31
1669	334	integration
1670	334	trig
1671	334	test
1672	335	math31
1673	335	integration
1674	335	trig
1675	335	test
1676	336	math31
1677	336	integration
1678	336	trig
1679	336	test
1680	337	math31
1681	337	integration
1682	337	trig
1683	337	test
1684	338	math31
1685	338	integration
1686	338	trig
1687	338	test
1688	339	math31
1689	339	integration
1690	339	trig
1691	339	test
1692	340	math31
1693	340	integration
1694	340	trig
1695	340	trig sub
1696	340	test
1697	341	math31
1698	341	integration
1699	341	trig
1700	341	trig sub
1701	341	test
1702	342	math31
1703	342	integration
1704	342	trig
1705	342	trig sub
1706	342	test
1707	343	math31
1708	343	integration
1709	343	partial fractions
1710	343	test
1711	344	math31
1712	344	math30
1713	344	limit
1714	345	math31
1715	345	limit
1716	345	hopitals rule
1717	345	log
1718	345	test
1719	346	math31
1720	346	integration
1721	346	mass
1722	346	notes
1723	346	test
1724	347	math31
1725	347	integration
1726	347	mass
1727	347	notes
1728	347	test
1729	348	math31
1730	348	math30
1731	348	integration
1732	349	math31
1733	349	math30
1734	349	integration
1735	349	polynomial long division
1736	350	math31
1737	350	math30
1738	350	integration
1739	350	trig sub
1740	351	math31
1741	351	math30
1742	351	integration
1743	352	math31
1744	352	math30
1745	352	differentiation
1746	352	u sub
1747	352	product rule
1748	353	math31
1749	353	math30
1750	353	integration
1751	353	u sub
1752	354	math31
1753	354	math30
1754	354	integration
1755	354	u sub
1756	354	trig
1757	355	math31
1758	355	math30
1759	355	integration
1760	355	log
1761	356	math31
1762	356	math30
1763	356	integration
1764	356	trig
1765	356	u sub
1766	357	math31
1767	357	parametric
1768	357	polar
1769	357	rectangular
1770	357	notes
1771	357	test
1772	358	math31
1773	358	parametric
1774	358	polar
1775	358	rectangular
1776	358	notes
1777	358	test
1778	359	math31
1779	359	parametric
1780	359	rectangular
1781	359	notes
1782	359	test
1783	359	remove parameter
1784	359	parametric -> rectangular
1785	360	math31
1786	360	parametric
1787	360	rectangular
1788	360	notes
1789	360	test
1790	361	math31
1791	361	parametric
1792	361	rectangular
1793	361	area
1794	361	notes
1795	361	test
1796	362	math31
1797	362	parametric
1798	362	area
1799	362	tangent
1800	362	notes
1801	362	test
1802	363	math31
1803	363	parametric
1804	363	rectangular
1805	363	notes
1806	363	test
1807	363	remove parameter
1808	363	parametric -> rectangular
1809	364	math31
1810	364	parametric
1811	364	rectangular
1812	364	notes
1813	364	test
1814	364	remove parameter
1815	364	parametric -> rectangular
1816	365	math31
1817	365	parametric
1818	365	rectangular
1819	365	notes
1820	365	test
1821	365	remove parameter
1822	365	parametric -> rectangular
1823	366	math31
1824	366	parametric
1825	366	notes
1826	366	test
1827	367	math31
1828	367	parametric
1829	367	notes
1830	367	test
1831	367	tangent
1832	367	derivative
1833	368	math31
1834	368	parametric
1835	368	notes
1836	368	test
1837	368	derivative
1838	368	concave
1839	369	math31
1840	369	parametric
1841	369	notes
1842	369	test
1843	369	arc length
1844	370	math31
1845	370	parametric
1846	370	quadratic
1847	370	notes
1848	370	test
1849	370	tangent
1850	371	math31
1851	371	polar
1852	371	rectangular
1853	371	notes
1854	372	math31
1855	372	polar
1856	372	rectangular
1857	372	notes
1858	373	math31
1859	373	polar
1860	373	rectangular
1861	373	notes
1862	374	math31
1863	374	polar
1864	374	rectangular
1865	374	notes
1866	375	math31
1867	375	polar
1868	375	rectangular
1869	375	notes
1870	376	math31
1871	376	polar
1872	376	rectangular
1873	376	notes
1874	377	math31
1875	377	polar
1876	377	rectangular
1877	377	notes
1878	378	math31
1879	378	polar
1880	378	rectangular
1881	378	notes
1882	379	math31
1883	379	polar
1884	379	parametric
1885	379	notes
1886	380	math31
1887	380	polar
1888	380	notes
1889	381	math31
1890	381	polar
1891	381	notes
1892	381	polar ways
1893	382	math31
1894	382	polar
1895	382	notes
1896	382	rectangular
1897	383	math31
1898	383	polar
1899	383	notes
1900	383	polar ways
1901	384	math31
1902	384	polar
1903	384	notes
1904	384	rectangular
1908	386	math31
1909	386	polar
1910	386	notes
1911	387	math31
1912	387	polar
1913	387	notes
1914	388	math31
1915	388	polar
1916	388	notes
1917	389	math31
1918	389	polar
1919	389	notes
1920	390	math31
1921	390	polar
1922	390	notes
1923	391	math31
1924	391	polar
1925	391	notes
1926	391	test
1927	392	math31
1928	392	integration
1929	392	pressure
1930	392	notes
1931	392	test
1932	393	math31
1933	393	integration
1934	393	pressure
1935	393	notes
1936	393	test
1937	394	math31
1938	394	series
1939	394	develop series
1940	394	find series
1941	394	test
1942	395	math31
1943	395	taylor_polynomial
1944	395	test
1945	396	math31
1946	396	taylor_polynomial
1947	396	test
1948	397	math31
1949	397	test
1950	397	series
1951	397	interval of convergence
1952	398	math31
1953	398	test
1954	398	series
1955	398	power series
1956	398	interval of convergence
1957	398	factorial
1958	399	math31
1959	399	test
1960	399	series
1961	399	power series
1962	399	interval of convergence
1963	399	factorial
1964	400	math31
1965	400	test
1966	400	series
1967	400	power series
1968	400	interval of convergence
1969	400	factorial
1970	401	math31
1971	401	test
1972	401	series
1973	401	power series
1974	401	interval of convergence
1975	401	factorial
1976	402	math31
1977	402	test
1978	402	series
1979	402	power series
1980	402	interval of convergence
1981	402	reindex
1982	402	derivative of series
1983	403	math31
1984	403	test
1985	403	series
1986	403	power series
1987	403	interval of convergence
1988	403	integral of series
1989	404	math31
1990	404	test
1991	404	series
1992	404	power series
1993	404	interval of convergence
1994	404	derivative of series
1995	405	math31
1996	405	test
1997	405	series
1998	405	power series
1999	405	interval of convergence
2000	405	integral of series
2001	406	math31
2002	406	test
2003	406	test3
2004	406	series
2005	406	power series
2006	406	geometric
2007	407	math31
2008	407	test
2009	407	series
2010	407	power series
2011	407	taylor polynomial
2012	408	math31
2013	408	integration
2014	408	trig sub
2015	408	notes
2016	409	math31
2017	409	integration
2018	409	trig sub
2019	409	notes
2020	410	math31
2021	410	integration
2022	410	volume
2023	410	washer
2024	410	sphere
2025	410	proof
2026	410	test
2027	411	math31
2028	411	integration
2029	411	work
2030	411	fluid
2031	411	notes
2032	411	test
2033	412	math31
2034	412	integration
2035	412	work
2036	412	spring
2037	412	notes
2038	412	test
2039	413	math31
2040	413	integration
2041	413	work
2042	413	chain
2043	413	notes
2044	413	test
2045	414	math31
2046	414	integration
2047	414	work
2048	414	fluid
2049	414	notes
2050	414	test
2051	415	math31
2052	415	integration
2053	415	work
2054	415	spring
2055	415	notes
2056	415	test
2057	416	math31
2058	416	integration
2059	416	work
2060	416	spring
2061	416	notes
2062	416	test
\.


--
-- Data for Name: testproblems; Type: TABLE DATA; Schema: public; Owner: -
--

COPY testproblems (tp_id, test_id, problem_id, "order", points) FROM stdin;
1	2	1	1	1
3	2	4	2	1
4	2	5	4	1
6	2	6	5	1
5	2	12	6	1
7	2	7	7	1
8	1	8	1	1
9	1	1	2	1
\.


--
-- Data for Name: tests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY tests (test_id, author, dsc, create_date, finished, date) FROM stdin;
2	\N	*scratch* 2	2011-01-21 16:49:36-08	f	2011-01-21
1	\N	*scratch*	2011-01-21 14:01:22-08	f	2011-01-21
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY users (user_id, username, password, role, first_name, last_name, address, phone, email) FROM stdin;
\.


--
-- Name: assignedtests_assignedtest_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY assignedtests
    ADD CONSTRAINT assignedtests_assignedtest_id_key UNIQUE (assignedtest_id);


--
-- Name: assignedtests_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY assignedtests
    ADD CONSTRAINT assignedtests_pkey PRIMARY KEY (assignedtest_id, test_id, user_id);


--
-- Name: problems_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY problems
    ADD CONSTRAINT problems_pkey PRIMARY KEY (problem_id);


--
-- Name: problems_uuid_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY problems
    ADD CONSTRAINT problems_uuid_key UNIQUE (uuid);


--
-- Name: problemscores_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY problemscores
    ADD CONSTRAINT problemscores_pkey PRIMARY KEY (pscore_id);


--
-- Name: problemtags_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY problemtags
    ADD CONSTRAINT problemtags_pkey PRIMARY KEY (pt_id);


--
-- Name: testproblems_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY testproblems
    ADD CONSTRAINT testproblems_pkey PRIMARY KEY (tp_id);


--
-- Name: tests_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY tests
    ADD CONSTRAINT tests_pkey PRIMARY KEY (test_id);


--
-- Name: unique_problem_tag; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY problemtags
    ADD CONSTRAINT unique_problem_tag UNIQUE (problem_id, tag);


--
-- Name: unique_test_problem; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY testproblems
    ADD CONSTRAINT unique_test_problem UNIQUE (test_id, problem_id);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: users_username_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: assignedtests_test_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY assignedtests
    ADD CONSTRAINT assignedtests_test_id_fkey FOREIGN KEY (test_id) REFERENCES tests(test_id);


--
-- Name: assignedtests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY assignedtests
    ADD CONSTRAINT assignedtests_user_id_fkey FOREIGN KEY (user_id) REFERENCES users(user_id);


--
-- Name: problemscores_assignedtest_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY problemscores
    ADD CONSTRAINT problemscores_assignedtest_id_fkey FOREIGN KEY (assignedtest_id) REFERENCES assignedtests(assignedtest_id);


--
-- Name: problemscores_problem_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY problemscores
    ADD CONSTRAINT problemscores_problem_id_fkey FOREIGN KEY (problem_id) REFERENCES problems(problem_id);


--
-- Name: problemscores_test_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY problemscores
    ADD CONSTRAINT problemscores_test_id_fkey FOREIGN KEY (test_id) REFERENCES tests(test_id);


--
-- Name: problemscores_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY problemscores
    ADD CONSTRAINT problemscores_user_id_fkey FOREIGN KEY (user_id) REFERENCES users(user_id);


--
-- Name: problemtags_problem_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY problemtags
    ADD CONSTRAINT problemtags_problem_id_fkey FOREIGN KEY (problem_id) REFERENCES problems(problem_id);


--
-- Name: testproblems_problem_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY testproblems
    ADD CONSTRAINT testproblems_problem_id_fkey FOREIGN KEY (problem_id) REFERENCES problems(problem_id);


--
-- Name: testproblems_test_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY testproblems
    ADD CONSTRAINT testproblems_test_id_fkey FOREIGN KEY (test_id) REFERENCES tests(test_id);


--
-- Name: public; Type: ACL; Schema: -; Owner: -
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: problems; Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON TABLE problems FROM PUBLIC;
REVOKE ALL ON TABLE problems FROM jeri;
GRANT ALL ON TABLE problems TO jeri;
GRANT ALL ON TABLE problems TO "www-data";


--
-- Name: problems_problem_id_seq; Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON SEQUENCE problems_problem_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE problems_problem_id_seq FROM jeri;
GRANT ALL ON SEQUENCE problems_problem_id_seq TO jeri;
GRANT ALL ON SEQUENCE problems_problem_id_seq TO "www-data";


--
-- Name: problemtags; Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON TABLE problemtags FROM PUBLIC;
REVOKE ALL ON TABLE problemtags FROM jeri;
GRANT ALL ON TABLE problemtags TO jeri;
GRANT ALL ON TABLE problemtags TO "www-data";


--
-- Name: problemtags_pt_id_seq; Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON SEQUENCE problemtags_pt_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE problemtags_pt_id_seq FROM jeri;
GRANT ALL ON SEQUENCE problemtags_pt_id_seq TO jeri;
GRANT ALL ON SEQUENCE problemtags_pt_id_seq TO "www-data";


--
-- Name: testproblems; Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON TABLE testproblems FROM PUBLIC;
REVOKE ALL ON TABLE testproblems FROM jeri;
GRANT ALL ON TABLE testproblems TO jeri;
GRANT ALL ON TABLE testproblems TO "www-data";


--
-- Name: testproblems_tp_id_seq; Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON SEQUENCE testproblems_tp_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE testproblems_tp_id_seq FROM jeri;
GRANT ALL ON SEQUENCE testproblems_tp_id_seq TO jeri;
GRANT ALL ON SEQUENCE testproblems_tp_id_seq TO "www-data";


--
-- Name: tests; Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON TABLE tests FROM PUBLIC;
REVOKE ALL ON TABLE tests FROM jeri;
GRANT ALL ON TABLE tests TO jeri;
GRANT ALL ON TABLE tests TO "www-data";


--
-- Name: tests_test_id_seq; Type: ACL; Schema: public; Owner: -
--

REVOKE ALL ON SEQUENCE tests_test_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE tests_test_id_seq FROM jeri;
GRANT ALL ON SEQUENCE tests_test_id_seq TO jeri;
GRANT ALL ON SEQUENCE tests_test_id_seq TO "www-data";


--
-- PostgreSQL database dump complete
--

